import React, { useState, useEffect } from 'react';
import { UtilityBar } from './components/Header/UtilityBar';
import { Navbar } from './components/Header/Navbar';
import { HeroSection } from './components/Hero/HeroSection';
import { QuickActionsGrid } from './components/QuickActions/QuickActionsGrid';
import { PopularServicesSection } from './components/PopularServices/PopularServicesSection';
import { SchemesSection } from './components/Schemes/SchemesSection';
import { TrustStatsBar } from './components/TrustStats/TrustStatsBar';
import { CitizenDashboard } from './components/Dashboard/CitizenDashboard';
import { GrievanceSection } from './components/Grievances/GrievanceSection';
import { HelpSection } from './components/Help/HelpSection';
import { PortalFooter } from './components/Footer/PortalFooter';

// Modals
import { LoginModal } from './components/Modals/LoginModal';
import { ServiceApplicationModal } from './components/Modals/ServiceApplicationModal';
import { SchemeEligibilityModal } from './components/Modals/SchemeEligibilityModal';
import { SchemeDetailModal } from './components/Modals/SchemeDetailModal';
import { AiAssistantModal } from './components/Modals/AiAssistantModal';
import { PolicyModal } from './components/Modals/PolicyModal';

// Data & Types
import {
  DEFAULT_USER as MOCK_USER,
  INITIAL_APPLICATIONS,
  INITIAL_VAULT_DOCS as INITIAL_VAULT_DOCUMENTS,
  INITIAL_PAYMENTS,
  INITIAL_GRIEVANCES,
  INITIAL_NOTIFICATIONS,
} from './data/mockData';
import { SERVICES_LIST } from './data/servicesData';
import { SCHEMES_LIST } from './data/schemesData';
import {
  ActiveTab,
  LanguageCode,
  FontSizeScale,
  ServiceCategory,
  ServiceItem,
  SchemeItem,
  UserProfile,
  TrackedApplication,
  VaultDocument,
  PaymentRecord,
  GrievanceTicket,
  NotificationItem,
} from './types';

export function App() {
  // Global Accessibility & Localization State
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>('en');
  const [fontSize, setFontSize] = useState<FontSizeScale>('normal');
  const [screenReaderActive, setScreenReaderActive] = useState<boolean>(false);

  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedServiceCategory, setSelectedServiceCategory] = useState<ServiceCategory>('all');
  const [dashboardSubTab, setDashboardSubTab] = useState<'overview' | 'track' | 'vault' | 'payments' | 'grievances'>('overview');

  // User & Data Persistence State
  const [user, setUser] = useState<UserProfile>(MOCK_USER);
  const [applications, setApplications] = useState<TrackedApplication[]>(INITIAL_APPLICATIONS);
  const [vaultDocs, setVaultDocs] = useState<VaultDocument[]>(INITIAL_VAULT_DOCUMENTS);
  const [payments, setPayments] = useState<PaymentRecord[]>(INITIAL_PAYMENTS);
  const [grievances, setGrievances] = useState<GrievanceTicket[]>(INITIAL_GRIEVANCES);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Modal Dialog States
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [activeServiceForApply, setActiveServiceForApply] = useState<ServiceItem | null>(null);
  const [activeSchemeForDetail, setActiveSchemeForDetail] = useState<SchemeItem | null>(null);
  const [isEligibilityModalOpen, setIsEligibilityModalOpen] = useState(false);
  const [eligibilityModalInitialScheme, setEligibilityModalInitialScheme] = useState<SchemeItem | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiInitialQuery, setAiInitialQuery] = useState('');
  const [activePolicyTitle, setActivePolicyTitle] = useState<string | null>(null);

  // Scroll to top on navigation change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  // Handle font size wrapper class
  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large':
        return 'text-[17px]';
      case 'largest':
        return 'text-[18px]';
      case 'normal':
      default:
        return 'text-[16px]';
    }
  };

  // Handlers for Services & Schemes
  const handleSelectService = (service: ServiceItem) => {
    setActiveServiceForApply(service);
  };

  const handleSelectScheme = (scheme: SchemeItem) => {
    setActiveSchemeForDetail(scheme);
  };

  const handleOpenEligibility = (scheme?: SchemeItem) => {
    setEligibilityModalInitialScheme(scheme || null);
    setIsEligibilityModalOpen(true);
  };

  const handleOpenAiAssistant = (initialQuery?: string) => {
    setAiInitialQuery(initialQuery || '');
    setIsAiModalOpen(true);
  };

  // Track reference ID from hero or quick action
  const handleTrackLookup = (appId: string) => {
    setActiveTab('track');
    setDashboardSubTab('track');
  };

  // Submit new application handler
  const handleApplicationSubmitted = (newApp: TrackedApplication) => {
    setApplications((prev) => [newApp, ...prev]);

    // Also push a payment record
    if (newApp.feesPaid > 0) {
      const newPayment: PaymentRecord = {
        id: `PAY-${Date.now()}`,
        transactionId: newApp.receiptNumber,
        serviceName: newApp.serviceTitle,
        amount: newApp.feesPaid,
        date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'SUCCESS',
        paymentMode: 'Bharat BillPay UPI',
        receiptUrl: '#',
      };
      setPayments((prev) => [newPayment, ...prev]);
    }

    // Add notification
    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      title: `Application Registered (${newApp.id})`,
      message: `Your application for ${newApp.serviceTitle} has been submitted for scrutiny.`,
      timestamp: 'Just now',
      read: false,
      type: 'info',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // File Grievance handler
  const handleFileGrievance = (newTicket: GrievanceTicket) => {
    setGrievances((prev) => [newTicket, ...prev]);

    // Add notification
    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      title: `Grievance Lodged (${newTicket.id})`,
      message: `Your complaint has been forwarded to ${newTicket.department}. SLA: 21 Days.`,
      timestamp: 'Just now',
      read: false,
      type: 'warning',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Upload vault document handler
  const handleUploadVaultDoc = (docData: Omit<VaultDocument, 'id'>) => {
    const newDoc: VaultDocument = {
      ...docData,
      id: `DOC-${Date.now()}`,
    };
    setVaultDocs((prev) => [newDoc, ...prev]);
  };

  // Delete vault document handler
  const handleDeleteVaultDoc = (docId: string) => {
    setVaultDocs((prev) => prev.filter((d) => d.id !== docId));
  };

  // Navigation tab handler
  const handleNavigate = (tab: ActiveTab) => {
    setActiveTab(tab);
    if (tab === 'track' || tab === 'vault' || tab === 'payments') {
      setDashboardSubTab(tab as any);
    } else if (tab === 'dashboard') {
      setDashboardSubTab('overview');
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col bg-[#F3F6F9] text-slate-900 antialiased font-sans ${getFontSizeClass()} ${
        screenReaderActive ? 'ring-4 ring-blue-500/20' : ''
      }`}
    >
      {/* 1. Header Top Utility Bar */}
      <UtilityBar
        currentLanguage={currentLanguage}
        onLanguageChange={setCurrentLanguage}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        screenReaderActive={screenReaderActive}
        onToggleScreenReader={() => setScreenReaderActive(!screenReaderActive)}
      />

      {/* 2. Header Main Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={handleNavigate}
        currentLanguage={currentLanguage}
        user={user}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogout={() => setUser({ ...user, isLoggedIn: false })}
        onSelectServiceCategory={(cat) => {
          setSelectedServiceCategory(cat);
          setActiveTab('services');
        }}
        onOpenAiAssistant={() => handleOpenAiAssistant()}
      />

      {/* Screen Reader Active Announcement Strip */}
      {screenReaderActive && (
        <div className="bg-amber-500 text-slate-950 text-xs font-bold py-1.5 px-4 text-center border-b border-amber-600">
          Screen Reader Accessibility Mode is active. All ARIA tags and high-contrast landmarks are optimized.
        </div>
      )}

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 focus:outline-none">
        {/* ========================================================================= */}
        {/* VIEW 1: HOME PAGE */}
        {/* ========================================================================= */}
        {activeTab === 'home' && (
          <>
            <HeroSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onSelectScheme={handleSelectScheme}
              onOpenAiAssistant={handleOpenAiAssistant}
              onTrackLookup={handleTrackLookup}
            />

            <QuickActionsGrid
              currentLanguage={currentLanguage}
              onNavigate={handleNavigate}
            />

            <PopularServicesSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onViewAllClick={() => setActiveTab('services')}
            />

            <SchemesSection
              currentLanguage={currentLanguage}
              onSelectScheme={handleSelectScheme}
              onCheckEligibility={handleOpenEligibility}
              onViewAllClick={() => setActiveTab('schemes')}
              user={user}
            />

            <TrustStatsBar currentLanguage={currentLanguage} />
          </>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: ALL SERVICES CATALOG */}
        {/* ========================================================================= */}
        {activeTab === 'services' && (
          <div className="py-6">
            <PopularServicesSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onViewAllClick={() => {}}
              selectedCategory={selectedServiceCategory}
              onCategoryChange={setSelectedServiceCategory}
              showAllServices={true}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: GOVERNMENT SCHEMES */}
        {/* ========================================================================= */}
        {activeTab === 'schemes' && (
          <div className="py-6">
            <SchemesSection
              currentLanguage={currentLanguage}
              onSelectScheme={handleSelectScheme}
              onCheckEligibility={handleOpenEligibility}
              onViewAllClick={() => {}}
              user={user}
              showAllSchemes={true}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: CITIZEN DASHBOARD / TRACK / VAULT / PAYMENTS */}
        {/* ========================================================================= */}
        {(activeTab === 'dashboard' || activeTab === 'track' || activeTab === 'vault' || activeTab === 'payments') && (
          <CitizenDashboard
            currentLanguage={currentLanguage}
            user={user}
            applications={applications}
            vaultDocs={vaultDocs}
            payments={payments}
            grievances={grievances}
            notifications={notifications}
            initialSubTab={
              activeTab === 'track'
                ? 'track'
                : activeTab === 'vault'
                ? 'vault'
                : activeTab === 'payments'
                ? 'payments'
                : dashboardSubTab
            }
            onTrackNewId={(id) => {
              alert(`Searching central database for reference ID ${id}...`);
            }}
            onApplyServiceClick={() => setActiveTab('services')}
            onFileGrievanceClick={() => setActiveTab('grievances')}
            onUploadVaultDoc={handleUploadVaultDoc}
            onDeleteVaultDoc={handleDeleteVaultDoc}
          />
        )}

        {/* ========================================================================= */}
        {/* VIEW 5: CPGRAMS GRIEVANCES */}
        {/* ========================================================================= */}
        {activeTab === 'grievances' && (
          <GrievanceSection
            currentLanguage={currentLanguage}
            user={user}
            grievances={grievances}
            onFileGrievance={handleFileGrievance}
          />
        )}

        {/* ========================================================================= */}
        {/* VIEW 6: CITIZEN HELP & FAQS */}
        {/* ========================================================================= */}
        {activeTab === 'help' && (
          <HelpSection currentLanguage={currentLanguage} />
        )}
      </main>

      {/* 9. Portal Footer */}
      <PortalFooter
        currentLanguage={currentLanguage}
        onNavigate={handleNavigate}
        onOpenPolicyModal={(title) => setActivePolicyTitle(title)}
      />

      {/* ========================================================================= */}
      {/* MODAL DIALOGS */}
      {/* ========================================================================= */}

      {/* Login / Authentication Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(loggedInUser) => {
          setUser(loggedInUser);
        }}
      />

      {/* Service Application Wizard Modal */}
      {activeServiceForApply && (
        <ServiceApplicationModal
          key={`apply-${activeServiceForApply.id}`}
          service={activeServiceForApply}
          user={user}
          vaultDocs={vaultDocs}
          onClose={() => {
            setActiveServiceForApply(null);
          }}
          onSubmitApplication={(newApp) => {
            handleApplicationSubmitted(newApp);
            setActiveTab('track');
            setDashboardSubTab('track');
          }}
        />
      )}

      {/* Scheme Detail Modal */}
      <SchemeDetailModal
        scheme={activeSchemeForDetail}
        user={user}
        onClose={() => setActiveSchemeForDetail(null)}
        onCheckEligibility={(scheme) => {
          handleOpenEligibility(scheme);
        }}
      />

      {/* Scheme Eligibility Calculator Modal */}
      {isEligibilityModalOpen && (
        <SchemeEligibilityModal
          initialScheme={eligibilityModalInitialScheme}
          user={user}
          onClose={() => setIsEligibilityModalOpen(false)}
          onApplyScheme={(scheme) => {
            alert(`Redirecting to direct DBT enrollment for ${scheme.name}`);
          }}
        />
      )}

      {/* SevaMitra AI Assistant Chat Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        initialQuery={aiInitialQuery}
        onSelectService={handleSelectService}
        onSelectScheme={handleSelectScheme}
      />

      {/* Legal & Policies Modal */}
      <PolicyModal
        policyTitle={activePolicyTitle}
        onClose={() => setActivePolicyTitle(null)}
      />
    </div>
  );
}
export default App;
