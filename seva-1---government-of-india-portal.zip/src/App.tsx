import React, { useState, useEffect } from 'react';
import { UtilityBar } from './components/Header/UtilityBar';
import { Navbar } from './components/Header/Navbar';
import { HeroSection } from './components/Hero/HeroSection';
import { QuickActionsGrid } from './components/QuickActions/QuickActionsGrid';
import { PopularServicesSection } from './components/PopularServices/PopularServicesSection';
import { SchemesSection } from './components/Schemes/SchemesSection';
import { TrustStatsBar } from './components/TrustStats/TrustStatsBar';
import { CitizenDashboard } from './components/Dashboard/CitizenDashboard';
import { TrackApplicationsPage } from './components/Tracking/TrackApplicationsPage';
import { GrievanceSection } from './components/Grievances/GrievanceSection';
import { HelpSection } from './components/Help/HelpSection';
import { PortalFooter } from './components/Footer/PortalFooter';

// Modals
import { LoginModal } from './components/Modals/LoginModal';
import { ServiceApplicationModal } from './components/Modals/ServiceApplicationModal';
import { SchemeEligibilityModal } from './components/Modals/SchemeEligibilityModal';
import { SchemeDetailModal } from './components/Modals/SchemeDetailModal';
import { AiAssistantModal } from './components/Modals/AiAssistantModal';
import { SearchModal } from './components/Modals/SearchModal';
import { PolicyModal } from './components/Modals/PolicyModal';

// Data & Types
import {
  DEFAULT_USER as MOCK_USER,
  INITIAL_APPLICATIONS,
  INITIAL_VAULT_DOCS as INITIAL_VAULT_DOCUMENTS,
  INITIAL_PAYMENTS,
  INITIAL_GRIEVANCES,
  INITIAL_NOTIFICATIONS,
} from './data/mockData';
import { SERVICES_LIST } from './data/servicesData';
import { SCHEMES_LIST } from './data/schemesData';
import {
  ActiveTab,
  LanguageCode,
  FontSizeScale,
  ServiceCategory,
  ServiceItem,
  SchemeItem,
  UserProfile,
  TrackedApplication,
  VaultDocument,
  PaymentRecord,
  GrievanceTicket,
  NotificationItem,
} from './types';

export function App() {
  // Global Accessibility & Localization State
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>(() => {
    try {
      const savedLang = localStorage.getItem('SEVA1_LANG') as LanguageCode;
      if (savedLang) return savedLang;
    } catch (e) {
      console.warn(e);
    }
    return 'en';
  });

  const handleLanguageChange = (newLang: LanguageCode) => {
    setCurrentLanguage(newLang);
    try {
      localStorage.setItem('SEVA1_LANG', newLang);
    } catch (e) {
      console.warn(e);
    }
  };

  const [fontSize, setFontSize] = useState<FontSizeScale>('normal');
  const [screenReaderActive, setScreenReaderActive] = useState<boolean>(false);

  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedServiceCategory, setSelectedServiceCategory] = useState<ServiceCategory>('all');
  const [dashboardSubTab, setDashboardSubTab] = useState<'overview' | 'track' | 'vault' | 'payments' | 'grievances'>('overview');

  // User & Data Persistence State
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('SEVA1_ACTIVE_USER');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.name) return parsed;
      }
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
    return MOCK_USER;
  });

  const [applications, setApplications] = useState<TrackedApplication[]>(() => {
    try {
      const savedUser = localStorage.getItem('SEVA1_ACTIVE_USER');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        if (parsed && parsed.name) {
          return INITIAL_APPLICATIONS.map((app) => ({
            ...app,
            applicantName: parsed.name,
            aadhaarNumber: parsed.aadhaarMasked || app.aadhaarNumber,
          }));
        }
      }
    } catch (e) {
      console.warn(e);
    }
    return INITIAL_APPLICATIONS;
  });

  const [vaultDocs, setVaultDocs] = useState<VaultDocument[]>(INITIAL_VAULT_DOCUMENTS);
  const [payments, setPayments] = useState<PaymentRecord[]>(INITIAL_PAYMENTS);
  const [grievances, setGrievances] = useState<GrievanceTicket[]>(INITIAL_GRIEVANCES);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Synchronize on login
  const handleLoginSuccess = (loggedInUser: UserProfile) => {
    setUser(loggedInUser);
    setApplications(
      INITIAL_APPLICATIONS.map((app) => ({
        ...app,
        applicantName: loggedInUser.name,
        aadhaarNumber: loggedInUser.aadhaarMasked,
      }))
    );
    try {
      localStorage.removeItem('SEVA1_LOGGED_OUT');
      localStorage.setItem('SEVA1_ACTIVE_USER', JSON.stringify(loggedInUser));
    } catch (e) {
      console.warn(e);
    }
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('SEVA1_ACTIVE_USER');
      localStorage.setItem('SEVA1_LOGGED_OUT', 'true');
    } catch (e) {
      console.warn(e);
    }
    setUser({
      name: '',
      email: '',
      phone: '',
      dob: '',
      gender: '',
      aadhaarMasked: '',
      panMasked: '',
      digiLockerLinked: false,
      address: '',
      city: '',
      district: '',
      state: '',
      pincode: '',
      isLoggedIn: false,
    });
  };

  const handleUpdateUser = (updatedUser: UserProfile) => {
    setUser(updatedUser);
    setApplications((prev) =>
      prev.map((app) => ({
        ...app,
        applicantName: updatedUser.name,
        aadhaarNumber: updatedUser.aadhaarMasked,
      }))
    );
    try {
      localStorage.setItem('SEVA1_ACTIVE_USER', JSON.stringify(updatedUser));
    } catch (e) {
      console.warn(e);
    }
  };

  // Modal Dialog States
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [activeServiceForApply, setActiveServiceForApply] = useState<ServiceItem | null>(null);
  const [activeSchemeForDetail, setActiveSchemeForDetail] = useState<SchemeItem | null>(null);
  const [isEligibilityModalOpen, setIsEligibilityModalOpen] = useState(false);
  const [eligibilityModalInitialScheme, setEligibilityModalInitialScheme] = useState<SchemeItem | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiInitialQuery, setAiInitialQuery] = useState('');
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [activePolicyTitle, setActivePolicyTitle] = useState<string | null>(null);

  // Global Ctrl+K / Cmd+K Search Hotkey
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Scroll to top on navigation change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  // Handle font size wrapper class
  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large':
        return 'text-[17px]';
      case 'largest':
        return 'text-[18px]';
      case 'normal':
      default:
        return 'text-[16px]';
    }
  };

  // Handlers for Services & Schemes
  const handleSelectService = (service: ServiceItem) => {
    setActiveServiceForApply(service);
  };

  const handleSelectScheme = (scheme: SchemeItem) => {
    setActiveSchemeForDetail(scheme);
  };

  const handleOpenEligibility = (scheme?: SchemeItem) => {
    setEligibilityModalInitialScheme(scheme || null);
    setIsEligibilityModalOpen(true);
  };

  const handleOpenAiAssistant = (initialQuery?: string) => {
    setAiInitialQuery(initialQuery || '');
    setIsAiModalOpen(true);
  };

  // Track reference ID from hero or quick action
  const handleTrackLookup = (appId: string) => {
    setActiveTab('track');
    setDashboardSubTab('track');
  };

  // Submit new application handler
  const handleApplicationSubmitted = (newApp: TrackedApplication) => {
    setApplications((prev) => [newApp, ...prev]);

    // Also push a payment record
    if (newApp.feesPaid > 0) {
      const newPayment: PaymentRecord = {
        id: `PAY-${Date.now()}`,
        transactionId: newApp.receiptNumber,
        serviceName: newApp.serviceTitle,
        amount: newApp.feesPaid,
        date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'SUCCESS',
        paymentMode: newApp.paymentMode || 'Bharat BillPay UPI',
        receiptUrl: '#',
      };
      setPayments((prev) => [newPayment, ...prev]);
    }

    // Add notification
    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      title: `Application Registered (${newApp.id})`,
      message: `Your application for ${newApp.serviceTitle} has been submitted for scrutiny.`,
      timestamp: 'Just now',
      read: false,
      type: 'info',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // File Grievance handler
  const handleFileGrievance = (newTicket: GrievanceTicket) => {
    setGrievances((prev) => [newTicket, ...prev]);

    // Add notification
    const newNotif: NotificationItem = {
      id: `NOTIF-${Date.now()}`,
      title: `Grievance Lodged (${newTicket.id})`,
      message: `Your complaint has been forwarded to ${newTicket.department}. SLA: 21 Days.`,
      timestamp: 'Just now',
      read: false,
      type: 'warning',
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Upload vault document handler
  const handleUploadVaultDoc = (docData: Omit<VaultDocument, 'id'>) => {
    const newDoc: VaultDocument = {
      ...docData,
      id: `DOC-${Date.now()}`,
    };
    setVaultDocs((prev) => [newDoc, ...prev]);
  };

  // Delete vault document handler
  const handleDeleteVaultDoc = (docId: string) => {
    setVaultDocs((prev) => prev.filter((d) => d.id !== docId));
  };

  // Navigation tab handler
  const handleNavigate = (tab: ActiveTab) => {
    setActiveTab(tab);
    if (tab === 'track' || tab === 'vault' || tab === 'payments') {
      setDashboardSubTab(tab as any);
    } else if (tab === 'dashboard') {
      setDashboardSubTab('overview');
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col bg-[#F3F6F9] text-slate-900 antialiased font-sans ${getFontSizeClass()} ${
        screenReaderActive ? 'ring-4 ring-blue-500/20' : ''
      }`}
    >
      {/* 1. Header Top Utility Bar */}
      <UtilityBar
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        screenReaderActive={screenReaderActive}
        onToggleScreenReader={() => setScreenReaderActive(!screenReaderActive)}
      />

      {/* 2. Header Main Navbar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={handleNavigate}
        currentLanguage={currentLanguage}
        user={user}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
        onSelectServiceCategory={(cat) => {
          setSelectedServiceCategory(cat);
          setActiveTab('services');
        }}
        onOpenAiAssistant={() => handleOpenAiAssistant()}
        onOpenSearch={() => setIsSearchModalOpen(true)}
      />

      {/* Screen Reader Active Announcement Strip */}
      {screenReaderActive && (
        <div className="bg-amber-500 text-slate-950 text-xs font-bold py-1.5 px-4 text-center border-b border-amber-600">
          Screen Reader Accessibility Mode is active. All ARIA tags and high-contrast landmarks are optimized.
        </div>
      )}

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 focus:outline-none">
        {/* ========================================================================= */}
        {/* VIEW 1: HOME PAGE */}
        {/* ========================================================================= */}
        {activeTab === 'home' && (
          <>
            <HeroSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onSelectScheme={handleSelectScheme}
              onOpenAiAssistant={handleOpenAiAssistant}
              onTrackLookup={handleTrackLookup}
              onOpenEligibilityModal={() => handleOpenEligibility()}
              onNavigateToTab={(tab) => handleNavigate(tab as any)}
              userEmail={user.email}
            />

            <QuickActionsGrid
              currentLanguage={currentLanguage}
              onNavigate={handleNavigate}
            />

            <PopularServicesSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onViewAllClick={() => setActiveTab('services')}
            />

            <SchemesSection
              currentLanguage={currentLanguage}
              onSelectScheme={handleSelectScheme}
              onCheckEligibility={handleOpenEligibility}
              onViewAllClick={() => setActiveTab('schemes')}
              user={user}
            />

            <TrustStatsBar currentLanguage={currentLanguage} />
          </>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: ALL SERVICES CATALOG */}
        {/* ========================================================================= */}
        {activeTab === 'services' && (
          <div className="py-6">
            <PopularServicesSection
              currentLanguage={currentLanguage}
              onSelectService={handleSelectService}
              onViewAllClick={() => {}}
              selectedCategory={selectedServiceCategory}
              onCategoryChange={setSelectedServiceCategory}
              showAllServices={true}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: GOVERNMENT SCHEMES */}
        {/* ========================================================================= */}
        {activeTab === 'schemes' && (
          <div className="py-6">
            <SchemesSection
              currentLanguage={currentLanguage}
              onSelectScheme={handleSelectScheme}
              onCheckEligibility={handleOpenEligibility}
              onViewAllClick={() => {}}
              user={user}
              showAllSchemes={true}
            />
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 4: TRACK APPLICATIONS PAGE (DEDICATED NATS STATUS HUB) */}
        {/* ========================================================================= */}
        {activeTab === 'track' && (
          <TrackApplicationsPage
            currentLanguage={currentLanguage}
            user={user}
            applications={applications}
            onApplyNewService={() => setActiveTab('services')}
            onFileGrievanceForApp={(app) => {
              setActiveTab('grievances');
            }}
            onOpenLogin={() => setIsLoginModalOpen(true)}
          />
        )}

        {/* ========================================================================= */}
        {/* VIEW 5: CITIZEN DASHBOARD / VAULT / PAYMENTS (HOME BASE OVERVIEW) */}
        {/* ========================================================================= */}
        {(activeTab === 'dashboard' || activeTab === 'vault' || activeTab === 'payments') && (
          <CitizenDashboard
            currentLanguage={currentLanguage}
            user={user}
            applications={applications}
            vaultDocs={vaultDocs}
            payments={payments}
            grievances={grievances}
            notifications={notifications}
            initialSubTab={
              activeTab === 'vault'
                ? 'vault'
                : activeTab === 'payments'
                ? 'payments'
                : 'overview'
            }
            onNavigateToTrack={() => setActiveTab('track')}
            onApplyServiceClick={() => setActiveTab('services')}
            onFileGrievanceClick={() => setActiveTab('grievances')}
            onUploadVaultDoc={handleUploadVaultDoc}
            onDeleteVaultDoc={handleDeleteVaultDoc}
            onUpdateUser={handleUpdateUser}
            onCheckSchemesClick={() => setActiveTab('schemes')}
          />
        )}

        {/* ========================================================================= */}
        {/* VIEW 6: CPGRAMS GRIEVANCES */}
        {/* ========================================================================= */}
        {activeTab === 'grievances' && (
          <GrievanceSection
            currentLanguage={currentLanguage}
            user={user}
            grievances={grievances}
            onFileGrievance={handleFileGrievance}
          />
        )}

        {/* ========================================================================= */}
        {/* VIEW 7: CITIZEN HELP & FAQS */}
        {/* ========================================================================= */}
        {activeTab === 'help' && (
          <HelpSection currentLanguage={currentLanguage} />
        )}
      </main>

      {/* 9. Portal Footer */}
      <PortalFooter
        currentLanguage={currentLanguage}
        onNavigate={handleNavigate}
        onOpenPolicyModal={(title) => setActivePolicyTitle(title)}
      />

      {/* ========================================================================= */}
      {/* MODAL DIALOGS */}
      {/* ========================================================================= */}

      {/* Login / Authentication Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        currentUser={user}
        currentLanguage={currentLanguage}
      />

      {/* Service Application Wizard Modal */}
      {activeServiceForApply && (
        <ServiceApplicationModal
          key={`apply-${activeServiceForApply.id}`}
          service={activeServiceForApply}
          user={user}
          vaultDocs={vaultDocs}
          onClose={() => {
            setActiveServiceForApply(null);
          }}
          onSubmitApplication={(newApp) => {
            handleApplicationSubmitted(newApp);
            setActiveTab('track');
            setDashboardSubTab('track');
          }}
        />
      )}

      {/* Scheme Detail Modal */}
      <SchemeDetailModal
        scheme={activeSchemeForDetail}
        user={user}
        onClose={() => setActiveSchemeForDetail(null)}
        onCheckEligibility={(scheme) => {
          handleOpenEligibility(scheme);
        }}
      />

      {/* Scheme Eligibility Calculator Modal */}
      {isEligibilityModalOpen && (
        <SchemeEligibilityModal
          initialScheme={eligibilityModalInitialScheme}
          user={user}
          onClose={() => setIsEligibilityModalOpen(false)}
          onApplyScheme={(scheme) => {
            alert(`Redirecting to direct DBT enrollment for ${scheme.name}`);
          }}
        />
      )}

      {/* SevaMitra AI Assistant Chat Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        initialQuery={aiInitialQuery}
        onSelectService={handleSelectService}
        onSelectScheme={handleSelectScheme}
      />

      {/* Global Universal Search Modal */}
      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        currentLanguage={currentLanguage}
        onSelectService={handleSelectService}
        onSelectScheme={handleSelectScheme}
        onOpenAiAssistant={handleOpenAiAssistant}
        onNavigateToVault={() => {
          setActiveTab('dashboard');
          setDashboardSubTab('vault');
        }}
        userEmail={user.email}
      />

      {/* Legal & Policies Modal */}
      <PolicyModal
        policyTitle={activePolicyTitle}
        onClose={() => setActivePolicyTitle(null)}
      />
    </div>
  );
}
export default App;
