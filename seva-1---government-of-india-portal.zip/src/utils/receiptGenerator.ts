import { TrackedApplication, PaymentRecord, UserProfile } from '../types';

export function generateReceiptHTML(
  app: TrackedApplication,
  user?: Partial<UserProfile>
): string {
  const applicantName = app.applicantName || user?.name || 'Citizen Applicant';
  const aadhaar = app.aadhaarNumber || user?.aadhaarMasked || 'XXXX-XXXX-8921';
  const phone = user?.phone || '+91 98765 43210';
  const email = user?.email || 'citizen@govmail.in';
  const address = user?.address || 'New Delhi, India';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SEVA 1 - Official Acknowledgment Receipt - ${app.id}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Noto+Sans+Devanagari:wght@600;700&display=swap');
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: #f1f5f9;
      color: #0f172a;
      padding: 30px 15px;
      line-height: 1.5;
    }
    .receipt-container {
      max-width: 780px;
      margin: 0 auto;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 12px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.08);
      overflow: hidden;
    }
    .header-bar {
      background: #0A1F44;
      color: #ffffff;
      padding: 24px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 4px solid #F5893C;
    }
    .emblem-title {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .emblem-svg {
      width: 44px;
      height: 56px;
      fill: #F5893C;
    }
    .brand-text h1 {
      font-size: 22px;
      font-weight: 800;
      letter-spacing: -0.5px;
      color: #ffffff;
      margin: 0;
    }
    .brand-text h1 span {
      color: #1D5FE0;
    }
    .brand-text p {
      font-size: 11px;
      color: #94a3b8;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-top: 2px;
    }
    .status-badge {
      background: #059669;
      color: #ffffff;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .sub-header {
      background: #f8fafc;
      padding: 16px 30px;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
    }
    .sub-header .doc-type {
      font-size: 13px;
      font-weight: 700;
      color: #0A1F44;
    }
    .sub-header .doc-date {
      font-size: 12px;
      color: #64748b;
    }
    .content-body {
      padding: 30px;
    }
    .highlight-card {
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 8px;
      padding: 18px 20px;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
    }
    .highlight-label {
      font-size: 11px;
      text-transform: uppercase;
      font-weight: 700;
      color: #1e40af;
      letter-spacing: 0.5px;
    }
    .highlight-id {
      font-size: 20px;
      font-weight: 800;
      color: #0A1F44;
      font-family: monospace;
      margin-top: 2px;
    }
    .section-title {
      font-size: 13px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #0A1F44;
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 14px;
      margin-top: 24px;
    }
    .grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 16px;
    }
    .info-item {
      display: flex;
      flex-direction: column;
    }
    .info-item .label {
      font-size: 11px;
      color: #64748b;
      font-weight: 600;
      text-transform: uppercase;
    }
    .info-item .value {
      font-size: 13px;
      color: #0f172a;
      font-weight: 600;
      margin-top: 2px;
    }
    .info-item .mono {
      font-family: monospace;
      font-weight: 700;
      color: #1D5FE0;
    }
    table.fee-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      font-size: 13px;
    }
    table.fee-table th {
      background: #f8fafc;
      color: #475569;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      text-align: left;
      padding: 10px 14px;
      border: 1px solid #e2e8f0;
    }
    table.fee-table td {
      padding: 10px 14px;
      border: 1px solid #e2e8f0;
      color: #1e293b;
    }
    table.fee-table tr.total-row td {
      background: #f1f5f9;
      font-weight: 800;
      font-size: 14px;
      color: #0A1F44;
    }
    .qr-stamp-box {
      margin-top: 28px;
      padding: 18px;
      background: #f8fafc;
      border: 1px dashed #94a3b8;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 20px;
    }
    .qr-text {
      font-size: 11px;
      color: #475569;
      line-height: 1.5;
    }
    .qr-text strong {
      color: #059669;
    }
    .footer-note {
      padding: 16px 30px;
      background: #0A1F44;
      color: #94a3b8;
      font-size: 10px;
      text-align: center;
      border-top: 1px solid #1e293b;
    }
    .footer-note p {
      margin-bottom: 4px;
    }
    .print-button-bar {
      margin-top: 20px;
      text-align: center;
    }
    .btn {
      display: inline-block;
      padding: 10px 24px;
      font-size: 14px;
      font-weight: 700;
      background: #1D5FE0;
      color: #ffffff;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
      margin: 0 6px;
    }
    .btn:hover {
      background: #1548b5;
    }
    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .receipt-container {
        border: none;
        box-shadow: none;
      }
      .print-button-bar {
        display: none !important;
      }
    }
  </style>
</head>
<body>

  <div class="receipt-container">
    <!-- Header -->
    <div class="header-bar">
      <div class="emblem-title">
        <svg class="emblem-svg" viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 10C42 10 38 18 38 26C38 35 38 48 42 66C44 70 48 72 50 72C52 72 56 70 58 66C62 48 62 35 62 26C62 18 58 10 50 10Z" fill="#F5893C"/>
          <path d="M32 20C28 14 20 18 18 24C16 30 20 38 24 42C20 46 16 52 18 58C20 64 26 68 32 68C36 68 38 65 40 60C38 52 38 40 38 30C38 24 35 21 32 20Z" fill="#F5893C" opacity="0.85"/>
          <path d="M68 20C72 14 80 18 82 24C84 30 80 38 76 42C80 46 84 52 82 58C80 64 74 68 68 68C64 68 62 65 60 60C62 52 62 40 62 30C62 24 65 21 68 20Z" fill="#F5893C" opacity="0.85"/>
          <rect x="18" y="74" width="64" height="12" rx="2" fill="#F5893C"/>
          <path d="M24 88C24 88 30 100 50 100C70 100 76 88 76 88H24Z" fill="#F5893C"/>
          <rect x="14" y="102" width="72" height="6" rx="1.5" fill="#F5893C"/>
          <text x="50" y="122" text-anchor="middle" fill="#FFFFFF" font-size="9" font-weight="700" font-family="'Noto Sans Devanagari', sans-serif">सत्यमेव जयते</text>
        </svg>
        <div class="brand-text">
          <h1>SEVA <span>1</span></h1>
          <p>Government of India • National Single Window Portal</p>
        </div>
      </div>
      <div class="status-badge">Submitted & Validated</div>
    </div>

    <!-- Sub-header -->
    <div class="sub-header">
      <div class="doc-type">OFFICIAL APPLICATION ACKNOWLEDGMENT & E-RECEIPT</div>
      <div class="doc-date">Generated on: ${new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
    </div>

    <!-- Body -->
    <div class="content-body">
      <!-- Highlight Card -->
      <div class="highlight-card">
        <div>
          <div class="highlight-label">Application Reference Number (ARN)</div>
          <div class="highlight-id">${app.id}</div>
        </div>
        <div>
          <div class="highlight-label">Bharat BillPay / Treasury Ref</div>
          <div class="highlight-id" style="font-size: 16px; color: #1D5FE0;">${app.receiptNumber}</div>
        </div>
      </div>

      <!-- Service Details -->
      <div class="section-title">1. Service Particulars</div>
      <div class="grid-2">
        <div class="info-item">
          <span class="label">Public Service Applied</span>
          <span class="value">${app.serviceTitle}</span>
        </div>
        <div class="info-item">
          <span class="label">Nodal Department / Ministry</span>
          <span class="value">${app.department}</span>
        </div>
        <div class="info-item">
          <span class="label">Submission Date</span>
          <span class="value">${app.submissionDate}</span>
        </div>
        <div class="info-item">
          <span class="label">Citizens Charter SLA (Target Delivery)</span>
          <span class="value" style="color: #059669; font-weight: 700;">${app.estimatedCompletionDate}</span>
        </div>
      </div>

      <!-- Applicant Details -->
      <div class="section-title">2. Applicant Demographics & Verification</div>
      <div class="grid-2">
        <div class="info-item">
          <span class="label">Applicant Full Name</span>
          <span class="value">${applicantName}</span>
        </div>
        <div class="info-item">
          <span class="label">Aadhaar (Masked UID)</span>
          <span class="value mono">${aadhaar} (Verified ✓)</span>
        </div>
        <div class="info-item">
          <span class="label">Mobile Number</span>
          <span class="value">${phone}</span>
        </div>
        <div class="info-item">
          <span class="label">Residential Address</span>
          <span class="value">${address}</span>
        </div>
      </div>

      <!-- Fee & Payment Details -->
      <div class="section-title">3. Payment & Statutory Fee Breakdown</div>
      <table class="fee-table">
        <thead>
          <tr>
            <th>Description</th>
            <th>Tax Rate</th>
            <th>Mode / Gateway</th>
            <th style="text-align: right;">Amount (INR)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Government Statutory Application Fee</td>
            <td>Exempted (0%)</td>
            <td>${app.paymentMode || 'Bharat BillPay UPI / Treasury'}</td>
            <td style="text-align: right; font-weight: 600;">₹${app.feesPaid}.00</td>
          </tr>
          <tr>
            <td>e-District Facilitation & Digital Delivery Surcharge</td>
            <td>0%</td>
            <td>Digital India Subsidy</td>
            <td style="text-align: right; font-weight: 600;">₹0.00</td>
          </tr>
          <tr class="total-row">
            <td colspan="3">Total Fee Paid & Realized</td>
            <td style="text-align: right; color: #1D5FE0;">₹${app.feesPaid}.00</td>
          </tr>
        </tbody>
      </table>

      <!-- Security / QR Code Section -->
      <div class="qr-stamp-box">
        <div class="qr-text">
          <strong>✓ UIDAI & DigiLocker Pre-Authenticated Record</strong><br/>
          This digital acknowledgment is cryptographically logged in the National Single Window database. You can track this application at <strong>https://seva.gov.in/track</strong> with ARN: <strong>${app.id}</strong>.
          <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #64748b;">SHA256: 8f4e9a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f</div>
        </div>
        <div style="text-align: center; border: 2px solid #0A1F44; padding: 6px; border-radius: 6px; background: #ffffff;">
          <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#0A1F44" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
            <line x1="7" y1="7" x2="7.01" y2="7"></line>
            <line x1="17" y1="7" x2="17.01" y2="7"></line>
            <line x1="7" y1="17" x2="7.01" y2="17"></line>
            <line x1="17" y1="17" x2="17.01" y2="17"></line>
          </svg>
          <div style="font-size: 8px; font-weight: 800; color: #0A1F44; margin-top: 2px;">SCAN TO VERIFY</div>
        </div>
      </div>
    </div>

    <!-- Footer Note -->
    <div class="footer-note">
      <p>This is a computer-generated official document issued under the Information Technology Act, 2000. No physical signature is required.</p>
      <p>National Informatics Centre (NIC) • Ministry of Electronics and Information Technology • Government of India</p>
    </div>
  </div>

  <div class="print-button-bar">
    <button onclick="window.print()" class="btn">Print / Save as PDF</button>
  </div>

</body>
</html>`;
}

export function downloadApplicationReceipt(
  app: TrackedApplication,
  user?: Partial<UserProfile>
): boolean {
  try {
    const htmlContent = generateReceiptHTML(app, user);
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    // Create download link
    const link = document.createElement('a');
    link.href = url;
    link.download = `SEVA1_Application_Receipt_${app.id}.html`;
    document.body.appendChild(link);
    link.click();
    
    // Clean up
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 200);

    return true;
  } catch (error) {
    console.error('Failed to generate receipt file download:', error);
    // Fallback: Open print view
    try {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(generateReceiptHTML(app, user));
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => printWindow.print(), 300);
        return true;
      }
    } catch (fallbackError) {
      console.error('Print fallback failed:', fallbackError);
    }
    return false;
  }
}

export function downloadPaymentReceipt(
  payment: PaymentRecord,
  user?: Partial<UserProfile>
): boolean {
  try {
    const pseudoApp: TrackedApplication = {
      id: payment.transactionId,
      serviceId: 'payment-service',
      serviceTitle: payment.serviceName,
      department: 'Ministry of Finance / Bharat BillPay Treasury',
      applicantName: user?.name || 'Citizen Applicant',
      aadhaarNumber: user?.aadhaarMasked || 'XXXX-XXXX-8921',
      submissionDate: payment.date,
      estimatedCompletionDate: 'Settled Instantaneously',
      status: 'completed',
      statusLabel: 'Payment Realized & Confirmed',
      currentStage: 'Treasury Transaction Completed',
      feesPaid: payment.amount,
      receiptNumber: payment.transactionId,
      timeline: [],
    };

    return downloadApplicationReceipt(pseudoApp, user);
  } catch (err) {
    console.error('Payment receipt download error:', err);
    return false;
  }
}
