import { SERVICES_LIST } from '../data/servicesData';
import { SCHEMES_LIST } from '../data/schemesData';
import { ServiceItem, SchemeItem, VaultDocument } from '../types';

export type SearchResultType = 'service' | 'scheme' | 'document' | 'track' | 'grievance';

export interface UnifiedSearchResult {
  id: string;
  type: SearchResultType;
  title: string;
  hindiTitle?: string;
  subtitle: string;
  badge: string;
  iconName: string;
  category: string;
  actionText: string;
  serviceData?: ServiceItem;
  schemeData?: SchemeItem;
  docData?: Partial<VaultDocument>;
  score: number;
}

// Built-in DigiLocker Document Templates for Universal Search
export const COMMON_VAULT_DOCUMENTS: Array<{
  id: string;
  title: string;
  docType: string;
  issuer: string;
  iconType: string;
  keywords: string[];
}> = [
  {
    id: 'vault-aadhaar',
    title: 'Aadhaar Card (UIDAI Verified)',
    docType: 'Aadhaar Card',
    issuer: 'Unique Identification Authority of India',
    iconType: 'Fingerprint',
    keywords: ['aadhaar', 'aadhar', 'adhar', 'uidai', 'identity', 'uid'],
  },
  {
    id: 'vault-pan',
    title: 'PAN Verification Record',
    docType: 'PAN Card',
    issuer: 'Income Tax Department',
    iconType: 'CreditCard',
    keywords: ['pan', 'pan card', 'tax', 'nsdl', 'utiitsl', 'income tax'],
  },
  {
    id: 'vault-dl',
    title: 'Driving License Record',
    docType: 'Driving License',
    issuer: 'Ministry of Road Transport and Highways (MoRTH)',
    iconType: 'Car',
    keywords: ['driving', 'license', 'dl', 'sarathi', 'parivahan', 'driver'],
  },
  {
    id: 'vault-rc',
    title: 'Vehicle Registration Certificate (RC)',
    docType: 'Vehicle RC',
    issuer: 'Ministry of Road Transport and Highways (MoRTH)',
    iconType: 'ShieldCheck',
    keywords: ['vehicle rc', 'rc', 'car registration', 'bike', 'vahan'],
  },
  {
    id: 'vault-marksheet-10',
    title: 'Class X Secondary School Marksheet',
    docType: 'Marksheet',
    issuer: 'Central Board of Secondary Education (CBSE)',
    iconType: 'GraduationCap',
    keywords: ['10th marksheet', 'class 10', 'cbse', 'matric', 'secondary'],
  },
  {
    id: 'vault-marksheet-12',
    title: 'Class XII Senior Secondary Marksheet',
    docType: 'Marksheet',
    issuer: 'Central Board of Secondary Education (CBSE)',
    iconType: 'GraduationCap',
    keywords: ['12th marksheet', 'class 12', 'cbse', 'inter', 'senior secondary'],
  },
  {
    id: 'vault-ration',
    title: 'Digital Ration Card (NFSA / State PDS)',
    docType: 'Ration Card',
    issuer: 'Department of Food and Public Distribution',
    iconType: 'ShoppingBag',
    keywords: ['ration', 'rashan', 'ration card', 'pds', 'food security', 'bpl'],
  },
  {
    id: 'vault-vaccine',
    title: 'Universal Immunization / COVID Vaccine Certificate',
    docType: 'Vaccine Certificate',
    issuer: 'Ministry of Health and Family Welfare (CoWIN)',
    iconType: 'FileText',
    keywords: ['vaccine', 'vaccination', 'covid', 'cowin', 'health certificate'],
  },
];

// Comprehensive Synonym & Keyword Map for Natural Language Citizen Search
const SYNONYM_MAP: Record<string, string[]> = {
  aadhaar: ['aadhar', 'adhar', 'uidai', 'vid', 'fingerprint', 'biometric', 'demographic', 'uid'],
  pan: ['pan card', 'nsdl', 'utiitsl', 'tax', 'incometax', 'e-pan', 'physical pan', 'tin'],
  voter: ['voter id', 'epic', 'election', 'matdata', 'eci', 'vote', 'form 6', 'form 8'],
  driving: ['license', 'licence', 'dl', 'sarathi', 'parivahan', 'learner', 'llr', 'rto', 'driver'],
  vehicle: ['rc', 'vahan', 'car', 'bike', 'motor', 'chassis', 'registration', 'hypothecation'],
  birth: ['birth certificate', 'janam', 'census', 'crs', 'newborn', 'dob proof'],
  income: ['income certificate', 'aay', 'e-district', 'affidavit', 'salary proof', 'tehsildar'],
  caste: ['caste certificate', 'jati', 'sc', 'st', 'obc', 'ews', 'domicile', 'niwas', 'mool niwas'],
  ration: ['ration card', 'rashan', 'pds', 'khadya', 'bpl', 'aay', 'apl', 'fair price', 'annapurna'],
  passport: ['passport seva', 'visa', 'tatkaal', 'pcc', 'mea', 'external affairs', 'travel doc'],
  kisan: ['pm kisan', 'farmer', 'agriculture', 'krishi', 'kheti', 'dbt', '6000', 'samman nidhi', 'khasra'],
  ayushman: ['pmjay', 'pm-jay', 'health', 'hospital', 'golden card', '5 lakh', 'cashless', 'medical', 'swasthya'],
  awas: ['housing', 'pucca house', 'pmay', 'pradhan mantri awas', 'home loan subsidy', 'makaan'],
  ujjwala: ['gas', 'lpg', 'cylinder', 'chulha', 'subsidy', 'free connection', 'pmuy'],
  jandhan: ['jan dhan', 'zero balance', 'bank account', 'rupay', 'dbt account', 'pmjdy'],
  pension: ['atal pension', 'apy', 'nps', 'jeevan pramaan', 'dlc', 'life certificate', 'senior citizen', 'pfrda'],
  scholarship: ['nsp', 'student', 'tuition', 'merit', 'matric', 'higher education', 'fellowship', 'pre-matric', 'post-matric'],
  sukanya: ['ssy', 'beti bachao', 'girl child', 'high interest', 'daughter savings', '80c'],
};

// Normalize search text (remove punctuation, lower case, trim)
export function normalizeQuery(query: string): string {
  return query
    .toLowerCase()
    .replace(/[^\w\s\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Universal Search Across Services, Schemes, Documents, and Features
 */
export function searchPortalCatalog(rawQuery: string): UnifiedSearchResult[] {
  const query = normalizeQuery(rawQuery);
  if (!query) return [];

  const queryTokens = query.split(' ').filter(Boolean);
  const results: UnifiedSearchResult[] = [];

  // Helper to test if item matches query tokens or synonyms
  const calculateMatchScore = (
    title: string,
    description: string,
    departmentOrMinistry: string,
    tagsOrCategory: string[],
    hindiTitle?: string
  ): number => {
    const cleanTitle = normalizeQuery(title);
    const cleanDesc = normalizeQuery(description);
    const cleanDept = normalizeQuery(departmentOrMinistry);
    const cleanHindi = hindiTitle ? normalizeQuery(hindiTitle) : '';
    const cleanTags = tagsOrCategory.map((t) => normalizeQuery(t)).join(' ');

    let score = 0;

    // 1. Exact match in title
    if (cleanTitle === query || cleanHindi === query) {
      score += 150;
    }
    // 2. Title starts with query
    else if (cleanTitle.startsWith(query)) {
      score += 100;
    }
    // 3. Title contains full query string
    else if (cleanTitle.includes(query) || cleanHindi.includes(query)) {
      score += 80;
    }

    // 4. Token matches
    let tokensMatchedInTitle = 0;
    let tokensMatchedInAnywhere = 0;

    for (const token of queryTokens) {
      let matchedToken = false;

      if (cleanTitle.includes(token) || cleanHindi.includes(token)) {
        tokensMatchedInTitle++;
        matchedToken = true;
        score += 35;
      } else if (cleanTags.includes(token)) {
        matchedToken = true;
        score += 25;
      } else if (cleanDept.includes(token)) {
        matchedToken = true;
        score += 20;
      } else if (cleanDesc.includes(token)) {
        matchedToken = true;
        score += 15;
      }

      // Check synonyms
      for (const [key, synonyms] of Object.entries(SYNONYM_MAP)) {
        if (token === key || synonyms.includes(token)) {
          // If the item title or tags contain the root key or any synonym
          if (
            cleanTitle.includes(key) ||
            cleanTags.includes(key) ||
            synonyms.some((s) => cleanTitle.includes(s) || cleanTags.includes(s) || cleanDesc.includes(s))
          ) {
            matchedToken = true;
            score += 40;
            break;
          }
        }
      }

      if (matchedToken) {
        tokensMatchedInAnywhere++;
      }
    }

    // Require that at least one meaningful token or synonym matched
    if (tokensMatchedInAnywhere === 0 && score === 0) {
      return 0;
    }

    // Bonus for matching all tokens
    if (tokensMatchedInAnywhere === queryTokens.length) {
      score += 30;
    }

    return score;
  };

  // 1. Search Public Services
  for (const s of SERVICES_LIST) {
    const score = calculateMatchScore(
      s.title,
      s.description,
      `${s.department} ${s.ministry}`,
      [s.category, s.categoryLabel, ...(s.requiredDocuments || [])],
      s.hindiTitle
    );

    if (score > 0) {
      results.push({
        id: s.id,
        type: 'service',
        title: s.title,
        hindiTitle: s.hindiTitle,
        subtitle: `${s.department} • SLA: ${s.processingTime}`,
        badge: s.fee === 0 ? 'Free Service' : `Fee: ₹${s.fee}`,
        iconName: s.iconName,
        category: s.categoryLabel,
        actionText: 'Apply Online',
        serviceData: s,
        score: score + (s.popular ? 5 : 0),
      });
    }
  }

  // 2. Search Welfare Schemes
  for (const sc of SCHEMES_LIST) {
    const score = calculateMatchScore(
      sc.name,
      `${sc.summary} ${sc.description}`,
      sc.ministry,
      [sc.category, sc.categoryLabel, ...(sc.tags || [])],
      sc.hindiName
    );

    if (score > 0) {
      results.push({
        id: sc.id,
        type: 'scheme',
        title: sc.name,
        hindiTitle: sc.hindiName,
        subtitle: `${sc.ministry} • Benefit: ${sc.benefitAmount}`,
        badge: sc.benefitAmount,
        iconName: sc.iconName,
        category: sc.categoryLabel,
        actionText: 'Check Eligibility',
        schemeData: sc,
        score: score + 10, // Schemes given high citizen relevance
      });
    }
  }

  // 3. Search DigiLocker Documents
  for (const doc of COMMON_VAULT_DOCUMENTS) {
    const score = calculateMatchScore(
      doc.title,
      `${doc.docType} issued by ${doc.issuer}`,
      doc.issuer,
      [doc.docType, ...doc.keywords]
    );

    if (score > 0) {
      results.push({
        id: doc.id,
        type: 'document',
        title: doc.title,
        subtitle: `Issued by ${doc.issuer}`,
        badge: 'DigiLocker Verified',
        iconName: doc.iconType,
        category: 'DigiLocker Vault',
        actionText: 'Fetch Document',
        docData: {
          title: doc.title,
          docType: doc.docType,
          issuer: doc.issuer,
          iconType: doc.iconType,
        },
        score: score,
      });
    }
  }

  // Sort results by relevance score descending
  return results.sort((a, b) => b.score - a.score);
}

// =========================================================================
// RECENT SEARCHES MANAGER (Local Storage & Per User)
// =========================================================================

const RECENT_SEARCH_KEY = 'SEVA1_RECENT_SEARCH_HISTORY';

export const DEFAULT_RECENT_SEARCHES = [
  'Aadhaar Address Update',
  'Instant e-PAN Card',
  'PM Kisan 19th Installment',
  'Driving License Application',
  'Ayushman Bharat 5 Lakh Card',
];

export function getRecentSearches(userKey?: string): string[] {
  try {
    const storageKey = userKey ? `${RECENT_SEARCH_KEY}_${userKey}` : RECENT_SEARCH_KEY;
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.slice(0, 8);
      }
    }
  } catch (e) {
    console.warn('Failed to load recent searches:', e);
  }
  return DEFAULT_RECENT_SEARCHES;
}

export function saveRecentSearch(query: string, userKey?: string): void {
  const clean = query.trim();
  if (!clean || clean.length < 2) return;

  try {
    const storageKey = userKey ? `${RECENT_SEARCH_KEY}_${userKey}` : RECENT_SEARCH_KEY;
    const current = getRecentSearches(userKey).filter(
      (item) => item.toLowerCase() !== clean.toLowerCase()
    );
    const updated = [clean, ...current].slice(0, 8);
    localStorage.setItem(storageKey, JSON.stringify(updated));
  } catch (e) {
    console.warn('Failed to save recent search:', e);
  }
}

export function removeRecentSearch(queryToRemove: string, userKey?: string): string[] {
  try {
    const storageKey = userKey ? `${RECENT_SEARCH_KEY}_${userKey}` : RECENT_SEARCH_KEY;
    const current = getRecentSearches(userKey).filter(
      (item) => item.toLowerCase() !== queryToRemove.toLowerCase()
    );
    localStorage.setItem(storageKey, JSON.stringify(current));
    return current;
  } catch (e) {
    console.warn('Failed to remove recent search:', e);
    return DEFAULT_RECENT_SEARCHES;
  }
}

export function clearAllRecentSearches(userKey?: string): void {
  try {
    const storageKey = userKey ? `${RECENT_SEARCH_KEY}_${userKey}` : RECENT_SEARCH_KEY;
    localStorage.setItem(storageKey, JSON.stringify([]));
  } catch (e) {
    console.warn('Failed to clear recent searches:', e);
  }
}
