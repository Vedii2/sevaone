export type LanguageCode = 
  | 'en' // English
  | 'hi' // Hindi हिन्दी
  | 'bn' // Bengali বাংলা
  | 'te' // Telugu తెలుగు
  | 'mr' // Marathi मराठी
  | 'ta' // Tamil தமிழ்
  | 'gu' // Gujarati ગુજરાતી
  | 'kn' // Kannada ಕನ್ನಡ
  | 'ml' // Malayalam മലയാളം
  | 'pa' // Punjabi ਪੰਜਾਬੀ
  | 'or'; // Odia ଓଡ଼ିଆ

export type ActiveTab = 
  | 'home' 
  | 'services' 
  | 'schemes' 
  | 'track' 
  | 'dashboard' 
  | 'grievances' 
  | 'help'
  | 'vault'
  | 'payments';

export type ServiceCategory = 
  | 'all'
  | 'identity'
  | 'health'
  | 'agriculture'
  | 'transport'
  | 'education'
  | 'revenue'
  | 'welfare'
  | 'business';

export interface ServiceItem {
  id: string;
  title: string;
  hindiTitle?: string;
  category: ServiceCategory;
  categoryLabel: string;
  department: string;
  ministry: string;
  description: string;
  processingTime: string;
  fee: number;
  iconName: string;
  requiredDocuments: string[];
  eligibility: string;
  popular?: boolean;
}

export type SchemeCategory = 
  | 'all'
  | 'farmers'
  | 'health'
  | 'women'
  | 'students'
  | 'seniors'
  | 'housing'
  | 'business';

export interface SchemeItem {
  id: string;
  name: string;
  hindiName?: string;
  category: SchemeCategory;
  categoryLabel: string;
  ministry: string;
  benefitAmount: string;
  summary: string;
  description: string;
  iconName: string;
  tags: string[];
  eligibilityCriteria: {
    minAge?: number;
    maxAge?: number;
    maxIncome?: number; // per annum in INR
    occupation?: string[];
    gender?: 'All' | 'Female' | 'Male';
    landholdingLimit?: string;
  };
  documentsRequired: string[];
}

export type ApplicationStatus = 'submitted' | 'under_review' | 'approved' | 'rejected' | 'completed';

export interface ApplicationTimelineStep {
  title: string;
  description: string;
  date?: string;
  completed: boolean;
  current?: boolean;
}

export interface TrackedApplication {
  id: string;
  serviceId: string;
  serviceTitle: string;
  department: string;
  applicantName: string;
  aadhaarNumber: string;
  submissionDate: string;
  estimatedCompletionDate: string;
  status: ApplicationStatus;
  statusLabel: string;
  currentStage: string;
  timeline: ApplicationTimelineStep[];
  officerRemarks?: string;
  feesPaid: number;
  receiptNumber: string;
  paymentMode?: string;
  upiTxnRef?: string;
}

export interface VaultDocument {
  id: string;
  title: string;
  docType: string;
  docNumber: string;
  issuer: string;
  issueDate: string;
  expiryDate?: string;
  verified: boolean;
  fileSize: string;
  fileUrl?: string;
  iconType: string;
}

export interface PaymentRecord {
  id: string;
  transactionId: string;
  serviceName: string;
  amount: number;
  date: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  paymentMode: string;
  receiptUrl?: string;
}

export interface GrievanceTicket {
  id: string;
  department: string;
  category: string;
  subject: string;
  description: string;
  filedDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
  statusLabel: string;
  slaDaysRemaining: number;
  assignedOfficer: string;
  attachmentName?: string;
  updates: {
    date: string;
    stage: string;
    remarks: string;
  }[];
}

export type FontSizeScale = 'normal' | 'large' | 'largest';

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  dob?: string;
  gender?: string;
  aadhaarMasked: string;
  panMasked: string;
  digiLockerLinked: boolean;
  avatarUrl?: string;
  address: string;
  city: string;
  district?: string;
  state: string;
  pincode: string;
  isLoggedIn: boolean;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'info' | 'success' | 'warning';
}
