import { TrackedApplication, VaultDocument, PaymentRecord, GrievanceTicket, UserProfile, FaqItem, NotificationItem } from '../types';

export const DEFAULT_USER: UserProfile = {
  name: 'Manasvi Raut',
  email: 'manasvi.raut@govmail.in',
  phone: '+91 98201 45678',
  dob: '1998-08-14',
  gender: 'Female',
  aadhaarMasked: 'XXXX-XXXX-7721',
  panMasked: 'BMQPR7721M',
  digiLockerLinked: true,
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  address: 'Flat 402, Shivam Enclave, Bandra West, Mumbai - 400050',
  city: 'Mumbai',
  district: 'Mumbai Suburban',
  state: 'Maharashtra',
  pincode: '400050',
  isLoggedIn: true,
};

export const INITIAL_APPLICATIONS: TrackedApplication[] = [
  {
    id: 'APP-2026-88219',
    serviceId: 'driving-license',
    serviceTitle: 'Driving License Renewal & Smart Card',
    department: 'Ministry of Road Transport and Highways (Sarathi)',
    applicantName: 'Manasvi Raut',
    aadhaarNumber: 'XXXX-XXXX-7721',
    submissionDate: '2026-08-24',
    estimatedCompletionDate: '2026-09-06',
    status: 'under_review',
    statusLabel: 'Under Review at RTO Delhi West',
    currentStage: 'Biometrics & Document Verification Verified',
    feesPaid: 350,
    receiptNumber: 'REC-DL-2026-99014',
    officerRemarks: 'All uploaded medical forms and biometric records match UIDAI credentials. Smart card printing in progress.',
    timeline: [
      {
        title: 'Application Submitted Online',
        description: 'Form submitted and payment of ₹350 processed successfully via Bharat BillPay.',
        date: '24 Aug 2026, 10:14 AM',
        completed: true,
      },
      {
        title: 'Aadhaar & DigiLocker Verification',
        description: 'Instant e-KYC authentication verified with UIDAI master database.',
        date: '24 Aug 2026, 10:16 AM',
        completed: true,
      },
      {
        title: 'Document Scrutiny by Motor Licensing Officer',
        description: 'Officer checked Form 1A medical fitness and previous DL records.',
        date: '27 Aug 2026, 03:40 PM',
        completed: true,
      },
      {
        title: 'Card Printing & Dispatch via Speed Post',
        description: 'Smart DL card queued for laser engraving and postal dispatch with tracking number.',
        date: 'Estimated by 05 Sep 2026',
        completed: false,
        current: true,
      },
      {
        title: 'Delivered to Registered Address',
        description: 'Delivered to resident with SMS delivery confirmation.',
        completed: false,
      }
    ]
  },
  {
    id: 'APP-2026-77341',
    serviceId: 'income-certificate',
    serviceTitle: 'Annual Income Certificate (Tehsildar Office)',
    department: 'Revenue Department, Govt of NCT Delhi',
    applicantName: 'Manasvi Raut',
    aadhaarNumber: 'XXXX-XXXX-7721',
    submissionDate: '2026-08-12',
    estimatedCompletionDate: '2026-08-20',
    status: 'approved',
    statusLabel: 'Certificate Issued & Digitally Signed',
    currentStage: 'Available for Download in Document Vault',
    feesPaid: 45,
    receiptNumber: 'REC-REV-2026-44021',
    officerRemarks: 'Field inquiry verified by Patwari. Digital signature affixed under IT Act 2000.',
    timeline: [
      {
        title: 'Application Submitted',
        description: 'Application along with salary affidavit registered on E-District portal.',
        date: '12 Aug 2026, 02:30 PM',
        completed: true,
      },
      {
        title: 'Field Verification by Area Patwari',
        description: 'Patwari submitted verification report approving stated income level.',
        date: '16 Aug 2026, 11:15 AM',
        completed: true,
      },
      {
        title: 'Tehsildar Digital Approval',
        description: 'Certificate approved and e-signed with 2048-bit digital certificate.',
        date: '19 Aug 2026, 04:55 PM',
        completed: true,
      },
      {
        title: 'Pushed to DigiLocker Vault',
        description: 'Verified digital certificate linked to citizen Aadhaar.',
        date: '19 Aug 2026, 05:00 PM',
        completed: true,
      }
    ]
  },
  {
    id: 'APP-2026-99432',
    serviceId: 'passport-seva',
    serviceTitle: 'Passport Renewal (36 Pages)',
    department: 'Ministry of External Affairs (CPV Division)',
    applicantName: 'Manasvi Raut',
    aadhaarNumber: 'XXXX-XXXX-7721',
    submissionDate: '2026-08-28',
    estimatedCompletionDate: '2026-09-15',
    status: 'submitted',
    statusLabel: 'Appointment Scheduled at PSK ITO Delhi',
    currentStage: 'Document Verification Scheduled for 04 Sep 2026 (10:30 AM)',
    feesPaid: 1500,
    receiptNumber: 'REC-MEA-2026-10293',
    officerRemarks: 'Please carry original Aadhaar, 10th certificate, and old passport booklet for counter verification.',
    timeline: [
      {
        title: 'Application & Fee Submitted',
        description: 'Fee of ₹1,500 paid online. Appointment slot confirmed.',
        date: '28 Aug 2026, 09:20 AM',
        completed: true,
        current: true,
      },
      {
        title: 'Passport Seva Kendra Biometrics',
        description: 'Fingerprint scanning and photo capture at PSK counter.',
        date: 'Scheduled: 04 Sep 2026',
        completed: false,
      },
      {
        title: 'Police Clearance Verification',
        description: 'Local police station physical address confirmation.',
        completed: false,
      },
      {
        title: 'Passport Printing & Security Binding',
        description: 'Govt of India security press printing with biometric chip.',
        completed: false,
      },
      {
        title: 'Speed Post Dispatch',
        description: 'Dispatched to applicant residence via India Post.',
        completed: false,
      }
    ]
  }
];

export const INITIAL_VAULT_DOCS: VaultDocument[] = [
  {
    id: 'DOC-AADHAAR-01',
    title: 'Aadhaar Card (e-Aadhaar with QR)',
    docType: 'Identity & Address Proof',
    docNumber: 'XXXX-XXXX-4829',
    issuer: 'Unique Identification Authority of India (UIDAI)',
    issueDate: '14 May 2018',
    verified: true,
    fileSize: '420 KB',
    iconType: 'Fingerprint'
  },
  {
    id: 'DOC-PAN-02',
    title: 'Permanent Account Number (e-PAN)',
    docType: 'Tax & Financial Identity',
    docNumber: 'ABCPS****K',
    issuer: 'Income Tax Department, Govt of India',
    issueDate: '22 Jan 2019',
    verified: true,
    fileSize: '310 KB',
    iconType: 'CreditCard'
  },
  {
    id: 'DOC-DL-03',
    title: 'Digital Driving License',
    docType: 'Motor Vehicle License',
    docNumber: 'DL-04-2015-0048291',
    issuer: 'Transport Department, Govt of NCT of Delhi',
    issueDate: '18 Mar 2021',
    expiryDate: '17 Mar 2041',
    verified: true,
    fileSize: '580 KB',
    iconType: 'Car'
  },
  {
    id: 'DOC-INCOME-04',
    title: 'Income Certificate (FY 2025-26)',
    docType: 'Income & Asset Proof',
    docNumber: 'INC/DL/2026/99410',
    issuer: 'Office of the Sub-Divisional Magistrate (SDM), Delhi',
    issueDate: '19 Aug 2026',
    expiryDate: '18 Aug 2027',
    verified: true,
    fileSize: '640 KB',
    iconType: 'FileText'
  },
  {
    id: 'DOC-EDU-05',
    title: 'Class X Secondary School Certificate',
    docType: 'Educational Qualification',
    docNumber: 'CBSE/2012/6641882',
    issuer: 'Central Board of Secondary Education (CBSE)',
    issueDate: '28 May 2012',
    verified: true,
    fileSize: '1.2 MB',
    iconType: 'GraduationCap'
  }
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'PAY-2026-901',
    transactionId: 'TXN-GOI-9928104',
    serviceName: 'Passport Renewal (36 Pages Regular)',
    amount: 1500,
    date: '28 Aug 2026, 09:20 AM',
    status: 'SUCCESS',
    paymentMode: 'UPI / Bharat BillPay',
    receiptUrl: '#receipt-passport'
  },
  {
    id: 'PAY-2026-882',
    transactionId: 'TXN-GOI-8819201',
    serviceName: 'Driving License Smart Card & Renewal Fee',
    amount: 350,
    date: '24 Aug 2026, 10:14 AM',
    status: 'SUCCESS',
    paymentMode: 'RuPay Debit Card',
    receiptUrl: '#receipt-dl'
  },
  {
    id: 'PAY-2026-724',
    transactionId: 'TXN-GOI-7718290',
    serviceName: 'E-District Income Certificate Processing Fee',
    amount: 45,
    date: '12 Aug 2026, 02:30 PM',
    status: 'SUCCESS',
    paymentMode: 'Net Banking (SBI)',
    receiptUrl: '#receipt-inc'
  },
  {
    id: 'PAY-2026-610',
    transactionId: 'TXN-GOI-6610992',
    serviceName: 'PVC Aadhaar Card Reprint & Speed Post Charge',
    amount: 50,
    date: '05 Jul 2026, 11:05 AM',
    status: 'SUCCESS',
    paymentMode: 'UPI / BHIM',
    receiptUrl: '#receipt-aadhaar'
  }
];

export const INITIAL_GRIEVANCES: GrievanceTicket[] = [
  {
    id: 'GRV-CPGRAMS-2026-4491',
    department: 'Department of Telecommunications / BSNL Broadband',
    category: 'Delayed Optical Fiber Line Relocation',
    subject: 'Request for optical fiber cable shifting pending over 20 days',
    description: 'Applied for shifting of FTTH broadband connection at Shanti Nagar. Work order generated on 10th Aug but local SDO office has not dispatched technical crew despite multiple follow-ups.',
    filedDate: '20 Aug 2026',
    status: 'IN_PROGRESS',
    statusLabel: 'Forwarded to Divisional Engineer (External)',
    slaDaysRemaining: 7,
    assignedOfficer: 'Er. V. K. Saxena (Divisional Engineer)',
    attachmentName: 'application_receipt_bsnl.pdf',
    updates: [
      {
        date: '20 Aug 2026, 04:00 PM',
        stage: 'Grievance Registered on National CPGRAMS Portal',
        remarks: 'Automated acknowledgment sent to citizen via SMS and Email.',
      },
      {
        date: '22 Aug 2026, 11:30 AM',
        stage: 'Assigned to Nodal Officer, DoT North Zone',
        remarks: 'Officer reviewed complaint details and verified connection account details.',
      },
      {
        date: '25 Aug 2026, 02:15 PM',
        stage: 'Site Inspection Instruction Issued to Field SDO',
        remarks: 'Target completion time fixed within 7 working days.',
      }
    ]
  },
  {
    id: 'GRV-CPGRAMS-2026-2108',
    department: 'Ministry of Consumer Affairs / Food & Public Distribution',
    category: 'FPS Ration Card Aadhaar Seeding Delay',
    subject: 'Fair Price Shop biometric terminal unable to authenticate biometric seeding',
    description: 'Ration card member addition completed online but local Fair Price Shop (FPS 104) dealer refused foodgrain entitlement stating offline server synchronization pending.',
    filedDate: '02 Jul 2026',
    status: 'RESOLVED',
    statusLabel: 'Redressed & Entitlement Restored',
    slaDaysRemaining: 0,
    assignedOfficer: 'District Food Supply Officer (DFSO)',
    attachmentName: 'ration_slip_screenshot.png',
    updates: [
      {
        date: '02 Jul 2026, 10:10 AM',
        stage: 'Grievance Logged',
        remarks: 'Registered under Public Distribution System grievance cell.',
      },
      {
        date: '05 Jul 2026, 03:20 PM',
        stage: 'Inspection & PoS Terminal Resynchronization',
        remarks: 'Inspector visited FPS 104 and updated the central database server cache.',
      },
      {
        date: '08 Jul 2026, 05:00 PM',
        stage: 'Citizen Confirmation Received & Case Closed',
        remarks: 'Citizen confirmed successful grain collection via biometric e-PoS device.',
      }
    ]
  }
];

export const FAQS_LIST: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'General',
    question: 'What is SEVA 1 and how does it connect Central and State services?',
    answer: 'SEVA 1 (Single Electronic Window for All) is the Government of India’s apex unified digital governance gateway. It aggregates over 1,400+ citizen services across central ministries, state departments, and municipal corporations into one single sign-on experience linked with DigiLocker and Aadhaar e-KYC.'
  },
  {
    id: 'faq-2',
    category: 'Tracking',
    question: 'How do I track my submitted application status?',
    answer: 'You can track any application in real-time by entering your unique Application Reference ID in the "Track Application" search bar on the homepage or in your Citizen Dashboard. You will receive step-by-step progress tracking, officer notes, and expected completion dates.'
  },
  {
    id: 'faq-3',
    category: 'DigiLocker',
    question: 'Are documents stored in the Document Vault legally valid?',
    answer: 'Yes! All digital certificates issued through the SEVA 1 Document Vault / DigiLocker ecosystem are legally valid and recognized on par with original physical documents under Rule 9A of the Information Technology (Preservation and Retention of Information by Intermediaries Providing Digital Locker Facilities) Rules, 2016.'
  },
  {
    id: 'faq-4',
    category: 'Schemes',
    question: 'How does the Scheme Eligibility Checker work?',
    answer: 'The Scheme Eligibility tool checks your demographic parameters such as annual household income, occupation, age, gender, and state of residence against official government scheme guidelines to instantly recommend the exact welfare benefits you are eligible to claim.'
  },
  {
    id: 'faq-5',
    category: 'Grievances',
    question: 'What is CPGRAMS and what is the maximum resolution SLA?',
    answer: 'CPGRAMS (Centralised Public Grievance Redress and Monitoring System) is an online 24x7 grievance platform. Grievances filed on SEVA 1 are directly mapped to the respective Ministry Nodal Officer with a strict time-bound SLA of 21 working days for redressal and mandatory action-taken reports.'
  },
  {
    id: 'faq-6',
    category: 'Payments',
    question: 'What payment modes are supported for government fees and stamp duties?',
    answer: 'SEVA 1 supports Bharat BillPay, UPI (BHIM, Google Pay, PhonePe, Paytm), RuPay debit cards, Visa/Mastercard, Net Banking across all 54 scheduled public & private commercial banks, as well as offline SBI e-Challan generation.'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'DL Renewal Update',
    message: 'Your Driving License renewal (APP-2026-88219) has cleared scrutiny at RTO Delhi West.',
    timestamp: '2 hours ago',
    read: false,
    type: 'info'
  },
  {
    id: 'notif-2',
    title: 'DigiLocker Certificate Synced',
    message: 'Annual Income Certificate FY 2025-26 has been deposited in your Document Vault.',
    timestamp: '1 day ago',
    read: false,
    type: 'success'
  },
  {
    id: 'notif-3',
    title: 'PM Kisan 19th Installment Credited',
    message: '₹2,000 Direct Benefit Transfer credited to your Aadhaar-linked SBI bank account.',
    timestamp: '3 days ago',
    read: true,
    type: 'success'
  }
];
