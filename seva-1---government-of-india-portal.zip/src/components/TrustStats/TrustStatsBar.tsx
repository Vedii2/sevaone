import React, { useState, useEffect, useRef } from 'react';
import { LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import { Users, FileCheck2, Award, IndianRupee, Smile } from 'lucide-react';

interface TrustStatsBarProps {
  currentLanguage: LanguageCode;
}

export const TrustStatsBar: React.FC<TrustStatsBarProps> = ({ currentLanguage }) => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Trigger count-up animation ONCE when scrolled into viewport
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated) {
          setHasAnimated(true);
        }
      },
      { threshold: 0.25 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, [hasAnimated]);

  // Hook for animated counter values
  const useCounter = (endValue: number, duration: number = 1800, decimals: number = 1) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (!hasAnimated) return;

      let startTimestamp: number | null = null;
      const step = (timestamp: number) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        // Easing function: easeOutExpo
        const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
        setCount(parseFloat((easeProgress * endValue).toFixed(decimals)));

        if (progress < 1) {
          window.requestAnimationFrame(step);
        }
      };

      window.requestAnimationFrame(step);
    }, [hasAnimated, endValue, duration, decimals]);

    return count;
  };

  const registeredVal = useCounter(48.7, 1800, 1);
  const appsVal = useCounter(124.6, 2000, 1);
  const approvedVal = useCounter(98.4, 1600, 1);
  const paymentsVal = useCounter(18420, 2200, 0);
  const satisfactionVal = useCounter(96.8, 1700, 1);

  const stats = [
    {
      id: 'registered',
      icon: Users,
      value: `${registeredVal} Cr+`,
      label: t.statsRegisteredUsers,
      sublabel: 'Aadhaar Verified Profiles',
      color: 'text-[#1D5FE0]',
      bgColor: 'bg-blue-500/10 border-blue-400/20',
    },
    {
      id: 'applications',
      icon: FileCheck2,
      value: `${appsVal} Cr+`,
      label: t.statsAppsSubmitted,
      sublabel: 'Central & State Portals',
      color: 'text-[#F5893C]',
      bgColor: 'bg-orange-500/10 border-orange-400/20',
    },
    {
      id: 'approved',
      icon: Award,
      value: `${approvedVal}%`,
      label: t.statsAppsApproved,
      sublabel: 'Direct Delivery Rate',
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-400/20',
    },
    {
      id: 'payments',
      icon: IndianRupee,
      value: `₹${paymentsVal.toLocaleString('en-IN')} Cr+`,
      label: t.statsPaymentsProcessed,
      sublabel: 'DBT Transfers & BillPay',
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10 border-purple-400/20',
    },
    {
      id: 'satisfaction',
      icon: Smile,
      value: `${satisfactionVal}%`,
      label: t.statsCitizenSatisfaction,
      sublabel: 'National Feedback Rating',
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-400/20',
    },
  ];

  return (
    <section
      ref={containerRef}
      className="py-12 bg-[#0A1F44] text-white relative overflow-hidden"
      aria-label="Government Public Service Statistics"
    >
      {/* Background ambient lighting */}
      <div className="absolute -top-24 left-1/4 w-96 h-96 bg-[#1D5FE0]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 right-1/4 w-96 h-96 bg-[#F5893C]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 sm:gap-8 items-center text-center">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={stat.id}
                className={`flex flex-col items-center p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs transition-all duration-300 hover:bg-white/10 ${
                  idx === 4 ? 'col-span-2 md:col-span-1' : ''
                }`}
              >
                {/* Metric Icon */}
                <div
                  className={`w-12 h-12 rounded-2xl ${stat.bgColor} border flex items-center justify-center mb-3 shadow-inner`}
                >
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>

                {/* Large Bold Metric Number */}
                <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight font-sans">
                  {stat.value}
                </div>

                {/* Main Label */}
                <div className="text-xs sm:text-sm font-bold text-slate-200 mt-1.5">
                  {stat.label}
                </div>

                {/* Small Subtext */}
                <div className="text-[11px] text-slate-400 font-medium mt-0.5">
                  {stat.sublabel}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
