import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import {
  QrCode,
  ShieldCheck,
  Clock,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Building2,
  ArrowLeft,
  Copy,
  Check,
  Sparkles,
  Smartphone,
  Lock,
  ExternalLink
} from 'lucide-react';
import { ServiceItem } from '../../types';

interface UpiQrPaymentSectionProps {
  service: ServiceItem;
  applicationId: string;
  transactionRef: string;
  applicantName: string;
  onPaymentSuccess: (details: { paymentMode: string; txnRef: string; timestamp: string }) => void;
  onSwitchToAlternativePayment: () => void;
  onBack: () => void;
}

export type PaymentStatus = 'waiting' | 'verifying' | 'success' | 'expired' | 'failed';

export const UpiQrPaymentSection: React.FC<UpiQrPaymentSectionProps> = ({
  service,
  applicationId,
  transactionRef,
  applicantName,
  onPaymentSuccess,
  onSwitchToAlternativePayment,
  onBack,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [timeLeft, setTimeLeft] = useState<number>(300); // 5 minutes
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('waiting');
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);
  const [currentTxnRef, setCurrentTxnRef] = useState<string>(transactionRef);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const payeeVpa = 'treasury.gov@sbi';
  const payeeName = `Govt of India - ${service.department.replace(/[^a-zA-Z0-9 ]/g, '').slice(0, 24)}`;
  const note = `Fee for ${service.title.slice(0, 24)} (${applicationId})`;

  // Standard UPI URI format accepted by all Indian UPI applications (NPCI specification)
  const upiUri = `upi://pay?pa=${encodeURIComponent(payeeVpa)}&pn=${encodeURIComponent(payeeName)}&am=${service.fee.toFixed(2)}&cu=INR&tn=${encodeURIComponent(note)}&tr=${encodeURIComponent(currentTxnRef)}`;

  // Generate QR Code on mount or whenever transaction changes
  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(upiUri, {
      width: 320,
      margin: 2,
      color: {
        dark: '#0A1F44',
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'H',
    })
      .then((url) => {
        if (isMounted) {
          setQrDataUrl(url);
        }
      })
      .catch((err) => {
        console.error('QR Code Generation Error:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [upiUri]);

  // Countdown timer effect
  useEffect(() => {
    if (paymentStatus === 'success' || paymentStatus === 'verifying') return;

    if (timeLeft <= 0) {
      setPaymentStatus('expired');
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setPaymentStatus('expired');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timeLeft, paymentStatus]);

  // Handle Refresh QR Code
  const handleRefreshQr = () => {
    const newRef = `TXN-UPI-${Math.floor(10000000 + Math.random() * 90000000)}`;
    setCurrentTxnRef(newRef);
    setTimeLeft(300);
    setPaymentStatus('waiting');
  };

  // Copy VPA to clipboard
  const handleCopyVpa = () => {
    navigator.clipboard?.writeText(payeeVpa);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  // Simulate Payment Successful trigger
  const handleSimulatePayment = () => {
    if (paymentStatus === 'expired') return;

    setPaymentStatus('verifying');

    setTimeout(() => {
      setPaymentStatus('success');

      setTimeout(() => {
        onPaymentSuccess({
          paymentMode: 'Bharat BillPay UPI QR (NPCI)',
          txnRef: currentTxnRef,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        });
      }, 1200);
    }, 1500);
  };

  // Format timer into MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const timerPercentage = (timeLeft / 300) * 100;

  return (
    <div className="space-y-5 text-xs sm:text-sm animate-in fade-in duration-200">
      
      {/* 1. Header with Government Department & Fee Amount */}
      <div className="bg-gradient-to-r from-[#0A1F44] via-[#102a5c] to-[#1D5FE0] text-white p-4 sm:p-5 rounded-2xl shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-blue-200">
              National Single Window Gateway • Bharat BillPay
            </span>
          </div>
          <div className="flex items-center space-x-1 text-[11px] bg-white/10 px-2.5 py-1 rounded-md text-emerald-300 font-bold border border-white/10">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>NPCI Encrypted</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-white/10">
          <div>
            <span className="text-[11px] text-blue-200 uppercase font-semibold">
              {service.department}
            </span>
            <h3 className="text-base sm:text-lg font-extrabold text-white leading-tight">
              {service.title}
            </h3>
            <p className="text-[11px] text-blue-100/80 font-mono mt-0.5">
              Ref ID: <span className="text-white font-bold">{applicationId}</span>
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-xl border border-white/15 text-right shrink-0">
            <div className="text-[10px] text-blue-200 uppercase font-bold tracking-wider">
              Total Amount Payable
            </div>
            <div className="text-2xl font-black text-white">
              ₹{service.fee}.00
            </div>
            <div className="text-[10px] text-emerald-300 font-semibold">
              0% Gateway Convenience Fee
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Centered QR Code Box with Quiet Zone & Live Scanner */}
      <div className="bg-slate-50 p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col items-center justify-center space-y-4 relative overflow-hidden">
        
        {/* Step Context Title */}
        <div className="text-center space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-50 text-[#1D5FE0] border border-blue-200 text-xs font-extrabold">
            <QrCode className="w-4 h-4" />
            <span>Scan UPI QR Code to Pay</span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Open any UPI app on your phone (GPay, PhonePe, Paytm, BHIM) and point your camera to pay.
          </p>
        </div>

        {/* QR Code Canvas with Frame Markers & High Contrast */}
        <div className="relative p-4 bg-white rounded-2xl shadow-md border-2 border-slate-200 group">
          
          {/* Decorative Corner Registration Markers */}
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#1D5FE0]" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#1D5FE0]" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#1D5FE0]" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#1D5FE0]" />

          {/* QR Image with Quiet Zone */}
          <div className="relative w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center overflow-hidden rounded-xl bg-white">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="Government Services UPI Payment QR Code"
                className={`w-full h-full object-contain transition-all duration-300 ${
                  paymentStatus === 'expired' ? 'blur-xs opacity-30 grayscale' : ''
                } ${paymentStatus === 'success' ? 'opacity-20' : ''}`}
              />
            ) : (
              <div className="flex flex-col items-center justify-center space-y-2 text-slate-400">
                <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
                <span className="text-xs font-semibold">Generating Dynamic UPI QR...</span>
              </div>
            )}

            {/* Waiting Laser Line Scanner Effect */}
            {paymentStatus === 'waiting' && qrDataUrl && (
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#1D5FE0] to-transparent opacity-80 animate-pulse pointer-events-none shadow-[0_0_8px_#1D5FE0]" />
            )}

            {/* Overlays for Verification, Success or Expired */}
            {paymentStatus === 'verifying' && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center space-y-2 animate-in fade-in">
                <div className="w-12 h-12 rounded-full border-4 border-[#1D5FE0] border-t-transparent animate-spin" />
                <div className="font-extrabold text-sm text-[#0A1F44]">
                  Verifying Payment...
                </div>
                <p className="text-[11px] text-slate-500">
                  Confirming transaction reference with NPCI Gateway
                </p>
              </div>
            )}

            {paymentStatus === 'success' && (
              <div className="absolute inset-0 bg-emerald-50/95 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center space-y-2 animate-in zoom-in-95">
                <div className="w-14 h-14 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <div className="font-black text-base text-emerald-900">
                  Payment Successful ✓
                </div>
                <div className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded">
                  {currentTxnRef}
                </div>
                <p className="text-[11px] text-emerald-700 font-medium">
                  Redirecting to Official Acknowledgment...
                </p>
              </div>
            )}

            {paymentStatus === 'expired' && (
              <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center space-y-2.5 text-white animate-in fade-in">
                <div className="w-10 h-10 rounded-full bg-rose-500/20 border border-rose-400 text-rose-300 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div className="font-extrabold text-sm text-white">
                  QR Code Expired
                </div>
                <p className="text-[11px] text-slate-300 max-w-[180px]">
                  For your security, UPI payment sessions expire in 5 minutes.
                </p>
                <button
                  onClick={handleRefreshQr}
                  className="mt-1 bg-[#1D5FE0] hover:bg-blue-600 text-white text-xs font-bold px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 shadow-sm active:scale-95 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Refresh QR Code</span>
                </button>
              </div>
            )}
          </div>

          {/* Central Logo Stamp */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 py-1 rounded-md shadow-md border border-slate-200 pointer-events-none flex items-center space-x-1">
            <span className="text-[10px] font-black text-[#0A1F44] tracking-tight">BHIM</span>
            <span className="text-[10px] font-black text-[#F5893C]">UPI</span>
          </div>
        </div>

        {/* 3. Live Countdown Timer & Refresh Option */}
        <div className="w-full max-w-sm space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-1.5 font-bold text-slate-600">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>
                {paymentStatus === 'expired' ? (
                  <span className="text-rose-600">Expired</span>
                ) : (
                  <>
                    Valid for: <span className="text-blue-700 font-mono font-extrabold">{formatTime(timeLeft)}</span>
                  </>
                )}
              </span>
            </div>

            <button
              onClick={handleRefreshQr}
              className="text-xs text-[#1D5FE0] hover:text-[#0A1F44] font-bold flex items-center space-x-1 hover:underline transition-colors"
              title="Generate fresh transaction reference"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Refresh QR</span>
            </button>
          </div>

          {/* Smooth Timer Progress Bar */}
          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 rounded-full ${
                timeLeft < 60 ? 'bg-rose-500' : 'bg-[#1D5FE0]'
              }`}
              style={{ width: `${timerPercentage}%` }}
            />
          </div>
        </div>

        {/* 4. Supported UPI Payment Apps */}
        <div className="pt-2 border-t border-slate-200/80 w-full max-w-md text-center space-y-2">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Accepted by All Major UPI Apps
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {[
              { name: 'Google Pay', color: 'bg-white text-slate-700 border-slate-200' },
              { name: 'PhonePe', color: 'bg-purple-50 text-purple-700 border-purple-200 font-bold' },
              { name: 'Paytm UPI', color: 'bg-sky-50 text-sky-700 border-sky-200 font-bold' },
              { name: 'BHIM UPI', color: 'bg-emerald-50 text-emerald-700 border-emerald-200 font-bold' },
              { name: 'Cred UPI', color: 'bg-slate-100 text-slate-800 border-slate-300 font-bold' },
              { name: 'Any Bank App', color: 'bg-white text-slate-600 border-slate-200' },
            ].map((app) => (
              <span
                key={app.name}
                className={`text-[11px] px-2.5 py-1 rounded-lg border shadow-2xs ${app.color}`}
              >
                {app.name}
              </span>
            ))}
          </div>
        </div>

        {/* 5. UPI ID / VPA string copy helper */}
        <div className="flex items-center justify-between bg-white px-3.5 py-2 rounded-xl border border-slate-200 text-xs w-full max-w-sm">
          <div className="flex items-center space-x-2 text-slate-600 truncate">
            <span className="text-slate-400 font-semibold">UPI ID:</span>
            <span className="font-mono font-bold text-slate-800">{payeeVpa}</span>
          </div>
          <button
            onClick={handleCopyVpa}
            className="text-xs text-[#1D5FE0] hover:text-blue-800 font-bold flex items-center space-x-1 pl-2 transition-colors"
            title="Copy UPI ID"
          >
            {copiedUpi ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>

        {/* 6. Instant Demo Simulation Trigger */}
        <div className="w-full max-w-sm pt-1">
          <button
            type="button"
            onClick={handleSimulatePayment}
            disabled={paymentStatus === 'verifying' || paymentStatus === 'success' || paymentStatus === 'expired'}
            className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center space-x-2 transition-all active:scale-[0.98]"
          >
            <Smartphone className="w-4 h-4" />
            <span>Simulate Mobile UPI Payment (Instant Test)</span>
          </button>
        </div>

      </div>

      {/* 7. Bottom Navigation & Fallback Option */}
      <div className="pt-3 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-200">
        <button
          type="button"
          onClick={onBack}
          className="w-full sm:w-auto px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl flex items-center justify-center space-x-1.5 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Documents</span>
        </button>

        <button
          type="button"
          onClick={onSwitchToAlternativePayment}
          className="w-full sm:w-auto px-4 py-2.5 text-xs font-bold text-[#1D5FE0] hover:bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-center space-x-1.5 transition-colors"
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Pay via Debit/Credit Card or Net Banking instead</span>
        </button>
      </div>

    </div>
  );
};
