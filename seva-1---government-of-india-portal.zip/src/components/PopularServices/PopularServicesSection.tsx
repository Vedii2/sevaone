import React, { useState } from 'react';
import { SERVICES_LIST } from '../../data/servicesData';
import { ServiceItem, ServiceCategory, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  Fingerprint,
  CreditCard,
  Vote,
  Car,
  Baby,
  FileText,
  ShoppingBag,
  Globe,
  Award,
  Clock,
  IndianRupee,
  ArrowRight,
  Filter,
  Check
} from 'lucide-react';

interface PopularServicesSectionProps {
  currentLanguage: LanguageCode;
  onSelectService: (service: ServiceItem) => void;
  onViewAllClick: () => void;
  selectedCategory?: ServiceCategory;
  onCategoryChange?: (cat: ServiceCategory) => void;
  showAllServices?: boolean;
}

export const PopularServicesSection: React.FC<PopularServicesSectionProps> = ({
  currentLanguage,
  onSelectService,
  onViewAllClick,
  selectedCategory = 'all',
  onCategoryChange,
  showAllServices = false,
}) => {
  const [internalCategory, setInternalCategory] = useState<ServiceCategory>(selectedCategory);
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const activeCategory = onCategoryChange ? selectedCategory : internalCategory;
  const handleCategorySelect = (cat: ServiceCategory) => {
    if (onCategoryChange) {
      onCategoryChange(cat);
    } else {
      setInternalCategory(cat);
    }
  };

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Fingerprint':
        return Fingerprint;
      case 'CreditCard':
        return CreditCard;
      case 'Vote':
        return Vote;
      case 'Car':
        return Car;
      case 'Baby':
        return Baby;
      case 'FileText':
        return FileText;
      case 'ShoppingBag':
        return ShoppingBag;
      case 'Globe':
        return Globe;
      case 'Award':
      default:
        return Award;
    }
  };

  const categories = [
    { id: 'all' as ServiceCategory, label: 'All Services' },
    { id: 'identity' as ServiceCategory, label: 'Identity & Citizen' },
    { id: 'revenue' as ServiceCategory, label: 'Certificates & Revenue' },
    { id: 'transport' as ServiceCategory, label: 'Transport & Driving' },
    { id: 'welfare' as ServiceCategory, label: 'Public Welfare' },
  ];

  // If showing popular only (e.g. on homepage), take top services; if in "View All" mode, take filtered list
  const displayServices = showAllServices
    ? SERVICES_LIST.filter((s) => activeCategory === 'all' || s.category === activeCategory)
    : SERVICES_LIST.slice(0, 8);

  return (
    <section id="services-section" className="py-16 bg-[#F3F6F9] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-[#1D5FE0] mb-1">
              <span>National Single Window</span>
              <span className="text-slate-300">•</span>
              <span className="text-emerald-700">Central & State Portals</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0A1F44] tracking-tight">
              {showAllServices ? 'All Public Services Catalog' : t.popularServices}
            </h2>
          </div>

          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            {!showAllServices ? (
              <button
                onClick={onViewAllClick}
                className="inline-flex items-center space-x-2 text-sm font-bold text-[#1D5FE0] hover:text-[#0A1F44] bg-white hover:bg-slate-50 px-5 py-2.5 rounded-xl transition-all border border-slate-200 shadow-2xs hover:shadow-sm"
              >
                <span>{t.viewAll} ({SERVICES_LIST.length})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <span className="text-xs text-slate-500 font-medium">
                Showing {displayServices.length} verified government services
              </span>
            )}
          </div>
        </div>

        {/* Category Filter Pills (When in view all mode or for easy filtering) */}
        {showAllServices && (
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            {categories.map((cat) => {
              const isSelected = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                    isSelected
                      ? 'bg-[#0A1F44] text-white border-[#0A1F44] shadow-md'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200 shadow-2xs'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Responsive Grid of Service Tiles with Editorial Aesthetic */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {displayServices.map((service) => {
            const Icon = getServiceIcon(service.iconName);
            return (
              <div
                key={service.id}
                onClick={() => onSelectService(service)}
                className="group bg-white rounded-2xl p-6 border border-slate-200/90 hover:border-[#1D5FE0]/50 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer transform hover:-translate-y-1"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onSelectService(service);
                  }
                }}
                aria-label={`Apply for ${service.title}`}
              >
                <div>
                  {/* Top: Icon Badge & Category Tag */}
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#1D5FE0] border border-blue-100 flex items-center justify-center group-hover:bg-[#1D5FE0] group-hover:text-white transition-all shrink-0">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-bold text-slate-600 bg-slate-100/80 border border-slate-200/80 px-2.5 py-1 rounded-lg text-right shrink-0">
                      {service.categoryLabel}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-[#0A1F44] group-hover:text-[#1D5FE0] transition-colors line-clamp-1">
                    {service.title}
                  </h3>

                  {/* Department / Authority */}
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1 font-medium">
                    {service.department}
                  </p>

                  {/* Description */}
                  <p className="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                    {service.description}
                  </p>
                </div>

                {/* Bottom Meta: Processing time, Fee & Apply Action */}
                <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1 text-slate-500 font-medium">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-[11px]">{service.processingTime}</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-slate-800 text-xs">
                      {service.fee === 0 ? (
                        <span className="text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/60">FREE</span>
                      ) : (
                        `₹${service.fee}`
                      )}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(service);
                      }}
                      className="bg-[#1D5FE0] group-hover:bg-[#0A1F44] text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
