import React, { useState, useRef, useEffect } from 'react';
import { AshokaEmblem } from '../Common/AshokaEmblem';
import { ActiveTab, LanguageCode, UserProfile, ServiceCategory } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  Search,
  User,
  ChevronDown,
  Menu,
  X,
  FileText,
  Shield,
  Compass,
  AlertCircle,
  HelpCircle,
  FolderLock,
  CreditCard,
  LogOut,
  Bell,
  CheckCircle2,
  PhoneCall,
  BookOpen,
  MessageSquare
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  currentLanguage: LanguageCode;
  user: UserProfile;
  onLoginClick?: () => void;
  onLogoutClick?: () => void;
  onOpenLoginModal?: () => void;
  onLogout?: () => void;
  onOpenSearch?: () => void;
  onSelectServiceCategory: (category: ServiceCategory) => void;
  onOpenHelpModal?: (type: 'faq' | 'manual' | 'feedback' | 'contact') => void;
  onOpenAiAssistant?: () => void;
  unreadNotificationsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  currentLanguage,
  user,
  onLoginClick,
  onLogoutClick,
  onOpenLoginModal,
  onLogout,
  onOpenSearch,
  onSelectServiceCategory,
  onOpenHelpModal = (_type?: 'faq' | 'manual' | 'feedback' | 'contact') => {},
  onOpenAiAssistant = () => {},
  unreadNotificationsCount = 0,
}) => {
  const handleLogin = onLoginClick || onOpenLoginModal || (() => {});
  const handleLogout = onLogoutClick || onLogout || (() => {});

  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const servicesRef = useRef<HTMLDivElement>(null);
  const helpRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Handle outside clicks to close dropdowns
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (servicesRef.current && !servicesRef.current.contains(target)) {
        setIsServicesOpen(false);
      }
      if (helpRef.current && !helpRef.current.contains(target)) {
        setIsHelpOpen(false);
      }
      if (userRef.current && !userRef.current.contains(target)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard navigation for dropdowns (Escape closes, etc.)
  const handleKeyDown = (e: React.KeyboardEvent, dropdownSetter: (v: boolean) => void) => {
    if (e.key === 'Escape') {
      dropdownSetter(false);
    }
  };

  const serviceDropdownCategories = [
    {
      id: 'identity' as ServiceCategory,
      title: 'Identity & Citizen Services',
      desc: 'Aadhaar, PAN Card, Voter ID, Passport Seva',
      icon: Shield,
    },
    {
      id: 'revenue' as ServiceCategory,
      title: 'Revenue, Certificates & Tax',
      desc: 'Income, Birth, Caste & Domicile Certificates',
      icon: FileText,
    },
    {
      id: 'transport' as ServiceCategory,
      title: 'Transport & Highways (Sarathi)',
      desc: 'Driving License, Vehicle RC, Fitness Certificate',
      icon: Compass,
    },
    {
      id: 'welfare' as ServiceCategory,
      title: 'Public Welfare & Distribution',
      desc: 'Ration Card, Pension & Social Security',
      icon: CheckCircle2,
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white text-slate-800 shadow-xs border-b border-slate-200/90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Emblem Brand Section */}
          <div
            onClick={() => onTabChange('home')}
            className="flex items-center space-x-3.5 cursor-pointer group shrink-0 select-none"
            role="button"
            tabIndex={0}
            aria-label="SEVA 1 Portal Home"
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                onTabChange('home');
              }
            }}
          >
            <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-200 group-hover:border-[#1D5FE0] transition-colors flex items-center justify-center shrink-0">
              <AshokaEmblem size="md" variant="gold" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center space-x-1.5 sm:space-x-2">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-[#0A1F44] leading-none font-sans flex items-center">
                  SEVA <span className="text-[#1D5FE0] ml-1">1</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                  Gov.in
                </span>
              </div>
              <div className="flex items-center space-x-1.5 text-[10px] text-slate-500 font-semibold tracking-wide hidden sm:flex mt-0.5">
                <span className="text-[#B45309] font-bold font-serif">सत्यमेव जयते</span>
                <span className="text-slate-300">•</span>
                <span className="uppercase tracking-widest">{t.tagline}</span>
              </div>
            </div>
          </div>

          {/* Center Navigation Links (Editorial Aesthetic: bold uppercase tracking-tight) */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2 text-[14px] font-bold uppercase tracking-tight text-slate-700" aria-label="Main Navigation">
            {/* Home */}
            <button
              onClick={() => onTabChange('home')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'home'
                  ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                  : 'hover:text-[#1D5FE0] hover:bg-slate-50'
              }`}
            >
              {t.home}
            </button>

            {/* Services (Dropdown) */}
            <div
              className="relative"
              ref={servicesRef}
              onKeyDown={(e) => handleKeyDown(e, setIsServicesOpen)}
            >
              <button
                onClick={() => {
                  setIsServicesOpen(!isServicesOpen);
                  setIsHelpOpen(false);
                }}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'services' || isServicesOpen
                    ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                    : 'hover:text-[#1D5FE0] hover:bg-slate-50'
                }`}
                aria-expanded={isServicesOpen}
                aria-haspopup="true"
              >
                <span>{t.services}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isServicesOpen ? 'rotate-180 text-[#1D5FE0]' : ''}`} />
              </button>

              {isServicesOpen && (
                <div
                  className="absolute left-0 mt-2 w-80 bg-white border border-slate-200 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  role="menu"
                  aria-orientation="vertical"
                >
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0A1F44] uppercase tracking-wider">
                      Explore Public Services
                    </span>
                    <button
                      onClick={() => {
                        onTabChange('services');
                        setIsServicesOpen(false);
                      }}
                      className="text-xs text-[#1D5FE0] hover:underline font-bold"
                    >
                      {t.viewAll}
                    </button>
                  </div>
                  <div className="p-1">
                    {serviceDropdownCategories.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            onSelectServiceCategory(item.id);
                            onTabChange('services');
                            setIsServicesOpen(false);
                          }}
                          className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-slate-50 flex items-start space-x-3 transition-colors group"
                          role="menuitem"
                        >
                          <div className="p-2 rounded-lg bg-blue-50 text-[#1D5FE0] group-hover:bg-[#1D5FE0] group-hover:text-white transition-colors">
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-slate-800 group-hover:text-[#1D5FE0] transition-colors">
                              {item.title}
                            </div>
                            <div className="text-xs text-slate-500 line-clamp-1 normal-case font-normal">
                              {item.desc}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Schemes */}
            <button
              onClick={() => onTabChange('schemes')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'schemes'
                  ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                  : 'hover:text-[#1D5FE0] hover:bg-slate-50'
              }`}
            >
              {t.schemes}
            </button>

            {/* Track Application */}
            <button
              onClick={() => onTabChange('track')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'track'
                  ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                  : 'hover:text-[#1D5FE0] hover:bg-slate-50'
              }`}
            >
              {t.trackApp}
            </button>

            {/* Citizen Dashboard */}
            <button
              onClick={() => onTabChange('dashboard')}
              className={`px-3 py-1.5 rounded-lg transition-all relative ${
                activeTab === 'dashboard'
                  ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                  : 'hover:text-[#1D5FE0] hover:bg-slate-50'
              }`}
            >
              <span>{t.dashboard}</span>
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#F5893C] text-white font-bold text-[10px] rounded-full flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Grievances (CPGRAMS) */}
            <button
              onClick={() => onTabChange('grievances')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeTab === 'grievances'
                  ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                  : 'hover:text-[#1D5FE0] hover:bg-slate-50'
              }`}
            >
              {t.grievances}
            </button>

            {/* Help (Dropdown) */}
            <div
              className="relative"
              ref={helpRef}
              onKeyDown={(e) => handleKeyDown(e, setIsHelpOpen)}
            >
              <button
                onClick={() => {
                  setIsHelpOpen(!isHelpOpen);
                  setIsServicesOpen(false);
                }}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'help' || isHelpOpen
                    ? 'text-[#1D5FE0] bg-blue-50/80 font-extrabold border-b-2 border-[#1D5FE0]'
                    : 'hover:text-[#1D5FE0] hover:bg-slate-50'
                }`}
                aria-expanded={isHelpOpen}
                aria-haspopup="true"
              >
                <span>{t.help}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isHelpOpen ? 'rotate-180 text-[#1D5FE0]' : ''}`} />
              </button>

              {isHelpOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  role="menu"
                >
                  <button
                    onClick={() => {
                      onOpenHelpModal('faq');
                      setIsHelpOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0] normal-case"
                  >
                    <HelpCircle className="w-4 h-4 text-amber-500" />
                    <span className="font-medium">Frequently Asked Questions</span>
                  </button>
                  <button
                    onClick={() => {
                      onOpenHelpModal('manual');
                      setIsHelpOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0] normal-case"
                  >
                    <BookOpen className="w-4 h-4 text-[#1D5FE0]" />
                    <span className="font-medium">User Manual & Guide</span>
                  </button>
                  <button
                    onClick={() => {
                      onOpenHelpModal('feedback');
                      setIsHelpOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0] normal-case"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span className="font-medium">Citizen Feedback & Rating</span>
                  </button>
                  <div className="border-t border-slate-100 my-1" />
                  <button
                    onClick={() => {
                      onOpenHelpModal('contact');
                      setIsHelpOpen(false);
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0] normal-case"
                  >
                    <PhoneCall className="w-4 h-4 text-rose-500" />
                    <span className="font-medium">Contact Us & Helplines (1800-11-SEVA)</span>
                  </button>
                </div>
              )}
            </div>
          </nav>

          <div className="hidden lg:block h-6 w-px bg-slate-200"></div>

          {/* Right Controls: Editorial Search Input & Login / User Profile */}
          <div className="flex items-center space-x-3">
            {/* Search Pill */}
            <div className="relative hidden md:block">
              <input
                type="text"
                placeholder="Search portal..."
                onClick={onOpenSearch}
                readOnly
                className="bg-slate-100 hover:bg-slate-200/80 cursor-pointer border-none rounded-full py-2 pl-4 pr-10 text-sm focus:ring-2 focus:ring-[#1D5FE0] w-36 sm:w-44 transition-all text-slate-800 placeholder-slate-400 font-medium"
              />
              <button
                onClick={onOpenSearch}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-[#1D5FE0]"
                title="Search portal (Ctrl+K)"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Search Icon */}
            <button
              onClick={onOpenSearch}
              className="p-2 rounded-full bg-slate-100 text-slate-600 md:hidden hover:bg-slate-200"
              title="Search"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Auth Flow: Login / Register OR User Profile Menu */}
            {user.isLoggedIn ? (
              <div className="relative" ref={userRef}>
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 px-3 py-1.5 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-[#1D5FE0]"
                  aria-expanded={isUserMenuOpen}
                  aria-haspopup="true"
                >
                  <div className="w-7 h-7 rounded-full bg-[#0A1F44] text-white font-bold text-xs flex items-center justify-center">
                    {user.name.charAt(0)}
                  </div>
                  <div className="text-left hidden md:block">
                    <div className="text-xs font-bold text-[#0A1F44] leading-none">
                      {user.name.split(' ')[0]}
                    </div>
                    <div className="text-[10px] text-emerald-600 font-semibold leading-tight">
                      Aadhaar Verified ✓
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {isUserMenuOpen && (
                  <div
                    className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                    role="menu"
                  >
                    <div className="px-4 py-2 border-b border-slate-100">
                      <div className="text-sm font-bold text-[#0A1F44]">{user.name}</div>
                      <div className="text-xs text-slate-500">{user.email}</div>
                      <div className="mt-1 text-[11px] text-emerald-600 font-semibold flex items-center space-x-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>DigiLocker & Aadhaar Linked</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onTabChange('dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0]"
                    >
                      <User className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">Citizen Profile & Activity</span>
                    </button>

                    <button
                      onClick={() => {
                        onTabChange('vault');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0]"
                    >
                      <FolderLock className="w-4 h-4 text-emerald-600" />
                      <span className="font-medium">Document Vault (DigiLocker)</span>
                    </button>

                    <button
                      onClick={() => {
                        onTabChange('payments');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center space-x-3 text-sm text-slate-700 hover:text-[#1D5FE0]"
                    >
                      <CreditCard className="w-4 h-4 text-amber-500" />
                      <span className="font-medium">Payment History & Receipts</span>
                    </button>

                    <div className="border-t border-slate-100 my-1" />

                    <button
                      onClick={() => {
                        handleLogout();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 hover:bg-rose-50 text-rose-600 flex items-center space-x-3 text-sm font-semibold transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t.logout}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={handleLogin}
                className="bg-[#0A1F44] hover:bg-[#1D5FE0] active:scale-95 text-white px-5 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-bold shadow-lg shadow-blue-900/20 transition-all flex items-center space-x-2"
              >
                <User className="w-3.5 h-3.5" />
                <span>{t.loginRegister}</span>
              </button>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 lg:hidden transition-colors"
              aria-label="Toggle Navigation Menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-200 px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top duration-200 shadow-xl">
          <button
            onClick={() => {
              onTabChange('home');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'home' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.home}
          </button>

          <button
            onClick={() => {
              onTabChange('services');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'services' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.services}
          </button>

          <button
            onClick={() => {
              onTabChange('schemes');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'schemes' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.schemes}
          </button>

          <button
            onClick={() => {
              onTabChange('track');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'track' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.trackApp}
          </button>

          <button
            onClick={() => {
              onTabChange('dashboard');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'dashboard' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.dashboard}
          </button>

          <button
            onClick={() => {
              onTabChange('grievances');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'grievances' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.grievances}
          </button>

          <button
            onClick={() => {
              onTabChange('help');
              setIsMobileMenuOpen(false);
            }}
            className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-tight ${
              activeTab === 'help' ? 'bg-blue-50 text-[#1D5FE0]' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            {t.help}
          </button>

          <div className="pt-2 border-t border-slate-200">
            {!user.isLoggedIn ? (
              <button
                onClick={() => {
                  handleLogin();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-[#0A1F44] hover:bg-[#1D5FE0] text-white py-2.5 rounded-full font-bold text-sm shadow-md"
              >
                {t.loginRegister}
              </button>
            ) : (
              <button
                onClick={() => {
                  handleLogout();
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-rose-50 text-rose-600 border border-rose-200 py-2 rounded-full font-semibold text-sm"
              >
                {t.logout} ({user.name})
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
