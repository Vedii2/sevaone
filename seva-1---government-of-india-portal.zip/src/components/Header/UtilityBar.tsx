import React, { useState, useRef, useEffect } from 'react';
import { AshokaEmblem } from '../Common/AshokaEmblem';
import { IndianFlagBadge } from '../Common/IndianFlagBadge';
import { SUPPORTED_LANGUAGES, TRANSLATIONS } from '../../data/translations';
import { LanguageCode } from '../../types';
import { Volume2, Globe, ChevronDown, Check } from 'lucide-react';

interface UtilityBarProps {
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  fontSizeScale: number; // 0.9, 1.0, 1.15
  onFontSizeChange: (scale: number) => void;
  onScreenReaderToggle: () => void;
  isScreenReaderActive: boolean;
}

export const UtilityBar: React.FC<UtilityBarProps> = ({
  currentLanguage,
  onLanguageChange,
  fontSizeScale,
  onFontSizeChange,
  onScreenReaderToggle,
  isScreenReaderActive,
}) => {
  const [isLangOpen, setIsLangOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Close dropdown when clicked outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setIsLangOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSkipToMain = (e: React.MouseEvent) => {
    e.preventDefault();
    const mainEl = document.getElementById('main-content');
    if (mainEl) {
      mainEl.tabIndex = -1;
      mainEl.focus();
      mainEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  return (
    <div className="w-full bg-[#0A1F44] text-white py-1.5 px-4 sm:px-8 flex justify-between items-center text-[11px] font-medium tracking-wide border-b border-white/10 shrink-0">
      <div className="max-w-7xl mx-auto w-full flex flex-wrap items-center justify-between gap-y-2">
        {/* Left Side: Government of India & Emblem */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <AshokaEmblem size="sm" variant="gold" />
            <IndianFlagBadge size="sm" />
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-amber-400 font-bold font-serif text-[11px] sm:text-xs tracking-wider">
              सत्यमेव जयते
            </span>
            <span className="text-white/40 hidden sm:inline">•</span>
            <span className="uppercase text-slate-200 text-xs sm:text-[12px] font-semibold tracking-wider">
              {t.govOfIndia}
            </span>
          </div>
        </div>

        {/* Right Side: Accessibility Controls, Font Scaler & Language Selector */}
        <div className="flex items-center space-x-3 sm:space-x-5 flex-wrap">
          {/* Skip to Main Content */}
          <a
            href="#main-content"
            onClick={handleSkipToMain}
            className="hover:text-blue-200 transition-colors focus:outline-none focus:ring-1 focus:ring-amber-400 rounded px-1.5 py-0.5 font-medium hidden md:inline-block"
            aria-label="Skip to main content of the portal"
          >
            {t.skipToContent}
          </a>

          <span className="text-white/30 hidden md:inline">|</span>

          {/* Screen Reader Access */}
          <button
            onClick={onScreenReaderToggle}
            className={`flex items-center space-x-1.5 px-2 py-0.5 rounded transition-colors focus:outline-none focus:ring-1 focus:ring-amber-400 ${
              isScreenReaderActive
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'hover:text-blue-200 text-slate-300'
            }`}
            title="Toggle Accessibility and Screen Reader Helper"
            aria-label="Screen Reader Access Toolbar"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.screenReader}</span>
          </button>

          <span className="text-white/30">|</span>

          {/* Font Size Controls: A- / A / A+ */}
          <div className="flex items-center space-x-2 bg-white/10 px-2 py-0.5 rounded border border-white/15" role="group" aria-label="Font Size Controls">
            <button
              onClick={() => onFontSizeChange(0.9)}
              className={`hover:text-orange-400 transition-colors ${
                fontSizeScale === 0.9 ? 'text-orange-400 font-bold underline underline-offset-4' : 'text-slate-300'
              }`}
              title="Decrease Font Size (A-)"
              aria-label="Decrease Font Size"
            >
              A-
            </button>
            <button
              onClick={() => onFontSizeChange(1.0)}
              className={`hover:text-orange-400 transition-colors ${
                fontSizeScale === 1.0 ? 'text-orange-400 font-bold underline underline-offset-4' : 'text-slate-200'
              }`}
              title="Standard Font Size (A)"
              aria-label="Normal Font Size"
            >
              A
            </button>
            <button
              onClick={() => onFontSizeChange(1.15)}
              className={`hover:text-orange-400 transition-colors ${
                fontSizeScale === 1.15 ? 'text-orange-400 font-bold underline underline-offset-4' : 'text-slate-300'
              }`}
              title="Increase Font Size (A+)"
              aria-label="Increase Font Size"
            >
              A+
            </button>
          </div>

          <span className="text-white/30">|</span>

          {/* Language Selector Dropdown */}
          <div className="relative" ref={langRef}>
            <button
              onClick={() => setIsLangOpen(!isLangOpen)}
              className="bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded flex items-center cursor-pointer transition-colors border border-white/15 text-slate-100"
              aria-expanded={isLangOpen}
              aria-haspopup="listbox"
              aria-label="Select Official Language"
            >
              <Globe className="w-3.5 h-3.5 text-amber-400 mr-1.5" />
              <span className="mr-1">{currentLangObj.nativeLabel}</span>
              <ChevronDown className={`w-3 h-3 text-slate-300 transition-transform ${isLangOpen ? 'rotate-180' : ''}`} />
            </button>

            {isLangOpen && (
              <div
                className="absolute right-0 mt-1.5 w-48 bg-[#0A1F44] border border-white/20 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in slide-in-from-top-2 duration-150 backdrop-blur-md"
                role="listbox"
                aria-label="Available Languages"
              >
                <div className="px-3 py-1.5 text-[11px] font-bold text-amber-400 border-b border-white/10 uppercase tracking-wider">
                  Select Language (भाषा)
                </div>
                <div className="max-h-60 overflow-y-auto py-1">
                  {SUPPORTED_LANGUAGES.map((lang) => {
                    const isSelected = lang.code === currentLanguage;
                    return (
                      <button
                        key={lang.code}
                        onClick={() => {
                          onLanguageChange(lang.code);
                          setIsLangOpen(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-white/10 transition-colors ${
                          isSelected ? 'text-amber-400 font-semibold bg-white/10' : 'text-slate-200'
                        }`}
                        role="option"
                        aria-selected={isSelected}
                      >
                        <span className="flex items-center space-x-2">
                          <span>{lang.nativeLabel}</span>
                          <span className="text-slate-400 text-[10px]">({lang.label})</span>
                        </span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
