import React, { useState } from 'react';
import {
  UserProfile,
  TrackedApplication,
  LanguageCode,
  ApplicationStatus,
} from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  downloadApplicationReceipt,
} from '../../utils/receiptGenerator';
import {
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Download,
  Printer,
  Copy,
  Check,
  Shield,
  ArrowRight,
  ChevronRight,
  ExternalLink,
  Filter,
  RefreshCw,
  Building2,
  Calendar,
  Sparkles,
  HelpCircle,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface TrackApplicationsPageProps {
  currentLanguage: LanguageCode;
  user: UserProfile;
  applications: TrackedApplication[];
  onApplyNewService: () => void;
  onFileGrievanceForApp: (app: TrackedApplication) => void;
  onOpenLogin?: () => void;
}

export const TrackApplicationsPage: React.FC<TrackApplicationsPageProps> = ({
  currentLanguage,
  user,
  applications,
  onApplyNewService,
  onFileGrievanceForApp,
  onOpenLogin,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ApplicationStatus>('all');
  const [selectedAppId, setSelectedAppId] = useState<string>(
    applications[0]?.id || ''
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [externalLookupId, setExternalLookupId] = useState('');
  const [externalLookupResult, setExternalLookupResult] = useState<TrackedApplication | null>(null);
  const [isSearchingExternal, setIsSearchingExternal] = useState(false);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Filter applications by search query and status tab
  const filteredApps = applications.filter((app) => {
    const matchesSearch =
      app.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.serviceTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (app.receiptNumber && app.receiptNumber.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus =
      statusFilter === 'all' || app.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Currently selected application for detailed inspector
  const activeApp =
    applications.find((a) => a.id === selectedAppId) ||
    filteredApps[0] ||
    applications[0];

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExternalLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!externalLookupId.trim()) return;

    setIsSearchingExternal(true);
    setTimeout(() => {
      setIsSearchingExternal(false);
      const randomApp: TrackedApplication = {
        id: externalLookupId.trim().toUpperCase(),
        serviceId: 'external-search',
        serviceTitle: 'National Single Window Tracked Service',
        department: 'Government Public Service Portal',
        applicantName: user.name || 'Citizen Applicant',
        aadhaarNumber: user.aadhaarMasked || 'XXXX-XXXX-8921',
        submissionDate: '28 Aug 2026',
        estimatedCompletionDate: '08 Sep 2026',
        status: 'under_review',
        statusLabel: 'Under Document Scrutiny by Licensing Authority',
        currentStage: 'Biometric & Identity Cross-Verification',
        feesPaid: 250,
        receiptNumber: `BBPS-REC-${Math.floor(100000 + Math.random() * 900000)}`,
        officerRemarks: 'Application received and verified against central repository. Pending competent authority signature.',
        timeline: [
          {
            title: 'Application Registered & Fee Paid',
            date: '28 Aug 2026, 11:30 AM',
            completed: true,
            description: 'Online application recorded on central gateway.',
          },
          {
            title: 'UIDAI & DigiLocker e-KYC Verification',
            date: '28 Aug 2026, 11:32 AM',
            completed: true,
            description: 'Instant Aadhaar authentication successful.',
          },
          {
            title: 'Document Scrutiny & Background Review',
            date: 'In Progress • Estimated within 48 hrs',
            completed: false,
            current: true,
            description: 'Scrutiny officer reviewing enclosed certificates.',
          },
          {
            title: 'Digital Certificate Approval & Dispatch',
            completed: false,
            description: 'Final authorization by designated officer.',
          },
        ],
      };
      setExternalLookupResult(randomApp);
      confetti({ particleCount: 40 });
    }, 800);
  };

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'approved':
      case 'completed':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
            <span>Approved & Issued</span>
          </span>
        );
      case 'under_review':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-pulse" />
            <span>Under Scrutiny</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
            <span>Action Required</span>
          </span>
        );
      case 'submitted':
      default:
        return (
          <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
            <span>Application Submitted</span>
          </span>
        );
    }
  };

  return (
    <div className="bg-[#F8FAFC] min-h-[850px] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header Banner: National Application Tracking System */}
        <div className="bg-[#0A1F44] text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800 mb-8 relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-72 h-72 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div>
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                <span>National Application Tracking System (NATS)</span>
                <span>•</span>
                <span>Real-Time Public Service SLA Hub</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Track Application Status
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
                Monitor real-time progress, scrutiny milestones, SLA delivery countdowns, and download authentic government acknowledgment slips.
              </p>
            </div>

            <div className="flex items-center space-x-3 shrink-0">
              <button
                onClick={onApplyNewService}
                className="bg-[#1D5FE0] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-lg shadow-sm transition-colors flex items-center space-x-1.5"
              >
                <span>+ Apply for New Service</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar inside Header */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <div className="text-slate-400 font-medium">Total Registered</div>
              <div className="text-xl font-extrabold text-white mt-0.5">{applications.length}</div>
            </div>
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <div className="text-slate-400 font-medium">Under Scrutiny</div>
              <div className="text-xl font-extrabold text-amber-400 mt-0.5">
                {applications.filter((a) => a.status === 'under_review').length}
              </div>
            </div>
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <div className="text-slate-400 font-medium">Approved / Issued</div>
              <div className="text-xl font-extrabold text-emerald-400 mt-0.5">
                {applications.filter((a) => a.status === 'approved' || a.status === 'completed').length}
              </div>
            </div>
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <div className="text-slate-400 font-medium">Citizen Applicant</div>
              <div className="text-sm font-bold text-slate-200 mt-1 truncate">{user.name}</div>
            </div>
          </div>
        </div>

        {/* Global Search & Filter Controls */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200/90 p-4 mb-6 space-y-4">
          <div className="flex flex-col md:flex-row items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by Reference ID (e.g. APP-2026-88219), Service Name, or Department..."
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800 placeholder:text-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Status Filter Chips */}
            <div className="flex items-center space-x-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 text-xs">
              {[
                { id: 'all', label: `All (${applications.length})` },
                { id: 'under_review', label: 'Under Scrutiny' },
                { id: 'approved', label: 'Approved' },
                { id: 'submitted', label: 'Submitted' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id as any)}
                  className={`px-3 py-2 rounded-lg font-bold whitespace-nowrap transition-colors ${
                    statusFilter === tab.id
                      ? 'bg-[#0A1F44] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Master - Detail Workspace */}
        {filteredApps.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-4">
            <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center mx-auto text-blue-600">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">No matching applications found</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              No applications match your filter criteria. You can search by reference ID or apply for a new public service.
            </p>
            <div className="pt-2 flex justify-center gap-3">
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                }}
                className="px-4 py-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"
              >
                Reset Filters
              </button>
              <button
                onClick={onApplyNewService}
                className="px-4 py-2 text-xs font-bold bg-[#1D5FE0] hover:bg-blue-600 text-white rounded-lg"
              >
                + Apply for Service
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Applications List (5 Columns on Desktop) */}
            <div className="lg:col-span-5 space-y-3">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
                Your Applications ({filteredApps.length})
              </div>

              {filteredApps.map((app) => {
                const isSelected = activeApp?.id === app.id;
                return (
                  <div
                    key={app.id}
                    onClick={() => setSelectedAppId(app.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer text-left relative ${
                      isSelected
                        ? 'bg-blue-50/70 border-blue-500 shadow-xs ring-2 ring-blue-500/20'
                        : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-slate-50/70 shadow-2xs'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">
                          {app.department.split(',')[0]}
                        </span>
                        <h3 className="text-sm font-extrabold text-[#0A1F44] line-clamp-1">
                          {app.serviceTitle}
                        </h3>
                      </div>
                      {getStatusBadge(app.status)}
                    </div>

                    <div className="text-xs text-slate-600 space-y-1 mt-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-mono font-bold text-slate-700">{app.id}</span>
                        <span className="text-slate-400">Filed: {app.submissionDate}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        Stage: <strong className="text-slate-700">{app.currentStage}</strong>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">
                        Est. Delivery: <strong className="text-blue-900">{app.estimatedCompletionDate}</strong>
                      </span>
                      <span className="font-bold text-[#1D5FE0] flex items-center space-x-1">
                        <span>Inspect Timeline</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right Column: Detailed Audit Trail Inspector (7 Columns on Desktop) */}
            {activeApp && (
              <div className="lg:col-span-7 bg-white rounded-2xl shadow-xs border border-slate-200/90 p-6 sm:p-7 space-y-6">
                
                {/* Header Summary */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
                        {activeApp.department}
                      </span>
                      <span>•</span>
                      <span className="text-[11px] font-bold text-slate-500">
                        SLA Guaranteed
                      </span>
                    </div>
                    <h2 className="text-xl font-extrabold text-[#0A1F44] mt-0.5">
                      {activeApp.serviceTitle}
                    </h2>
                  </div>

                  <div className="flex items-center space-x-2">
                    {getStatusBadge(activeApp.status)}
                  </div>
                </div>

                {/* Key Particulars Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs">
                  <div>
                    <span className="text-slate-400 font-medium block">Reference ARN</span>
                    <div className="flex items-center space-x-1 mt-0.5">
                      <strong className="font-mono text-slate-900 text-[11px]">{activeApp.id}</strong>
                      <button
                        onClick={() => handleCopyId(activeApp.id)}
                        className="text-slate-400 hover:text-blue-600 p-0.5"
                        title="Copy Reference ID"
                      >
                        {copiedId === activeApp.id ? (
                          <Check className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 font-medium block">Applicant</span>
                    <strong className="text-slate-900 truncate block mt-0.5">
                      {activeApp.applicantName || user.name}
                    </strong>
                  </div>

                  <div>
                    <span className="text-slate-400 font-medium block">Submitted Date</span>
                    <strong className="text-slate-900 block mt-0.5">{activeApp.submissionDate}</strong>
                  </div>

                  <div>
                    <span className="text-slate-400 font-medium block">Est. Delivery SLA</span>
                    <strong className="text-blue-700 block mt-0.5">{activeApp.estimatedCompletionDate}</strong>
                  </div>
                </div>

                {/* Officer Remarks / Scrutiny Insights */}
                {activeApp.officerRemarks && (
                  <div className="p-4 bg-blue-50/70 rounded-xl border border-blue-200 text-xs text-blue-950 space-y-1">
                    <div className="font-bold flex items-center space-x-1.5 text-blue-900">
                      <Shield className="w-3.5 h-3.5 text-blue-700" />
                      <span>Competent Authority Scrutiny Remarks</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed pl-5">
                      {activeApp.officerRemarks}
                    </p>
                  </div>
                )}

                {/* Step-by-Step Interactive Timeline */}
                <div>
                  <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-4">
                    Audit Trail & Milestone Progress
                  </h3>

                  <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {activeApp.timeline.map((step, idx) => {
                      let iconColor = 'bg-slate-300 text-white';
                      let dotBorder = 'border-slate-300';
                      if (step.completed) {
                        iconColor = 'bg-emerald-600 text-white shadow-xs';
                        dotBorder = 'border-emerald-600 ring-4 ring-emerald-500/10';
                      } else if (step.current) {
                        iconColor = 'bg-[#1D5FE0] text-white shadow-xs animate-pulse';
                        dotBorder = 'border-[#1D5FE0] ring-4 ring-blue-500/20';
                      }

                      return (
                        <div key={idx} className="relative group text-left">
                          <div
                            className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border-2 ${dotBorder} ${iconColor}`}
                          >
                            {step.completed ? '✓' : idx + 1}
                          </div>

                          <div>
                            <div className="flex items-center justify-between">
                              <h4
                                className={`text-xs sm:text-sm font-bold ${
                                  step.completed || step.current ? 'text-slate-900' : 'text-slate-400'
                                }`}
                              >
                                {step.title}
                              </h4>
                              {step.date && (
                                <span className="text-[11px] font-semibold text-slate-500">
                                  {step.date}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                              {step.description}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Action Buttons: Download PDF Slip, Print, Escalate */}
                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        confetti({ particleCount: 50 });
                        downloadApplicationReceipt(activeApp, user);
                      }}
                      className="bg-[#1D5FE0] hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF Receipt</span>
                    </button>

                    <button
                      onClick={() => window.print()}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-lg border border-slate-200 flex items-center space-x-1.5 transition-colors"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Slip</span>
                    </button>
                  </div>

                  <button
                    onClick={() => onFileGrievanceForApp(activeApp)}
                    className="text-xs font-bold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 px-3.5 py-2.5 rounded-lg flex items-center space-x-1.5 transition-colors"
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Lodge Delay Grievance</span>
                  </button>
                </div>

              </div>
            )}

          </div>
        )}

        {/* Public Global ARN Lookup Box for external government tokens */}
        <div className="mt-12 bg-white rounded-2xl shadow-xs border border-slate-200/90 p-6 sm:p-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center space-x-2 text-blue-700 text-xs font-bold uppercase tracking-wider">
                <Building2 className="w-4 h-4" />
                <span>External Ministry & Department Token Lookup</span>
              </div>
              <h3 className="text-lg font-bold text-[#0A1F44] mt-0.5">
                Track Other Central / State Government Application Numbers
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Search tokens issued by UIDAI, Sarathi Parivahan, E-District, Passport Seva, or State Portals.
              </p>
            </div>
          </div>

          <form onSubmit={handleExternalLookup} className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={externalLookupId}
              onChange={(e) => setExternalLookupId(e.target.value)}
              placeholder="e.g. DL-042026001928, URN-2948-2910, or EDIST-DEL-99120"
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
            />
            <button
              type="submit"
              disabled={isSearchingExternal}
              className="bg-[#0A1F44] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg transition-colors flex items-center justify-center space-x-1.5"
            >
              {isSearchingExternal ? (
                <span>Querying Central Database...</span>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Track Token</span>
                </>
              )}
            </button>
          </form>

          {externalLookupResult && (
            <div className="mt-4 p-4 bg-blue-50/80 rounded-xl border border-blue-200 animate-in fade-in">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-blue-900">
                  Result for {externalLookupResult.id}:
                </span>
                {getStatusBadge(externalLookupResult.status)}
              </div>
              <div className="text-xs text-slate-700 space-y-1">
                <div>Current Stage: <strong>{externalLookupResult.currentStage}</strong></div>
                <div>SLA Estimated Completion: <strong>{externalLookupResult.estimatedCompletionDate}</strong></div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
