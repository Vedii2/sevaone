import React from 'react';
import { AshokaEmblem } from '../Common/AshokaEmblem';
import { IndianFlagBadge } from '../Common/IndianFlagBadge';
import { ActiveTab, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  ShieldCheck,
  ExternalLink,
  Award,
  Lock,
  Globe,
  HelpCircle,
  Users,
  ChevronRight
} from 'lucide-react';

interface PortalFooterProps {
  currentLanguage: LanguageCode;
  onNavigate: (tab: ActiveTab) => void;
  onOpenPolicyModal?: (policyTitle: string) => void;
}

export const PortalFooter: React.FC<PortalFooterProps> = ({
  currentLanguage,
  onNavigate,
  onOpenPolicyModal,
}) => {
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const quickLinks = [
    { label: t.home, tab: 'home' as ActiveTab },
    { label: t.services, tab: 'services' as ActiveTab },
    { label: t.schemes, tab: 'schemes' as ActiveTab },
    { label: t.trackApp, tab: 'track' as ActiveTab },
    { label: t.digilockerVault, tab: 'vault' as ActiveTab },
    { label: t.grievances, tab: 'grievances' as ActiveTab },
    { label: t.help, tab: 'help' as ActiveTab },
  ];

  const centralMinistries = [
    { name: 'Ministry of Electronics & IT (MeitY)', url: 'https://meity.gov.in' },
    { name: 'Unique Identification Authority of India (UIDAI)', url: 'https://uidai.gov.in' },
    { name: 'Ministry of Road Transport & Highways', url: 'https://morth.nic.in' },
    { name: 'Ministry of Agriculture & Farmers Welfare', url: 'https://agricoop.gov.in' },
    { name: 'Ministry of Health & Family Welfare', url: 'https://mohfw.gov.in' },
    { name: 'Ministry of External Affairs (Passport Seva)', url: 'https://passportindia.gov.in' },
  ];

  const importantPortals = [
    { name: 'National Portal of India (india.gov.in)', url: 'https://india.gov.in' },
    { name: 'Digital India Initiative', url: 'https://digitalindia.gov.in' },
    { name: 'DigiLocker National Cloud', url: 'https://digilocker.gov.in' },
    { name: 'MyGov - Citizen Engagement', url: 'https://mygov.in' },
    { name: 'UMANG Unified Mobile App', url: 'https://umang.gov.in' },
    { name: 'CPGRAMS Grievance Portal', url: 'https://pgportal.gov.in' },
  ];

  const legalLinks = [
    'Terms of Service',
    'Privacy Policy',
    'Hyperlinking Policy',
    'Copyright Policy',
    'Accessibility Statement',
    'Cyber Security Guidelines (CERT-In)',
  ];

  const handlePolicyClick = (policy: string) => {
    if (onOpenPolicyModal) {
      onOpenPolicyModal(policy);
    } else {
      alert(`${policy}\n\nSEVA 1 strictly complies with the Guidelines for Indian Government Websites (GIGW 3.0) and Information Technology Act 2000.`);
    }
  };

  return (
    <footer className="bg-[#0A1F44] text-white pt-14 pb-8 border-t-4 border-[#F5893C] text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 5-Column Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          
          {/* Column 1: MeitY / NIC Branding (4 Cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-3">
              <AshokaEmblem size={44} color="#F5893C" />
              <div>
                <div className="text-[11px] font-semibold text-[#F5893C] tracking-wide uppercase">
                  {t.govOfIndia}
                </div>
                <div className="text-xl font-extrabold tracking-tight text-white flex items-center space-x-2">
                  <span>SEVA 1</span>
                  <IndianFlagBadge className="inline-block" />
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
              {t.footerAboutText}
            </p>

            <div className="pt-2 text-[11px] text-slate-400 space-y-1">
              <div>
                Designed, developed, and maintained by{' '}
                <strong className="text-white">National Informatics Centre (NIC)</strong>
              </div>
              <div>
                Hosted by <strong>NIC National Cloud</strong>
              </div>
              <div>
                Ministry of Electronics and Information Technology (MeitY)
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links (2 Cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F5893C] border-b border-slate-800 pb-2">
              {t.quickLinksTitle}
            </h4>
            <ul className="space-y-2 text-xs">
              {quickLinks.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => onNavigate(item.tab)}
                    className="text-slate-300 hover:text-white transition-colors flex items-center space-x-1 text-left"
                  >
                    <ChevronRight className="w-3 h-3 text-[#F5893C] shrink-0" />
                    <span>{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Central Ministries (2 Cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F5893C] border-b border-slate-800 pb-2">
              Central Ministries
            </h4>
            <ul className="space-y-2 text-xs">
              {centralMinistries.map((item, idx) => (
                <li key={idx}>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-300 hover:text-white transition-colors flex items-center space-x-1"
                  >
                    <span className="line-clamp-1">{item.name}</span>
                    <ExternalLink className="w-3 h-3 text-slate-500 shrink-0" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Important Portals (2 Cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F5893C] border-b border-slate-800 pb-2">
              Important Portals
            </h4>
            <ul className="space-y-2 text-xs">
              {importantPortals.map((item, idx) => (
                <li key={idx}>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-300 hover:text-white transition-colors flex items-center space-x-1"
                  >
                    <span className="line-clamp-1">{item.name}</span>
                    <ExternalLink className="w-3 h-3 text-slate-500 shrink-0" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 5: Legal & Policies (2 Cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F5893C] border-b border-slate-800 pb-2">
              Legal & Policy
            </h4>
            <ul className="space-y-2 text-xs">
              {legalLinks.map((policy, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handlePolicyClick(policy)}
                    className="text-slate-300 hover:text-white transition-colors text-left"
                  >
                    {policy}
                  </button>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom Trust & Compliance Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-slate-400">
          
          {/* Left: Security Badges & Certifications */}
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-1.5 bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>CERT-In Audited & Secure</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
              <Award className="w-4 h-4 text-amber-400" />
              <span>STQC Quality Certified</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
              <Globe className="w-4 h-4 text-blue-400" />
              <span>W3C WCAG 2.1 AA Compliant</span>
            </div>
          </div>

          {/* Right: Visitor Counter & Last Updated */}
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-2 text-right">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-[#F5893C]" />
              <span>Total Citizen Hits: <strong className="font-mono text-white">1,842,904,112</strong></span>
            </div>
            <div className="text-[11px] text-slate-500">
              Last Updated on: <strong>01 Sep 2026</strong> | Version 3.4.1
            </div>
          </div>

        </div>

        {/* Final Copyright */}
        <div className="mt-6 pt-4 border-t border-slate-900 text-center text-[11px] text-slate-500">
          © {new Date().getFullYear()} Government of India. All rights reserved. Content on this website is published and managed by National Informatics Centre, MeitY.
        </div>
      </div>
    </footer>
  );
};
