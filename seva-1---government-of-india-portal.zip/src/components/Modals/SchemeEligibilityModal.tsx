import React, { useState } from 'react';
import { SCHEMES_LIST } from '../../data/schemesData';
import { SchemeItem, UserProfile } from '../../types';
import {
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
  IndianRupee,
  Building2,
  Users,
  Tractor
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SchemeEligibilityModalProps {
  initialScheme?: SchemeItem | null;
  user?: UserProfile;
  onClose: () => void;
  onApplyScheme: (scheme: SchemeItem) => void;
}

export const SchemeEligibilityModal: React.FC<SchemeEligibilityModalProps> = ({
  initialScheme,
  user,
  onClose,
  onApplyScheme,
}) => {
  const [income, setIncome] = useState<number>(240000);
  const [occupation, setOccupation] = useState('farmer');
  const [socialCategory, setSocialCategory] = useState('OBC');
  const [state, setState] = useState(user?.state || 'Uttar Pradesh');
  const [hasLand, setHasLand] = useState(true);
  const [calculated, setCalculated] = useState(false);

  const calculateEligibleSchemes = () => {
    return SCHEMES_LIST.map((scheme) => {
      let isEligible = true;
      let matchScore = 95;
      let reasons: string[] = [];

      if (scheme.id === 'pm-kisan') {
        if (occupation === 'farmer' && hasLand) {
          isEligible = true;
          matchScore = 100;
          reasons.push('Farmer with cultivable landholding');
        } else {
          isEligible = false;
          matchScore = 30;
          reasons.push('Requires agricultural landholding');
        }
      } else if (scheme.id === 'ayushman-bharat') {
        if (income <= 500000) {
          isEligible = true;
          matchScore = 98;
          reasons.push('Annual income under ₹5 Lakh ceiling');
        } else {
          isEligible = false;
          matchScore = 40;
          reasons.push('Income exceeds ₹5 Lakh threshold');
        }
      } else if (scheme.id === 'pm-awas-yojana') {
        if (income <= 600000) {
          isEligible = true;
          matchScore = 92;
          reasons.push('Meets EWS / LIG income group');
        } else {
          isEligible = false;
          matchScore = 35;
        }
      } else if (scheme.id === 'national-scholarship') {
        if (occupation === 'student' || income <= 250000) {
          isEligible = true;
          matchScore = 94;
          reasons.push('Meets parental income cap & category');
        } else {
          isEligible = false;
          matchScore = 45;
        }
      } else {
        isEligible = true;
        matchScore = 88;
        reasons.push('Universal citizen entitlement');
      }

      return {
        scheme,
        isEligible,
        matchScore,
        reasons,
      };
    });
  };

  const results = calculateEligibleSchemes();
  const eligibleSchemes = results.filter((r) => r.isEligible);

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    setCalculated(true);
    confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#0A1F44]">
                Scheme Eligibility & DBT Benefit Calculator
              </h2>
              <p className="text-xs text-slate-500">
                Instant assessment based on official Central & State scheme guidelines
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700"
          >
            ✕
          </button>
        </div>

        {/* Input Parameters Form */}
        <form onSubmit={handleCalculate} className="my-6 space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Annual Family Income */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Annual Family Income (₹) *
              </label>
              <select
                value={income}
                onChange={(e) => setIncome(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-800"
              >
                <option value={120000}>Under ₹1,20,000 (BPL / Antyodaya)</option>
                <option value={240000}>₹1,20,000 - ₹3,00,000 (EWS)</option>
                <option value={500000}>₹3,00,000 - ₹6,00,000 (LIG)</option>
                <option value={900000}>₹6,00,000 - ₹12,00,000 (MIG)</option>
                <option value={1500000}>Above ₹12,00,000</option>
              </select>
            </div>

            {/* Occupation */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Primary Occupation *
              </label>
              <select
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-800"
              >
                <option value="farmer">Small / Marginal Farmer</option>
                <option value="student">Student / Scholar</option>
                <option value="self-employed">Self-Employed / Artisan</option>
                <option value="salaried">Salaried Employee</option>
                <option value="homemaker">Women Homemaker</option>
                <option value="senior">Senior Citizen (60+)</option>
              </select>
            </div>

            {/* Social Category */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Social Category
              </label>
              <select
                value={socialCategory}
                onChange={(e) => setSocialCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-800"
              >
                <option value="General">General</option>
                <option value="OBC">OBC (Non-Creamy)</option>
                <option value="SC">Scheduled Caste (SC)</option>
                <option value="ST">Scheduled Tribe (ST)</option>
                <option value="EWS">EWS</option>
              </select>
            </div>

            {/* Cultivable Landholding */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Agricultural Landholding
              </label>
              <select
                value={hasLand ? 'yes' : 'no'}
                onChange={(e) => setHasLand(e.target.value === 'yes')}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-slate-800"
              >
                <option value="yes">Yes (Under 2 Hectares)</option>
                <option value="no">No / Landless</option>
              </select>
            </div>

          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg shadow-xs transition-colors flex items-center space-x-1.5"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Calculate Entitlements</span>
            </button>
          </div>
        </form>

        {/* Results Showcase */}
        <div className="pt-4 border-t border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-[#0A1F44]">
              Eligible Government Schemes ({eligibleSchemes.length} Found)
            </h3>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
              Total Direct Entitlement: ₹5,06,000+ / yr
            </span>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {eligibleSchemes.map(({ scheme, matchScore, reasons }) => (
              <div
                key={scheme.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-amber-400 bg-slate-50/70 hover:bg-white transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-[#0A1F44]">{scheme.name}</span>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      {matchScore}% Match
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 mt-0.5">{scheme.ministry}</p>

                  <div className="text-xs text-slate-700 mt-2 flex items-center space-x-2">
                    <span className="font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                      Benefit: {scheme.benefitAmount}
                    </span>
                    <span className="text-slate-500 text-[11px]">• {reasons.join(', ')}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onApplyScheme(scheme);
                    onClose();
                  }}
                  className="bg-[#0A1F44] hover:bg-blue-900 text-white text-xs font-bold px-4 py-2 rounded-lg shrink-0 transition-colors"
                >
                  Apply for Scheme
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
          >
            Close Calculator
          </button>
        </div>

      </div>
    </div>
  );
};
