import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  FileText,
  Sparkles,
  ShieldCheck,
  Bot,
  Clock,
  Trash2,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  CornerDownLeft,
  Filter,
  CheckCircle2,
  Layers
} from 'lucide-react';
import {
  searchPortalCatalog,
  UnifiedSearchResult,
  SearchResultType,
  getRecentSearches,
  saveRecentSearch,
  removeRecentSearch,
  clearAllRecentSearches,
  DEFAULT_RECENT_SEARCHES
} from '../../utils/searchEngine';
import { ServiceItem, SchemeItem, VaultDocument, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: LanguageCode;
  onSelectService: (service: ServiceItem) => void;
  onSelectScheme: (scheme: SchemeItem) => void;
  onOpenAiAssistant: (query?: string) => void;
  onNavigateToVault?: () => void;
  initialQuery?: string;
  userEmail?: string;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  onSelectService,
  onSelectScheme,
  onOpenAiAssistant,
  onNavigateToVault,
  initialQuery = '',
  userEmail,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [filterType, setFilterType] = useState<'all' | 'service' | 'scheme' | 'document'>('all');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<UnifiedSearchResult[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Sync recent searches on open
  useEffect(() => {
    if (isOpen) {
      setRecentSearches(getRecentSearches(userEmail));
      setQuery(initialQuery || '');
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  }, [isOpen, initialQuery, userEmail]);

  // Execute live search with subtle shimmer delay for smooth feel
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const timer = setTimeout(() => {
      const hits = searchPortalCatalog(query);
      setResults(hits);
      setIsLoading(false);
    }, 120);

    return () => clearTimeout(timer);
  }, [query]);

  // Keyboard shortcut listener: ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSelectResult = (result: UnifiedSearchResult) => {
    saveRecentSearch(query || result.title, userEmail);
    onClose();

    if (result.type === 'service' && result.serviceData) {
      onSelectService(result.serviceData);
    } else if (result.type === 'scheme' && result.schemeData) {
      onSelectScheme(result.schemeData);
    } else if (result.type === 'document' && onNavigateToVault) {
      onNavigateToVault();
    }
  };

  const handleSelectRecent = (recentQuery: string) => {
    setQuery(recentQuery);
    saveRecentSearch(recentQuery, userEmail);
    setRecentSearches(getRecentSearches(userEmail));
  };

  const handleRemoveRecent = (e: React.MouseEvent, item: string) => {
    e.stopPropagation();
    const updated = removeRecentSearch(item, userEmail);
    setRecentSearches(updated);
  };

  const handleClearAllRecent = () => {
    clearAllRecentSearches(userEmail);
    setRecentSearches([]);
  };

  const filteredResults = filterType === 'all'
    ? results
    : results.filter((r) => r.type === filterType);

  const servicesCount = results.filter((r) => r.type === 'service').length;
  const schemesCount = results.filter((r) => r.type === 'scheme').length;
  const docsCount = results.filter((r) => r.type === 'document').length;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-start justify-center p-3 sm:p-6 sm:pt-16 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl sm:rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150 flex flex-col max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200/90 bg-slate-50/70">
          <div className="relative flex items-center bg-white rounded-2xl border-2 border-slate-200 focus-within:border-[#1D5FE0] focus-within:ring-4 focus-within:ring-blue-500/10 shadow-sm transition-all">
            <div className="pl-4 pr-2 text-[#1D5FE0]">
              <Search className="w-5 h-5" />
            </div>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search services, welfare schemes, DigiLocker certificates..."
              className="w-full bg-transparent py-3.5 sm:py-4 px-2 text-base sm:text-lg text-slate-800 placeholder-slate-400 focus:outline-none font-medium"
            />
            {query && (
              <button
                onClick={() => {
                  setQuery('');
                  inputRef.current?.focus();
                }}
                className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-full mr-2 transition-colors"
                title="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <div className="pr-3 hidden sm:flex items-center space-x-1 text-[11px] font-semibold text-slate-400 uppercase tracking-widest bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
              <span>ESC to close</span>
            </div>
          </div>

          {/* Filter Pills (When search query entered) */}
          {query.trim().length > 0 && results.length > 0 && (
            <div className="flex items-center space-x-2 pt-3 text-xs overflow-x-auto scrollbar-none">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1.5 rounded-full font-bold transition-all shrink-0 ${
                  filterType === 'all'
                    ? 'bg-[#1D5FE0] text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                All Results ({results.length})
              </button>
              {servicesCount > 0 && (
                <button
                  onClick={() => setFilterType('service')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all shrink-0 ${
                    filterType === 'service'
                      ? 'bg-[#1D5FE0] text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Services ({servicesCount})
                </button>
              )}
              {schemesCount > 0 && (
                <button
                  onClick={() => setFilterType('scheme')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all shrink-0 ${
                    filterType === 'scheme'
                      ? 'bg-[#F5893C] text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Schemes ({schemesCount})
                </button>
              )}
              {docsCount > 0 && (
                <button
                  onClick={() => setFilterType('document')}
                  className={`px-3 py-1.5 rounded-full font-bold transition-all shrink-0 ${
                    filterType === 'document'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  DigiLocker ({docsCount})
                </button>
              )}
            </div>
          )}
        </div>

        {/* Modal Body: Results or Recent Searches */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {/* 1. Loading Shimmer */}
          {isLoading && (
            <div className="space-y-3 py-2">
              {[1, 2, 3].map((n) => (
                <div key={n} className="p-3 rounded-2xl border border-slate-100 bg-slate-50/60 animate-pulse flex items-center space-x-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-200" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-1/3" />
                    <div className="h-3 bg-slate-200 rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 2. Empty Query State (Show Recent Searches + Popular Suggestions) */}
          {!isLoading && !query.trim() && (
            <div className="space-y-6">
              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between pb-2.5">
                    <div className="flex items-center space-x-1.5 text-xs font-bold uppercase tracking-wider text-slate-500">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>Recent Searches</span>
                    </div>
                    <button
                      onClick={handleClearAllRecent}
                      className="text-xs text-rose-600 hover:underline font-semibold flex items-center space-x-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Clear History</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {recentSearches.map((item) => (
                      <div
                        key={item}
                        onClick={() => handleSelectRecent(item)}
                        className="group flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-blue-50/70 border border-slate-200/80 hover:border-blue-200 cursor-pointer transition-all"
                      >
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <Clock className="w-4 h-4 text-slate-400 group-hover:text-[#1D5FE0] shrink-0" />
                          <span className="text-sm font-semibold text-slate-700 group-hover:text-[#1D5FE0] truncate">
                            {item}
                          </span>
                        </div>
                        <button
                          onClick={(e) => handleRemoveRecent(e, item)}
                          className="text-slate-300 hover:text-slate-600 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          title="Remove from history"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Popular Discovery Shortcuts */}
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500 pb-2.5">
                  Popular Citizen Services
                </div>
                <div className="flex flex-wrap gap-2">
                  {DEFAULT_RECENT_SEARCHES.map((pill) => (
                    <button
                      key={pill}
                      onClick={() => handleSelectRecent(pill)}
                      className="px-3.5 py-1.5 rounded-full text-xs font-semibold bg-white hover:bg-blue-50 text-slate-700 hover:text-[#1D5FE0] border border-slate-200 hover:border-blue-300 shadow-2xs transition-all flex items-center space-x-1.5"
                    >
                      <Search className="w-3 h-3 text-slate-400" />
                      <span>{pill}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 3. Search Results List */}
          {!isLoading && query.trim() && filteredResults.length > 0 && (
            <div className="space-y-2">
              {filteredResults.map((res) => {
                const isService = res.type === 'service';
                const isScheme = res.type === 'scheme';
                const isDoc = res.type === 'document';

                return (
                  <div
                    key={`${res.type}-${res.id}`}
                    onClick={() => handleSelectResult(res)}
                    className="group p-3.5 rounded-2xl border border-slate-200 hover:border-[#1D5FE0] bg-white hover:bg-blue-50/30 shadow-2xs hover:shadow-md cursor-pointer transition-all flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-3.5 min-w-0">
                      <div
                        className={`p-2.5 rounded-xl shrink-0 transition-colors ${
                          isService
                            ? 'bg-blue-50 text-[#1D5FE0] group-hover:bg-[#1D5FE0] group-hover:text-white'
                            : isScheme
                            ? 'bg-amber-50 text-[#F5893C] group-hover:bg-[#F5893C] group-hover:text-white'
                            : 'bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white'
                        }`}
                      >
                        {isService && <FileText className="w-5 h-5" />}
                        {isScheme && <Sparkles className="w-5 h-5" />}
                        {isDoc && <ShieldCheck className="w-5 h-5" />}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-bold text-[#0A1F44] group-hover:text-[#1D5FE0] transition-colors truncate">
                            {res.title}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md border shrink-0 ${
                              isService
                                ? 'bg-blue-50 text-blue-800 border-blue-200'
                                : isScheme
                                ? 'bg-amber-50 text-amber-900 border-amber-200'
                                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            }`}
                          >
                            {res.badge}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                          {res.subtitle}
                        </p>
                      </div>
                    </div>

                    <div className="hidden sm:flex items-center space-x-1 text-xs font-bold text-[#1D5FE0] opacity-0 group-hover:opacity-100 transition-opacity shrink-0 pl-3">
                      <span>{res.actionText}</span>
                      <ChevronRight className="w-4 h-4 ml-0.5" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 4. No Results Found State with Direct AI Help */}
          {!isLoading && query.trim() && filteredResults.length === 0 && (
            <div className="p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  No direct matches found for "{query}"
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Try checking for spelling errors, searching broader terms like "Aadhaar", "PAN", "Ration Card", "Scholarship", or ask SevaMitra AI.
                </p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2.5">
                <button
                  onClick={() => {
                    onClose();
                    onOpenAiAssistant(`I am searching for information regarding: ${query}`);
                  }}
                  className="w-full sm:w-auto bg-gradient-to-r from-[#1D5FE0] to-[#0A47B8] hover:from-[#174ebd] hover:to-[#083893] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 flex items-center justify-center space-x-2 transition-all active:scale-95"
                >
                  <Bot className="w-4 h-4" />
                  <span>Ask SevaMitra AI Assistant</span>
                </button>

                <button
                  onClick={() => setQuery('')}
                  className="w-full sm:w-auto bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl text-xs font-bold transition-colors"
                >
                  Clear Search
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Helper Strip */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-semibold text-slate-700">1,400+ Verified Public Records Indexed</span>
          </div>
          <button
            onClick={() => {
              onClose();
              onOpenAiAssistant();
            }}
            className="text-[#1D5FE0] hover:underline font-bold flex items-center space-x-1"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Need Help? Chat with SevaMitra</span>
          </button>
        </div>
      </div>
    </div>
  );
};
