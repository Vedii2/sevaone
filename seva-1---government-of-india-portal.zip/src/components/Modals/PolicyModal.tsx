import React from 'react';
import { ShieldCheck, Lock, FileText } from 'lucide-react';

interface PolicyModalProps {
  policyTitle: string | null;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ policyTitle, onClose }) => {
  if (!policyTitle) return null;

  const getPolicyContent = (title: string) => {
    switch (title) {
      case 'Privacy Policy':
        return {
          subtitle: 'Digital Personal Data Protection (DPDP) Act Compliance',
          text: `The Government of India and the National Informatics Centre (NIC) are committed to protecting the privacy of citizens accessing the SEVA 1 portal. 
          
1. Information Collected: We do not collect personal information without consent. Personal identifiers (such as Aadhaar, PAN, and Mobile numbers) are used strictly for authentication and service fulfillment under UIDAI and DigiLocker security protocols.
2. Data Sharing: Your data is never shared with commercial entities or third parties. It is transmitted solely to authorized Central and State departmental authorities for the explicit purpose of service delivery and DBT benefit credit.
3. Cookies & Security: All sessions are encrypted with 256-bit SSL protocols. We strictly adhere to the Guidelines for Indian Government Websites (GIGW 3.0).`,
        };
      case 'Terms of Service':
        return {
          subtitle: 'National e-Governance Division (NeGD) Rules of Usage',
          text: `1. Acceptance of Terms: By accessing the SEVA 1 National Single Window Portal, you agree to comply with all applicable laws of the Republic of India, including the Information Technology Act 2000.
2. Citizen Responsibility: Citizens must provide accurate and authentic documents. Submitting fraudulent certificates or impersonating another citizen is punishable under Section 66D of the IT Act.
3. Service Level Agreements: The portal endeavors to fulfill services within stated citizen charter timelines. In case of unexpected server downtime or department delays, grievances can be lodged directly via CPGRAMS.`,
        };
      case 'Accessibility Statement':
        return {
          subtitle: 'Compliance with W3C WCAG 2.1 Level AA & GIGW 3.0',
          text: `SEVA 1 is designed to be fully accessible to persons with disabilities, adhering to the Rights of Persons with Disabilities Act 2016 and W3C Web Content Accessibility Guidelines (WCAG 2.1 AA).
          
- Screen Reader Access: Standard ARIA landmarks, alt tags, and logical heading hierarchies.
- Font Scaling: A+ / A / A- controls in the utility bar allowing font resizing without layout breakage.
- Color Contrast: Minimum 4.5:1 contrast ratios across all text and interactive controls.
- Keyboard Navigable: All menus, forms, and dialogs can be operated entirely using Tab, Enter, Space, and Esc.`,
        };
      default:
        return {
          subtitle: 'Government of India Official Gazette Directive',
          text: `This portal strictly adheres to the official policies, cyber security guidelines by CERT-In, and National e-Governance standards mandated by the Ministry of Electronics and Information Technology (MeitY).`,
        };
    }
  };

  const content = getPolicyContent(policyTitle);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div>
            <div className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
              Official Legal Directive
            </div>
            <h3 className="text-xl font-extrabold text-[#0A1F44] mt-0.5">{policyTitle}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700"
          >
            ✕
          </button>
        </div>

        <div className="my-6 space-y-4">
          <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-xs font-bold text-blue-900 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
            <span>{content.subtitle}</span>
          </div>

          <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-4 rounded-xl border border-slate-200">
            {content.text}
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-200">
          <button
            onClick={onClose}
            className="bg-[#0A1F44] hover:bg-blue-900 text-white font-bold text-xs px-5 py-2.5 rounded-lg transition-colors"
          >
            Understood & Close
          </button>
        </div>
      </div>
    </div>
  );
};
