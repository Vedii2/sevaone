import React, { useState, useEffect, useMemo } from 'react';
import { ServiceItem, UserProfile, VaultDocument, TrackedApplication } from '../../types';
import {
  FileText,
  CheckCircle2,
  Clock,
  ArrowRight,
  ArrowLeft,
  Shield,
  CreditCard,
  Download,
  Printer,
  Sparkles,
  QrCode,
  IndianRupee,
  Check,
  Lock,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { downloadApplicationReceipt } from '../../utils/receiptGenerator';
import { UpiQrPaymentSection } from '../Payment/UpiQrPaymentSection';

interface ServiceApplicationModalProps {
  service: ServiceItem | null;
  user: UserProfile;
  vaultDocs: VaultDocument[];
  onClose: () => void;
  onSubmitApplication: (newApp: TrackedApplication) => void;
}

export const ServiceApplicationModal: React.FC<ServiceApplicationModalProps> = ({
  service,
  user,
  vaultDocs: _vaultDocs,
  onClose,
  onSubmitApplication,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [maxReachedStep, setMaxReachedStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [applicantName, setApplicantName] = useState(user.name);
  const [applicantPhone, setApplicantPhone] = useState(user.phone);
  const [applicantAadhaar, setApplicantAadhaar] = useState(user.aadhaarMasked);
  const [applicantAddress, setApplicantAddress] = useState(user.address);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState('Debit / Credit Card (RuPay, Visa, Mastercard)');
  const [paymentMethodView, setPaymentMethodView] = useState<'upi_qr' | 'alternative_methods'>('upi_qr');
  const [attachedDocs, setAttachedDocs] = useState<string[]>([]);
  const [generatedApp, setGeneratedApp] = useState<TrackedApplication | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Unique session transaction reference and application reference generated for this specific application
  const [sessionAppId, setSessionAppId] = useState<string>(() => `APP-2026-${Math.floor(10000 + Math.random() * 90000)}`);
  const [sessionTxnRef, setSessionTxnRef] = useState<string>(() => `TXN-UPI-${Math.floor(10000000 + Math.random() * 90000000)}`);

  // Reset entire wizard state whenever service changes or modal opens
  useEffect(() => {
    if (service) {
      setStep(1);
      setMaxReachedStep(1);
      setApplicantName(user.name);
      setApplicantPhone(user.phone);
      setApplicantAadhaar(user.aadhaarMasked);
      setApplicantAddress(user.address);
      setSelectedPaymentMode('Debit / Credit Card (RuPay, Visa, Mastercard)');
      setPaymentMethodView('upi_qr');
      setAttachedDocs(service.requiredDocuments || []);
      setGeneratedApp(null);
      setIsProcessing(false);
      setDownloadSuccess(false);
      setSessionAppId(`APP-2026-${Math.floor(10000 + Math.random() * 90000)}`);
      setSessionTxnRef(`TXN-UPI-${Math.floor(10000000 + Math.random() * 90000000)}`);
    }
  }, [service?.id, user]);

  if (!service) return null;

  // Toggle attached document
  const handleToggleDoc = (docName: string) => {
    setAttachedDocs((prev) =>
      prev.includes(docName) ? prev.filter((d) => d !== docName) : [...prev, docName]
    );
  };

  const handleNextToDocuments = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName.trim() || !applicantPhone.trim()) return;
    setAttachedDocs(service.requiredDocuments);
    setMaxReachedStep((prev) => Math.max(prev, 2) as 1 | 2 | 3 | 4);
    setStep(2);
  };

  const handleProceedToPayment = () => {
    setMaxReachedStep((prev) => Math.max(prev, 3) as 1 | 2 | 3 | 4);
    setStep(3);
  };

  // Handler for QR Code Payment Success
  const handleUpiQrPaymentSuccess = (details: { paymentMode: string; txnRef: string; timestamp: string }) => {
    const today = new Date();
    const completionDate = new Date();
    completionDate.setDate(today.getDate() + 7);

    const formattedToday = today.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const formattedCompletion = completionDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

    const newApplication: TrackedApplication = {
      id: sessionAppId,
      serviceId: service.id,
      serviceTitle: service.title,
      department: service.department,
      applicantName: applicantName,
      aadhaarNumber: applicantAadhaar,
      submissionDate: formattedToday,
      estimatedCompletionDate: formattedCompletion,
      status: 'submitted',
      statusLabel: 'Application Submitted & Fee Realized (UPI)',
      currentStage: 'Document Scrutiny by Licensing / Approving Authority',
      feesPaid: service.fee,
      receiptNumber: details.txnRef,
      paymentMode: details.paymentMode,
      upiTxnRef: details.txnRef,
      timeline: [
        {
          title: 'Application & Fee Realized via Bharat BillPay UPI',
          date: `${formattedToday}, ${details.timestamp}`,
          completed: true,
          description: `Application transmitted to ${service.department}. Real-time settlement confirmed by NPCI (Txn: ${details.txnRef}).`,
        },
        {
          title: 'Scrutiny & Document Verification',
          date: 'Estimated within 48 hours',
          current: true,
          completed: false,
          description: 'Scrutiny Officer is verifying attached identity certificates.',
        },
        {
          title: 'Field Verification / Competent Authority Approval',
          completed: false,
          description: 'Final sanction by the Sub-Divisional Magistrate / Competent Authority.',
        },
        {
          title: 'Digital Certificate Issuance & Dispatch',
          completed: false,
          description: 'Digital signed certificate will be pushed directly to your DigiLocker Vault.',
        },
      ],
    };

    setGeneratedApp(newApplication);
    setMaxReachedStep(4);
    setStep(4);
    onSubmitApplication(newApplication);
    confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
  };

  // Handler for Card / Netbanking / Challan payment
  const handleFinalPaymentAndSubmit = () => {
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const receiptId = `RCP-BBPS-2026-${Math.floor(100000 + Math.random() * 900000)}`;

      const today = new Date();
      const completionDate = new Date();
      completionDate.setDate(today.getDate() + 7);

      const formattedToday = today.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      const formattedCompletion = completionDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

      const newApplication: TrackedApplication = {
        id: sessionAppId,
        serviceId: service.id,
        serviceTitle: service.title,
        department: service.department,
        applicantName: applicantName,
        aadhaarNumber: applicantAadhaar,
        submissionDate: formattedToday,
        estimatedCompletionDate: formattedCompletion,
        status: 'submitted',
        statusLabel: 'Application Submitted & Fee Acknowledged',
        currentStage: 'Document Scrutiny by Licensing / Approving Authority',
        feesPaid: service.fee,
        receiptNumber: receiptId,
        paymentMode: selectedPaymentMode,
        timeline: [
          {
            title: 'Application & Fee Acknowledged',
            date: formattedToday + ', Just now',
            completed: true,
            description: `Application received by ${service.department}. Paid via ${selectedPaymentMode}.`,
          },
          {
            title: 'Scrutiny & Document Verification',
            date: 'Estimated within 48 hours',
            current: true,
            completed: false,
            description: 'Scrutiny Officer is verifying attached identity certificates.',
          },
          {
            title: 'Field Verification / Competent Authority Approval',
            completed: false,
            description: 'Final sanction by the Sub-Divisional Magistrate / Competent Authority.',
          },
          {
            title: 'Digital Certificate Issuance & Dispatch',
            completed: false,
            description: 'Digital signed certificate will be pushed directly to your DigiLocker Vault.',
          },
        ],
      };

      setGeneratedApp(newApplication);
      setMaxReachedStep(4);
      setStep(4);
      onSubmitApplication(newApplication);
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.6 } });
    }, 1000);
  };

  const handleStepClick = (targetStep: 1 | 2 | 3 | 4) => {
    if (targetStep === 4) return; // Cannot skip ahead directly to acknowledgment
    if (targetStep <= maxReachedStep) {
      setStep(targetStep);
    }
  };

  const handleDownloadReceipt = () => {
    if (!generatedApp) return;
    confetti({ particleCount: 50 });
    const success = downloadApplicationReceipt(generatedApp, user);
    if (success) {
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        
        {/* Header Strip */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div>
            <div className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
              {service.department}
            </div>
            <h2 className="text-xl font-extrabold text-[#0A1F44]">{service.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700 transition-colors"
            title="Close Application Modal"
          >
            ✕
          </button>
        </div>

        {/* Wizard Progress Steps Indicator with Lock/Clickable Guards */}
        <div className="grid grid-cols-4 gap-2 my-5 text-center text-xs" role="tablist">
          {[
            { num: 1 as const, label: '1. Particulars' },
            { num: 2 as const, label: '2. Documents' },
            { num: 3 as const, label: '3. Payment' },
            { num: 4 as const, label: '4. Acknowledgment' },
          ].map((s) => {
            const isActive = step === s.num;
            const isCompleted = s.num < step;
            const isAccessible = s.num <= maxReachedStep && s.num < 4;
            
            let badgeStyle = 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed';
            if (isActive) {
              badgeStyle = s.num === 4 
                ? 'bg-emerald-500 text-white border-emerald-600 font-extrabold shadow-xs ring-2 ring-emerald-500/20' 
                : 'bg-[#1D5FE0] text-white border-[#1D5FE0] font-extrabold shadow-xs ring-2 ring-blue-500/20';
            } else if (isCompleted || isAccessible) {
              badgeStyle = 'bg-blue-50 text-blue-900 border-blue-300 hover:bg-blue-100 cursor-pointer font-bold';
            }

            return (
              <button
                key={s.num}
                type="button"
                onClick={() => isAccessible && handleStepClick(s.num)}
                disabled={!isAccessible && !isActive}
                className={`p-2 rounded-lg text-xs font-semibold border transition-all flex items-center justify-center space-x-1 ${badgeStyle}`}
                title={isAccessible ? `Go to ${s.label}` : 'Complete previous steps first'}
              >
                <span>{s.label}</span>
                {!isAccessible && !isActive && s.num !== 4 && (
                  <Lock className="w-2.5 h-2.5 opacity-40 ml-0.5 inline" />
                )}
              </button>
            );
          })}
        </div>

        {/* ========================================================================= */}
        {/* STEP 1: APPLICANT PARTICULARS */}
        {/* ========================================================================= */}
        {step === 1 && (
          <form onSubmit={handleNextToDocuments} className="space-y-4 text-xs sm:text-sm">
            <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 text-xs text-blue-900 flex items-center justify-between">
              <span>Auto-filled from your authenticated citizen profile:</span>
              <span className="font-bold text-emerald-700">✓ DigiLocker Verified</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Legal Name *</label>
              <input
                type="text"
                required
                value={applicantName}
                onChange={(e) => setApplicantName(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Registered Mobile *</label>
                <input
                  type="text"
                  required
                  value={applicantPhone}
                  onChange={(e) => setApplicantPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Aadhaar Number *</label>
                <input
                  type="text"
                  required
                  disabled
                  value={applicantAadhaar}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-100 border border-slate-300 rounded-lg font-mono text-slate-600 cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Residential Address *</label>
              <textarea
                rows={2}
                required
                value={applicantAddress}
                onChange={(e) => setApplicantAddress(e.target.value)}
                className="w-full p-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="pt-4 flex justify-between items-center border-t border-slate-100">
              <span className="text-xs text-slate-500">Processing SLA: <strong>{service.processingTime}</strong></span>
              <button
                type="submit"
                className="bg-[#0A1F44] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg flex items-center space-x-1.5 transition-colors"
              >
                <span>Continue to Documents</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* ========================================================================= */}
        {/* STEP 2: DOCUMENTS CHECKLIST */}
        {/* ========================================================================= */}
        {step === 2 && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-center space-x-2">
              <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Required certificates have been fetched automatically from your DigiLocker Vault.
              </span>
            </div>

            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Mandatory Enclosures for {service.title}
            </h4>

            <div className="space-y-2.5">
              {service.requiredDocuments.map((docName, idx) => {
                const isSelected = attachedDocs.includes(docName);
                return (
                  <div
                    key={idx}
                    onClick={() => handleToggleDoc(docName)}
                    className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-blue-50/50 border-blue-300 text-blue-950'
                        : 'bg-slate-50 border-slate-200 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-5 h-5 rounded border flex items-center justify-center ${
                          isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-400 bg-white'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <div className="font-bold text-xs sm:text-sm">{docName}</div>
                        <span className="text-[10px] text-emerald-700 font-semibold">
                          Linked via DigiLocker
                        </span>
                      </div>
                    </div>

                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      Verified
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex justify-between items-center border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg flex items-center space-x-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <button
                type="button"
                onClick={handleProceedToPayment}
                className="bg-[#0A1F44] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg flex items-center space-x-1.5 transition-colors"
              >
                <span>Proceed to Fee Payment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 3: FEE PAYMENT (BHARAT BILLPAY & DYNAMIC UPI QR) */}
        {/* ========================================================================= */}
        {step === 3 && (
          <div className="space-y-4 text-xs sm:text-sm">
            {service.fee === 0 ? (
              /* Zero Statutory Fee Waiver */
              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-200 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-emerald-950">
                    No Statutory Fee Required
                  </h3>
                  <p className="text-xs text-emerald-800 mt-1 max-w-sm mx-auto">
                    This public service under <strong>{service.department}</strong> is subsidized by the Government of India with 100% fee waiver.
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border border-emerald-200 text-xs font-mono text-slate-700 flex justify-between max-w-sm mx-auto">
                  <span>Payable Amount:</span>
                  <strong className="text-emerald-700">₹0.00 (Exempted)</strong>
                </div>

                <div className="pt-2 flex justify-between items-center border-t border-emerald-200">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg flex items-center space-x-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleFinalPaymentAndSubmit}
                    disabled={isProcessing}
                    className="bg-[#0A1F44] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg flex items-center space-x-2 shadow-xs transition-colors"
                  >
                    {isProcessing ? (
                      <span>Transmitting Application...</span>
                    ) : (
                      <>
                        <span>Submit Free Application</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : paymentMethodView === 'upi_qr' ? (
              /* Dynamic UPI QR Code View (Default & Primary Option) */
              <UpiQrPaymentSection
                service={service}
                applicationId={sessionAppId}
                transactionRef={sessionTxnRef}
                applicantName={applicantName}
                onPaymentSuccess={handleUpiQrPaymentSuccess}
                onSwitchToAlternativePayment={() => setPaymentMethodView('alternative_methods')}
                onBack={() => setStep(2)}
              />
            ) : (
              /* Alternative Payment Modes (Card, Netbanking, e-Challan) */
              <div className="space-y-4 animate-in fade-in duration-150">
                {/* Switch back banner */}
                <div className="p-3 bg-blue-50/80 rounded-xl border border-blue-200 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <QrCode className="w-4 h-4 text-[#1D5FE0]" />
                    <span className="text-xs font-semibold text-blue-950">
                      Want instant scan & pay?
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPaymentMethodView('upi_qr')}
                    className="text-xs font-bold text-[#1D5FE0] hover:text-blue-900 flex items-center space-x-1 underline"
                  >
                    <span>Use UPI QR Code</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                {/* Fee Breakdown Summary */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Government Statutory Fee:</span>
                    <strong className="text-slate-800">₹{service.fee}.00</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Service Facilitation & GST (0%):</span>
                    <strong className="text-emerald-700">₹0.00</strong>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-200 text-sm font-extrabold text-slate-900">
                    <span>Total Payable Amount:</span>
                    <span className="text-blue-700">₹{service.fee}.00</span>
                  </div>
                </div>

                {/* Payment Mode Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                    Select Bharat BillPay / Treasury Gateway Mode
                  </label>
                  <div className="space-y-2">
                    {[
                      'Debit / Credit Card (RuPay, Visa, Mastercard)',
                      'Net Banking (SBI, HDFC, ICICI, PNB, BoB)',
                      'e-Challan / Treasury Desk Payment',
                    ].map((mode) => (
                      <label
                        key={mode}
                        className={`flex items-center space-x-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                          selectedPaymentMode === mode
                            ? 'bg-blue-50 border-blue-400 text-blue-950 font-bold'
                            : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment_mode"
                          checked={selectedPaymentMode === mode}
                          onChange={() => setSelectedPaymentMode(mode)}
                          className="text-blue-600"
                        />
                        <span className="text-xs">{mode}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex justify-between items-center border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setPaymentMethodView('upi_qr')}
                    className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg flex items-center space-x-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to UPI QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleFinalPaymentAndSubmit}
                    disabled={isProcessing}
                    className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-lg flex items-center space-x-2 shadow-xs transition-colors"
                  >
                    {isProcessing ? (
                      <span>Processing via Treasury Gateway...</span>
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4" />
                        <span>Pay ₹{service.fee} & Submit Application</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 4: SUBMISSION SUCCESS & ACKNOWLEDGMENT */}
        {/* ========================================================================= */}
        {step === 4 && generatedApp && (
          <div className="text-center py-4 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="text-xs font-bold text-emerald-700 uppercase tracking-widest">
              Application Successfully Registered
            </div>

            <h3 className="text-2xl font-extrabold text-[#0A1F44]">
              Reference ID: <span className="font-mono text-blue-700">{generatedApp.id}</span>
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              Your application for <strong>{generatedApp.serviceTitle}</strong> has been transmitted to {generatedApp.department}.
            </p>

            {/* Acknowledgment Slip Card */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left text-xs max-w-lg mx-auto space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Applicant:</span>
                <strong className="text-slate-800">{generatedApp.applicantName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Submission Date:</span>
                <strong className="text-slate-800">{generatedApp.submissionDate}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Estimated Delivery:</span>
                <strong className="text-emerald-700 font-bold">{generatedApp.estimatedCompletionDate}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Status:</span>
                <span className="font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded text-[11px] flex items-center space-x-1">
                  <Check className="w-3 h-3 inline mr-0.5" />
                  <span>{generatedApp.paymentMode || 'Bharat BillPay UPI'}</span>
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Receipt / Txn Ref:</span>
                <strong className="font-mono text-blue-700">{generatedApp.receiptNumber}</strong>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 font-bold">
                <span className="text-slate-700">Fee Amount Realized:</span>
                <span className="text-slate-900">₹{generatedApp.feesPaid}.00</span>
              </div>
            </div>

            {downloadSuccess && (
              <div className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 py-1.5 px-3 rounded-lg max-w-md mx-auto animate-in fade-in">
                ✓ Receipt downloaded successfully! Check your downloads folder.
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-4 py-2.5 rounded-lg border border-slate-300 flex items-center space-x-1.5 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Slip</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadReceipt}
                className="bg-[#1D5FE0] hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Download PDF Receipt</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="bg-[#0A1F44] hover:bg-blue-900 text-white text-xs font-bold px-5 py-2.5 rounded-lg transition-colors shadow-xs"
              >
                Go to Dashboard
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
