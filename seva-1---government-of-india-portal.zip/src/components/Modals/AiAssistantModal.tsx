import React, { useState, useEffect, useRef } from 'react';
import { Bot, Send, User, Sparkles, X, ChevronRight, CornerDownLeft, Volume2, ShieldCheck, Check } from 'lucide-react';
import { SERVICES_LIST } from '../../data/servicesData';
import { SCHEMES_LIST } from '../../data/schemesData';
import { ServiceItem, SchemeItem } from '../../types';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  onSelectService: (service: ServiceItem) => void;
  onSelectScheme: (scheme: SchemeItem) => void;
}

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  actionServiceId?: string;
  actionSchemeId?: string;
  timestamp: string;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  onSelectService,
  onSelectScheme,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'bot',
      text: 'Namaste! I am your SevaMitra AI Assistant, trained on official Government of India rules, citizen charters, and service guidelines. How can I assist you with services, schemes, or grievances today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Handle initial query if passed
  useEffect(() => {
    if (isOpen && initialQuery && initialQuery.trim()) {
      handleUserSendMessage(initialQuery);
    }
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  const quickPrompts = [
    'How do I update address in Aadhaar?',
    'What documents are needed for fresh PAN card?',
    'How do I get PM Kisan ₹6,000 benefit?',
    'Who is eligible for Ayushman Bharat ₹5 Lakh?',
    'How do I track my Driving License dispatch?',
  ];

  const generateBotReply = (query: string): { text: string; serviceId?: string; schemeId?: string } => {
    const q = query.toLowerCase();

    if (q.includes('aadhaar')) {
      return {
        text: 'To update your Aadhaar address online: You will need a valid Proof of Address (Electricity bill, Passport, Bank Passbook, or Rent Agreement). The fee is ₹50 with an SLA of 5–7 working days. You can begin the demographic update directly right here on SEVA 1.',
        serviceId: 'aadhaar-update',
      };
    } else if (q.includes('pan')) {
      return {
        text: 'Applying for an Instant e-PAN or Physical PAN requires your Aadhaar number and linked mobile OTP. Physical card dispatch fee is ₹107, while digital e-PAN is generated in under 10 minutes.',
        serviceId: 'pan-card',
      };
    } else if (q.includes('kisan') || q.includes('farmer')) {
      return {
        text: 'Under PM Kisan Samman Nidhi, all landholding farmer families receive ₹6,000 per year in three 4-monthly installments of ₹2,000 directly via DBT. Mandatory prerequisites are e-KYC and Aadhaar-linked NPCI bank account.',
        schemeId: 'pm-kisan',
      };
    } else if (q.includes('ayushman') || q.includes('health') || q.includes('pm-jay')) {
      return {
        text: 'Ayushman Bharat PM-JAY provides cashless secondary and tertiary hospitalization cover of up to ₹5,00,000 per beneficiary family per year across 28,000+ empaneled public & private hospitals with zero out-of-pocket cost.',
        schemeId: 'ayushman-bharat',
      };
    } else if (q.includes('driving') || q.includes('license') || q.includes('dl')) {
      return {
        text: 'For a Driving License: First apply for Learner License online through contactless Aadhaar-based test, followed by practical track test booking on Parivahan Sarathi after 30 days. Fee is ₹200.',
        serviceId: 'driving-license',
      };
    } else if (q.includes('grievance') || q.includes('complaint') || q.includes('delay') || q.includes('ration')) {
      return {
        text: 'You can lodge a formal complaint on the CPGRAMS Redressal section. All citizen complaints are mandated by the Citizen Charter for resolution within a strict 21-day timeline with real-time SMS updates.',
      };
    } else {
      return {
        text: `I have analyzed your query regarding "${query}". On the SEVA 1 portal, you can access over 1,400 Central & State government services, verify certificates via DigiLocker, and check your DBT welfare entitlement anytime.`,
      };
    }
  };

  const handleUserSendMessage = (queryText: string) => {
    if (!queryText.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const reply = generateBotReply(queryText);
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: reply.text,
        actionServiceId: reply.serviceId,
        actionSchemeId: reply.schemeId,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full h-[620px] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#0A1F44] text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-linear-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center shadow-xs">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h3 className="font-bold text-sm">SevaMitra AI Portal Assistant</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <p className="text-[11px] text-slate-300">National E-Governance Division (NeGD)</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-full text-slate-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat History Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/70 text-xs sm:text-sm">
          {messages.map((m) => {
            const isBot = m.sender === 'bot';
            return (
              <div key={m.id} className={`flex items-start space-x-2.5 ${isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    isBot ? 'bg-[#0A1F44] text-white' : 'bg-blue-600 text-white'
                  }`}
                >
                  {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                <div className={`max-w-[82%] space-y-2`}>
                  <div
                    className={`p-3.5 rounded-2xl leading-relaxed ${
                      isBot
                        ? 'bg-white text-slate-800 border border-slate-200/90 shadow-2xs'
                        : 'bg-[#0A1F44] text-white'
                    }`}
                  >
                    <p>{m.text}</p>
                    <span
                      className={`text-[10px] block mt-1 ${
                        isBot ? 'text-slate-400' : 'text-slate-300 text-right'
                      }`}
                    >
                      {m.timestamp}
                    </span>
                  </div>

                  {/* Contextual Action Button if service or scheme matched */}
                  {m.actionServiceId && (
                    <button
                      onClick={() => {
                        const s = SERVICES_LIST.find((item) => item.id === m.actionServiceId);
                        if (s) {
                          onSelectService(s);
                          onClose();
                        }
                      }}
                      className="inline-flex items-center space-x-1.5 bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors"
                    >
                      <span>Open Application Form</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {m.actionSchemeId && (
                    <button
                      onClick={() => {
                        const sc = SCHEMES_LIST.find((item) => item.id === m.actionSchemeId);
                        if (sc) {
                          onSelectScheme(sc);
                          onClose();
                        }
                      }}
                      className="inline-flex items-center space-x-1.5 bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      <span>Check Scheme Details</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center space-x-2 text-slate-400 text-xs italic pl-10">
              <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce delay-100" />
              <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce delay-200" />
              <span>SevaMitra is referencing official government rules...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleUserSendMessage(prompt)}
              className="text-[11px] bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 px-2.5 py-1 rounded-full whitespace-nowrap border border-slate-200 transition-colors shrink-0 font-medium"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleUserSendMessage(input);
          }}
          className="p-3 bg-white border-t border-slate-200 flex items-center space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your question about any government service or scheme..."
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="bg-[#0A1F44] hover:bg-blue-900 disabled:opacity-40 text-white p-2.5 rounded-xl transition-colors shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
