import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  Send,
  User,
  Sparkles,
  X,
  ChevronRight,
  ShieldCheck,
  CreditCard,
  FileText,
  Compass,
  MessageSquare,
  Zap,
  RotateCcw
} from 'lucide-react';
import { SERVICES_LIST } from '../../data/servicesData';
import { SCHEMES_LIST } from '../../data/schemesData';
import { ServiceItem, SchemeItem } from '../../types';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  onSelectService: (service: ServiceItem) => void;
  onSelectScheme: (scheme: SchemeItem) => void;
}

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  actionServiceId?: string;
  actionSchemeId?: string;
  timestamp: string;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  onSelectService,
  onSelectScheme,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'bot',
      text: 'Namaste! I am your SevaMitra AI Assistant, powered by official Government of India citizen charters and digital service databases. How can I assist you with public services, direct welfare benefits, or grievance redressal today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Handle initial query if passed
  useEffect(() => {
    if (isOpen && initialQuery && initialQuery.trim()) {
      handleUserSendMessage(initialQuery);
    }
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  const quickPrompts = [
    { label: 'Update Aadhaar Address', query: 'How do I update my address in Aadhaar online?' },
    { label: 'Instant e-PAN Card', query: 'What is the procedure for getting an instant e-PAN card?' },
    { label: 'PM Kisan ₹6,000 Status', query: 'How do I check my PM Kisan 19th installment and DBT link?' },
    { label: 'Ayushman ₹5 Lakh Card', query: 'Who is eligible for Ayushman Bharat 5 Lakh hospitalization coverage?' },
    { label: 'Driving License Online', query: 'How do I apply for a Learner & Driving License on Sarathi Parivahan?' },
    { label: 'Lodge CPGRAMS Grievance', query: 'How do I file a grievance against ration delay on CPGRAMS?' },
  ];

  const generateBotReply = (query: string): { text: string; serviceId?: string; schemeId?: string } => {
    const q = query.toLowerCase();

    if (q.includes('aadhaar') || q.includes('aadhar') || q.includes('uidai')) {
      return {
        text: 'To update your Aadhaar address online: You will need a valid Proof of Address (Electricity bill, Passport, Bank Passbook, or Rent Agreement). The fee is ₹50 with an SLA of 3–5 working days. You can start the demographic update directly right here on SEVA 1.',
        serviceId: 'aadhaar-update',
      };
    } else if (q.includes('pan') || q.includes('e-pan') || q.includes('tax')) {
      return {
        text: 'Applying for an Instant e-PAN or Physical PAN requires your Aadhaar number and linked mobile OTP. Digital e-PAN is generated in under 10 minutes with zero fee, while physical PVC card dispatch is ₹107.',
        serviceId: 'pan-card',
      };
    } else if (q.includes('kisan') || q.includes('farmer') || q.includes('6000') || q.includes('krishi')) {
      return {
        text: 'Under PM Kisan Samman Nidhi, eligible landholding farmer families receive ₹6,000 per year in three 4-monthly installments of ₹2,000 directly via DBT into their Aadhaar-seeded bank account. Mandatory prerequisites are e-KYC and land record linkage.',
        schemeId: 'pm-kisan',
      };
    } else if (q.includes('ayushman') || q.includes('health') || q.includes('pmjay') || q.includes('hospital')) {
      return {
        text: 'Ayushman Bharat PM-JAY provides cashless secondary and tertiary hospitalization cover of up to ₹5,00,000 per beneficiary family per year across 28,000+ empaneled public & private hospitals with zero out-of-pocket costs.',
        schemeId: 'ayushman-bharat',
      };
    } else if (q.includes('driving') || q.includes('license') || q.includes('dl') || q.includes('sarathi')) {
      return {
        text: 'For a Driving License: First apply for Learner License online through contactless Aadhaar-based test on Parivahan Sarathi, followed by booking your practical track test appointment after 30 days. Government fee is ₹350.',
        serviceId: 'driving-license',
      };
    } else if (q.includes('ration') || q.includes('rashan') || q.includes('food') || q.includes('nfsa')) {
      return {
        text: 'NFSA Ration Cards provide subsidized foodgrains and portability under One Nation One Ration Card across all state fair price shops. You can submit your digital application and link family Aadhaar numbers seamlessly.',
        serviceId: 'ration-card',
      };
    } else if (q.includes('grievance') || q.includes('complaint') || q.includes('cpgrams') || q.includes('delay')) {
      return {
        text: 'You can lodge a formal public grievance on the CPGRAMS portal section of SEVA 1. Under the Central Citizen Charter, all complaints are mandated for officer scrutiny and resolution within 21 days with real-time SMS updates.',
      };
    } else {
      return {
        text: `I have analyzed your request regarding "${query}". On SEVA 1, you can directly access 1,400+ Central and State public services, download verified DigiLocker certificates, check your DBT welfare entitlement, and track application SLAs in real time.`,
      };
    }
  };

  const handleUserSendMessage = (queryText: string) => {
    if (!queryText.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const reply = generateBotReply(queryText);
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: reply.text,
        actionServiceId: reply.serviceId,
        actionSchemeId: reply.schemeId,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 500);
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: '1',
        sender: 'bot',
        text: 'Chat history refreshed. How may I assist you with government services or schemes today?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl sm:rounded-3xl max-w-xl w-full h-[640px] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-gradient-to-r from-[#0A1F44] via-[#102a5c] to-[#1D5FE0] text-white p-4 sm:p-4.5 flex items-center justify-between shadow-md">
          <div className="flex items-center space-x-3 min-w-0">
            {/* Alive Bot Avatar */}
            <div className="relative shrink-0">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#1D5FE0] to-[#00C9A7] text-white flex items-center justify-center shadow-md ring-2 ring-white/20">
                <Bot className="w-5 h-5" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border-2 border-[#0A1F44]" />
              </span>
            </div>

            <div className="min-w-0">
              <div className="flex items-center space-x-1.5">
                <h3 className="font-extrabold text-sm sm:text-base tracking-tight truncate">
                  SevaMitra AI Citizen Assistant
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.2 rounded-full font-bold">
                  24×7
                </span>
              </div>
              <p className="text-[11px] text-blue-200 truncate">
                Government of India • National E-Governance Division (NeGD)
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1 shrink-0">
            <button
              onClick={handleResetChat}
              className="p-1.5 hover:bg-white/10 rounded-lg text-blue-200 hover:text-white transition-colors"
              title="Reset Conversation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-white/10 rounded-lg text-blue-200 hover:text-white transition-colors"
              title="Close Dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Chat History Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/70 text-xs sm:text-sm">
          {messages.map((m) => {
            const isBot = m.sender === 'bot';
            return (
              <div
                key={m.id}
                className={`flex items-start space-x-2.5 ${isBot ? '' : 'flex-row-reverse space-x-reverse'}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
                    isBot ? 'bg-[#0A1F44] text-white' : 'bg-[#1D5FE0] text-white'
                  }`}
                >
                  {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                <div className="max-w-[84%] space-y-2">
                  <div
                    className={`p-3.5 sm:p-4 rounded-2xl leading-relaxed shadow-2xs ${
                      isBot
                        ? 'bg-white text-slate-800 border border-slate-200/90'
                        : 'bg-gradient-to-r from-[#1D5FE0] to-[#0A47B8] text-white'
                    }`}
                  >
                    <p className="font-medium whitespace-pre-line">{m.text}</p>
                    <span
                      className={`text-[10px] block mt-1.5 font-semibold ${
                        isBot ? 'text-slate-400' : 'text-blue-200 text-right'
                      }`}
                    >
                      {m.timestamp}
                    </span>
                  </div>

                  {/* Contextual Action Button if service or scheme matched */}
                  {m.actionServiceId && (
                    <button
                      onClick={() => {
                        const s = SERVICES_LIST.find((item) => item.id === m.actionServiceId);
                        if (s) {
                          onSelectService(s);
                          onClose();
                        }
                      }}
                      className="inline-flex items-center space-x-1.5 bg-blue-50 text-[#1D5FE0] hover:bg-[#1D5FE0] hover:text-white border border-blue-200 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-2xs active:scale-95"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Open Service Application Form</span>
                      <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </button>
                  )}

                  {m.actionSchemeId && (
                    <button
                      onClick={() => {
                        const sc = SCHEMES_LIST.find((item) => item.id === m.actionSchemeId);
                        if (sc) {
                          onSelectScheme(sc);
                          onClose();
                        }
                      }}
                      className="inline-flex items-center space-x-1.5 bg-amber-50 text-[#F5893C] hover:bg-[#F5893C] hover:text-white border border-amber-200 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-2xs active:scale-95"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Check Welfare Scheme Eligibility</span>
                      <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center space-x-2 text-slate-500 text-xs italic pl-11 py-1">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-bounce delay-100" />
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-bounce delay-200" />
              <span className="font-semibold text-slate-600">SevaMitra is referencing official government rules...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 pl-1 shrink-0 flex items-center space-x-1">
            <Zap className="w-3 h-3 text-amber-500" />
            <span>Try:</span>
          </div>
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleUserSendMessage(prompt.query)}
              className="text-[11px] bg-slate-50 hover:bg-blue-50 hover:text-[#1D5FE0] text-slate-700 px-3 py-1 rounded-full whitespace-nowrap border border-slate-200/80 hover:border-blue-300 transition-all shrink-0 font-semibold"
            >
              {prompt.label}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleUserSendMessage(input);
          }}
          className="p-3 bg-white border-t border-slate-200 flex items-center space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your question about any government service, scheme, or certificate..."
            className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white font-medium"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="bg-[#1D5FE0] hover:bg-[#0A1F44] disabled:opacity-40 text-white p-2.5 rounded-xl transition-colors shadow-md shadow-blue-500/20 active:scale-95"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
