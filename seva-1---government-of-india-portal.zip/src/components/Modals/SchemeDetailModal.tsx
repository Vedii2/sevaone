import React from 'react';
import { SchemeItem, UserProfile } from '../../types';
import {
  Sparkles,
  CheckCircle2,
  Building2,
  IndianRupee,
  FileText,
  ShieldCheck,
  Download,
  Users,
  Calendar,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SchemeDetailModalProps {
  scheme: SchemeItem | null;
  user?: UserProfile;
  onClose: () => void;
  onCheckEligibility: (scheme: SchemeItem) => void;
}

export const SchemeDetailModal: React.FC<SchemeDetailModalProps> = ({
  scheme,
  user,
  onClose,
  onCheckEligibility,
}) => {
  if (!scheme) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-200">
          <div>
            <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">
              {scheme.ministry}
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#0A1F44] mt-1">
              {scheme.name}
            </h2>
            <div className="mt-2 inline-flex items-center space-x-2">
              <span className="bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold px-2.5 py-0.5 rounded-md">
                Direct Benefit: {scheme.benefitAmount}
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-md">
                DBT Active
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700"
          >
            ✕
          </button>
        </div>

        {/* Scheme Summary */}
        <div className="my-5">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Official Scheme Objective
          </h4>
          <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200">
            {scheme.summary}
          </p>
        </div>

        {/* Eligibility Criteria */}
        <div className="my-5">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Prescribed Eligibility Criteria
          </h4>
          <div className="space-y-2">
            {scheme.eligibilityCriteria.map((crit, idx) => (
              <div key={idx} className="flex items-start space-x-2 text-xs sm:text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{crit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Required Documents */}
        <div className="my-5">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Required Documents for Verification
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {scheme.requiredDocuments.map((doc, idx) => (
              <div key={idx} className="flex items-center space-x-2 p-2.5 rounded-lg bg-blue-50/60 border border-blue-200 text-xs font-medium text-blue-950">
                <FileText className="w-4 h-4 text-blue-700 shrink-0" />
                <span>{doc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mt-4 pt-4 border-t border-slate-100">
          {scheme.tags.map((tag, idx) => (
            <span key={idx} className="text-xs font-semibold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md">
              #{tag}
            </span>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="mt-6 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => {
              confetti({ particleCount: 40 });
              alert(`Downloading Scheme Gazette Guidelines for ${scheme.name}`);
            }}
            className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center space-x-1"
          >
            <Download className="w-4 h-4" />
            <span>Download Official Gazette Guidelines (PDF)</span>
          </button>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Close
            </button>
            <button
              onClick={() => {
                onCheckEligibility(scheme);
                onClose();
              }}
              className="flex-1 sm:flex-none bg-[#F5893C] hover:bg-[#e0772d] text-slate-950 font-extrabold text-xs sm:text-sm px-5 py-2.5 rounded-lg shadow-xs flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Check My Eligibility</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
