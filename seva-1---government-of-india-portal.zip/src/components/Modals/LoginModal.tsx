import React, { useState } from 'react';
import { AshokaEmblem } from '../Common/AshokaEmblem';
import { IndianFlagBadge } from '../Common/IndianFlagBadge';
import { UserProfile } from '../../types';
import {
  ShieldCheck,
  Smartphone,
  KeyRound,
  ArrowRight,
  CheckCircle2,
  Lock,
  User,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [authMethod, setAuthMethod] = useState<'aadhaar' | 'phone' | 'meripehchaan'>('aadhaar');
  const [identifier, setIdentifier] = useState('XXXX-XXXX-8921');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'input' | 'otp'>('input');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setError('Please enter your Aadhaar or Mobile Number');
      return;
    }
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      setOtp('738291'); // Auto-suggest or demo OTP
    }, 700);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('Please enter a valid 6-digit OTP');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const authenticatedUser: UserProfile = {
        name: 'Rajesh Kumar Sharma',
        aadhaarMasked: 'XXXX-XXXX-8921',
        panMasked: 'ABCPS8921K',
        phone: '+91 98765 43210',
        email: 'rajesh.sharma@nic.in',
        address: 'House No. 42, Sector 14, Rohini, New Delhi - 110085',
        city: 'New Delhi',
        state: 'Delhi',
        pincode: '110085',
        district: 'North West Delhi',
        digiLockerLinked: true,
        isLoggedIn: true,
      };

      confetti({ particleCount: 70, spread: 70 });
      onLoginSuccess(authenticatedUser);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 relative">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
        >
          ✕
        </button>

        {/* Header Branding */}
        <div className="text-center pb-5 border-b border-slate-100">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <AshokaEmblem size={36} color="#0A1F44" />
            <IndianFlagBadge />
          </div>
          <h2 className="text-xl font-bold text-[#0A1F44]">MeriPehchaan Citizen Login</h2>
          <p className="text-xs text-slate-500 mt-0.5">National Single Sign-On (NSSO) Portal</p>
        </div>

        {/* Auth Method Selector */}
        <div className="grid grid-cols-3 gap-2 my-5 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setAuthMethod('aadhaar');
              setIdentifier('XXXX-XXXX-8921');
              setStep('input');
            }}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              authMethod === 'aadhaar'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Aadhaar OTP
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMethod('phone');
              setIdentifier('+91 98765 43210');
              setStep('input');
            }}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              authMethod === 'phone'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Mobile OTP
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMethod('meripehchaan');
              setIdentifier('rajesh.sharma@gov');
              setStep('input');
            }}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              authMethod === 'meripehchaan'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            DigiLocker SSO
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Step 1: Input Identifier */}
        {step === 'input' && (
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                {authMethod === 'aadhaar'
                  ? 'Enter 12-Digit Aadhaar Number'
                  : authMethod === 'phone'
                  ? 'Enter Registered Mobile Number'
                  : 'Enter MeriPehchaan Username'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={authMethod === 'aadhaar' ? '1234 5678 9012' : '+91 98765 43210'}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-slate-800"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                A one-time password (OTP) will be sent to your UIDAI registered mobile number.
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#0A1F44] hover:bg-blue-900 active:scale-95 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <span>Generating OTP...</span>
              ) : (
                <>
                  <span>Send Verification OTP</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Step 2: Enter OTP */}
        {step === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Enter 6-Digit OTP
                </label>
                <button
                  type="button"
                  onClick={() => setStep('input')}
                  className="text-xs text-blue-700 hover:underline"
                >
                  Change Number
                </button>
              </div>
              <input
                type="text"
                required
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="738291"
                className="w-full text-center text-xl tracking-widest font-mono py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold text-[#0A1F44]"
              />
              <div className="flex justify-between items-center text-[11px] text-slate-400 mt-2">
                <span>OTP sent to: {identifier}</span>
                <span className="text-emerald-700 font-bold">Demo OTP: 738291</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <span>Verifying with UIDAI...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Authenticate & Log In</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Footer Security Note */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-center space-x-2 text-[11px] text-slate-500">
          <Lock className="w-3.5 h-3.5 text-emerald-600" />
          <span>256-bit SSL Encrypted • Aadhaar Compliant (UIDAI)</span>
        </div>

      </div>
    </div>
  );
};
