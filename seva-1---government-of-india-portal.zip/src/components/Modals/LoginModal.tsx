import React, { useState, useEffect } from 'react';
import { AshokaEmblem } from '../Common/AshokaEmblem';
import { IndianFlagBadge } from '../Common/IndianFlagBadge';
import { UserProfile, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  ShieldCheck,
  Smartphone,
  KeyRound,
  ArrowRight,
  CheckCircle2,
  Lock,
  User,
  AlertCircle,
  UserPlus,
  LogIn,
  Calendar,
  MapPin,
  Mail,
  Sparkles,
  Check,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  currentUser?: UserProfile;
  currentLanguage?: LanguageCode;
}

// 4 Distinct Verified Demo Citizen Personas for Multi-Account & Regression Testing
export const PRESET_ACCOUNTS: UserProfile[] = [
  {
    name: 'Priya Sharma',
    dob: '1995-11-22',
    gender: 'Female',
    phone: '+91 94123 78901',
    email: 'priya.sharma@nic.in',
    aadhaarMasked: 'XXXX-XXXX-5514',
    panMasked: 'CPQPS5514K',
    address: 'B-12, Gomti Nagar Extension, Lucknow - 226010',
    city: 'Lucknow',
    district: 'Lucknow',
    state: 'Uttar Pradesh',
    pincode: '226010',
    digiLockerLinked: true,
    isLoggedIn: true,
  },
  {
    name: 'Rajesh Gupta',
    dob: '1987-04-18',
    gender: 'Male',
    phone: '+91 98112 34567',
    email: 'rajesh.gupta@govmail.in',
    aadhaarMasked: 'XXXX-XXXX-4102',
    panMasked: 'BGVPG4102J',
    address: 'H-44, Vikas Marg, Preet Vihar, New Delhi - 110092',
    city: 'New Delhi',
    district: 'East Delhi',
    state: 'Delhi (NCT)',
    pincode: '110092',
    digiLockerLinked: true,
    isLoggedIn: true,
  },
  {
    name: 'Amitabh Verma',
    dob: '1982-03-05',
    gender: 'Male',
    phone: '+91 99887 66554',
    email: 'amitabh.verma@digitalindia.gov.in',
    aadhaarMasked: 'XXXX-XXXX-9932',
    panMasked: 'AVKPV9932B',
    address: '74, Indiranagar 100ft Road, Bengaluru - 560038',
    city: 'Bengaluru',
    district: 'Bengaluru Urban',
    state: 'Karnataka',
    pincode: '560038',
    digiLockerLinked: true,
    isLoggedIn: true,
  },
  {
    name: 'Manasvi Raut',
    dob: '1998-08-14',
    gender: 'Female',
    phone: '+91 98201 45678',
    email: 'manasvi.raut@govmail.in',
    aadhaarMasked: 'XXXX-XXXX-7721',
    panMasked: 'BMQPR7721M',
    address: 'Flat 402, Shivam Enclave, Bandra West, Mumbai - 400050',
    city: 'Mumbai',
    district: 'Mumbai Suburban',
    state: 'Maharashtra',
    pincode: '400050',
    digiLockerLinked: true,
    isLoggedIn: true,
  },
];

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentUser,
  currentLanguage = 'en',
}) => {
  const [modalMode, setModalMode] = useState<'signin' | 'register'>('signin');
  
  // Custom Sign In Form state
  const [customName, setCustomName] = useState('');
  const [customPhone, setCustomPhone] = useState('');
  const [customAadhaar, setCustomAadhaar] = useState('');
  const [customDob, setCustomDob] = useState('1992-06-15');
  const [customState, setCustomState] = useState('Delhi (NCT)');
  const [customAddress, setCustomAddress] = useState('Sector 14, Rohini, New Delhi - 110085');

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regDob, setRegDob] = useState('1994-08-20');
  const [regGender, setRegGender] = useState('Female');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regAadhaar, setRegAadhaar] = useState('');
  const [regPan, setRegPan] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regCity, setRegCity] = useState('');
  const [regDistrict, setRegDistrict] = useState('');
  const [regState, setRegState] = useState('Maharashtra');
  const [regPincode, setRegPincode] = useState('');
  const [regDigiLocker, setRegDigiLocker] = useState(true);

  // OTP Verification state
  const [step, setStep] = useState<'input' | 'otp'>('input');
  const [sessionOtp, setSessionOtp] = useState<string>('749201');
  const [otp, setOtp] = useState('');
  const [pendingUser, setPendingUser] = useState<UserProfile | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Reset form whenever modal opens or closes
  useEffect(() => {
    if (isOpen) {
      setStep('input');
      setError('');
      setIsLoading(false);
      setOtp('');
      setPendingUser(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Dynamic 6-Digit OTP Generator for every authentication session
  const generateNewSessionOtp = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  // Mask Aadhaar helper strictly based on real input digits
  const maskAadhaarNumber = (raw: string, fallbackPhone?: string): string => {
    const cleaned = raw.replace(/\D/g, '');
    if (cleaned.length >= 4) {
      const last4 = cleaned.slice(-4);
      return `XXXX-XXXX-${last4}`;
    }
    if (fallbackPhone) {
      const pClean = fallbackPhone.replace(/\D/g, '');
      const pLast4 = pClean.slice(-4);
      if (pLast4.length === 4) {
        return `XXXX-XXXX-${pLast4}`;
      }
    }
    const rand4 = Math.floor(1000 + Math.random() * 9000).toString();
    return `XXXX-XXXX-${rand4}`;
  };

  // Mask PAN helper strictly based on real input
  const maskPanNumber = (raw: string, fallbackPhone?: string): string => {
    const cleaned = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (cleaned.length >= 5) {
      return `${cleaned.slice(0, 5)}****${cleaned.slice(-1)}`;
    }
    const suffix = fallbackPhone ? fallbackPhone.replace(/\D/g, '').slice(-3) : '482';
    return `ABCPS${suffix}K`;
  };

  // Handle Preset Account Quick Sign-In
  const handleSelectPreset = (preset: UserProfile) => {
    setIsLoading(true);
    const newOtp = generateNewSessionOtp();
    setSessionOtp(newOtp);
    setPendingUser(preset);
    setError('');

    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      setOtp(newOtp);
    }, 350);
  };

  // Handle Custom Sign In Submission
  const handleCustomSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) {
      setError('Please enter your Full Legal Name');
      return;
    }
    if (!customPhone.trim()) {
      setError('Please enter your Registered Mobile Number');
      return;
    }

    const cleanPhone = customPhone.trim();
    const formattedPhone = cleanPhone.startsWith('+91')
      ? cleanPhone
      : `+91 ${cleanPhone.replace(/\s+/g, '')}`;

    const constructedUser: UserProfile = {
      name: customName.trim(),
      dob: customDob,
      gender: 'General',
      phone: formattedPhone,
      email: `${customName.toLowerCase().replace(/[^a-z0-9]/g, '.')}@govmail.in`,
      aadhaarMasked: maskAadhaarNumber(customAadhaar, cleanPhone),
      panMasked: maskPanNumber('', cleanPhone),
      address: customAddress.trim() || 'National Capital Territory, India',
      city: customAddress.includes(',') ? customAddress.split(',')[0].trim() : 'New Delhi',
      district: 'Central',
      state: customState,
      pincode: customAddress.match(/\b\d{6}\b/)?.[0] || '110001',
      digiLockerLinked: true,
      isLoggedIn: true,
    };

    const newOtp = generateNewSessionOtp();
    setSessionOtp(newOtp);
    setPendingUser(constructedUser);
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      setOtp(newOtp);
    }, 450);
  };

  // Handle Register Form Submission
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim()) {
      setError('Please enter your Full Legal Name');
      return;
    }
    if (!regPhone.trim()) {
      setError('Please enter your Mobile Number');
      return;
    }
    if (!regAddress.trim()) {
      setError('Please enter your Residential Address');
      return;
    }

    const cleanPhone = regPhone.trim();
    const formattedPhone = cleanPhone.startsWith('+91')
      ? cleanPhone
      : `+91 ${cleanPhone.replace(/\s+/g, '')}`;

    const newUser: UserProfile = {
      name: regName.trim(),
      dob: regDob,
      gender: regGender,
      phone: formattedPhone,
      email: regEmail.trim() || `${regName.toLowerCase().replace(/[^a-z0-9]/g, '.')}@govmail.in`,
      aadhaarMasked: maskAadhaarNumber(regAadhaar, cleanPhone),
      panMasked: maskPanNumber(regPan, cleanPhone),
      address: regAddress.trim(),
      city: regCity.trim() || 'Mumbai',
      district: regDistrict.trim() || regCity.trim() || 'Urban',
      state: regState,
      pincode: regPincode.trim() || '400001',
      digiLockerLinked: regDigiLocker,
      isLoggedIn: true,
    };

    const newOtp = generateNewSessionOtp();
    setSessionOtp(newOtp);
    setPendingUser(newUser);
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setStep('otp');
      setOtp(newOtp);
    }, 450);
  };

  // Handle OTP Verification & Final Login
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('Please enter a valid 6-digit OTP');
      return;
    }

    if (!pendingUser) {
      setError('Session expired. Please try again.');
      setStep('input');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      confetti({ particleCount: 80, spread: 75, origin: { y: 0.6 } });
      
      try {
        localStorage.removeItem('SEVA1_LOGGED_OUT');
        localStorage.setItem('SEVA1_ACTIVE_USER', JSON.stringify(pendingUser));
      } catch (err) {
        console.warn('Storage error', err);
      }

      onLoginSuccess(pendingUser);
      onClose();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 relative my-8">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors"
          title="Close Modal"
        >
          ✕
        </button>

        {/* Top Official Header Branding */}
        <div className="text-center pb-4 border-b border-slate-100">
          <div className="flex items-center justify-center space-x-2.5 mb-2">
            <AshokaEmblem size="sm" variant="gold" />
            <IndianFlagBadge size="sm" />
          </div>
          <div className="text-xs font-bold text-amber-700 font-serif tracking-wider mb-0.5">
            सत्यमेव जयते
          </div>
          <h2 className="text-xl font-extrabold text-[#0A1F44]">
            {modalMode === 'signin' ? t.authTitleSignIn : t.authTitleRegister}
          </h2>
          <p className="text-[11px] text-slate-500 font-medium mt-0.5">
            National Single Sign-On (NSSO) • Government of India
          </p>
        </div>

        {/* Mode Switcher: Sign In vs Register (only in input step) */}
        {step === 'input' && (
          <div className="grid grid-cols-2 gap-1.5 my-4 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setModalMode('signin');
                setError('');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
                modalMode === 'signin'
                  ? 'bg-[#0A1F44] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{t.signInTab}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setModalMode('register');
                setError('');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
                modalMode === 'register'
                  ? 'bg-[#0A1F44] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{t.registerTab}</span>
            </button>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 1: SIGN IN MODE (Custom Input or 1-Click Persona Switcher) */}
        {/* ========================================================================= */}
        {step === 'input' && modalMode === 'signin' && (
          <div className="space-y-4">
            
            {/* Quick-Select Demo Citizen Personas for Multi-Account Testing */}
            <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200/80">
              <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>⚡ {t.testCitizensTitle}:</span>
                <span className="text-[10px] text-blue-700 font-normal">Click to test instant login</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {PRESET_ACCOUNTS.map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className="p-2 bg-white hover:bg-[#1D5FE0] hover:text-white rounded-lg border border-blue-200 text-left transition-all shadow-2xs group"
                  >
                    <div className="font-bold text-xs text-slate-800 group-hover:text-white truncate">
                      {preset.name}
                    </div>
                    <div className="text-[10px] text-slate-500 group-hover:text-blue-100 truncate">
                      {preset.city}, {preset.state.split(' ')[0]}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-200"></div>
              <span className="flex-shrink mx-3 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                {t.orEnterRealDetails}
              </span>
              <div className="flex-grow border-t border-slate-200"></div>
            </div>

            {/* Custom Details Form */}
            <form onSubmit={handleCustomSignIn} className="space-y-3 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.fullNameLabel} *
                </label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. Priya Sharma, Rajesh Gupta"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t.mobileNumberLabel} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customPhone}
                    onChange={(e) => setCustomPhone(e.target.value)}
                    placeholder="9876543210"
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t.dobLabel}
                  </label>
                  <input
                    type="date"
                    value={customDob}
                    onChange={(e) => setCustomDob(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t.aadhaarLabel} (12 Digits or Last 4)
                  </label>
                  <input
                    type="text"
                    value={customAadhaar}
                    onChange={(e) => setCustomAadhaar(e.target.value)}
                    placeholder="e.g. 5514 or 9876 5432 5514"
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    {t.stateLabel}
                  </label>
                  <select
                    value={customState}
                    onChange={(e) => setCustomState(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Delhi (NCT)">Delhi (NCT)</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="West Bengal">West Bengal</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Other State / UT">Other State / UT</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.addressLabel}
                </label>
                <input
                  type="text"
                  value={customAddress}
                  onChange={(e) => setCustomAddress(e.target.value)}
                  placeholder="Flat No, Building, Street, City"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 bg-[#0A1F44] hover:bg-blue-900 active:scale-95 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isLoading ? (
                  <span>Generating OTP...</span>
                ) : (
                  <>
                    <span>{t.generateOtpButton}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: REGISTER NEW ACCOUNT FORM */}
        {/* ========================================================================= */}
        {step === 'input' && modalMode === 'register' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
            <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Registering creates a national citizen record linked with DigiLocker.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                {t.fullNameLabel} (as in Aadhaar) *
              </label>
              <input
                type="text"
                required
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="e.g. Ramesh Kumar, Sunita Devi"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.dobLabel} *
                </label>
                <input
                  type="date"
                  required
                  value={regDob}
                  onChange={(e) => setRegDob(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.genderLabel} *
                </label>
                <select
                  value={regGender}
                  onChange={(e) => setRegGender(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Third Gender / Other">Third Gender / Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.mobileNumberLabel} *
                </label>
                <input
                  type="tel"
                  required
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="9876543210"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="citizen@gmail.com"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.aadhaarLabel} *
                </label>
                <input
                  type="text"
                  required
                  value={regAadhaar}
                  onChange={(e) => setRegAadhaar(e.target.value)}
                  placeholder="e.g. 1234 5678 9012"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  {t.panLabel} (Optional)
                </label>
                <input
                  type="text"
                  value={regPan}
                  onChange={(e) => setRegPan(e.target.value.toUpperCase())}
                  placeholder="ABCPS1234K"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                {t.addressLabel} *
              </label>
              <textarea
                rows={2}
                required
                value={regAddress}
                onChange={(e) => setRegAddress(e.target.value)}
                placeholder="House No, Apartment, Landmark, Area"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  {t.cityLabel} *
                </label>
                <input
                  type="text"
                  required
                  value={regCity}
                  onChange={(e) => setRegCity(e.target.value)}
                  placeholder="Mumbai"
                  className="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  {t.stateLabel} *
                </label>
                <select
                  value={regState}
                  onChange={(e) => setRegState(e.target.value)}
                  className="w-full px-2 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="Maharashtra">Maharashtra</option>
                  <option value="Delhi (NCT)">Delhi (NCT)</option>
                  <option value="Uttar Pradesh">Uttar Pradesh</option>
                  <option value="Karnataka">Karnataka</option>
                  <option value="Tamil Nadu">Tamil Nadu</option>
                  <option value="Gujarat">Gujarat</option>
                  <option value="West Bengal">West Bengal</option>
                  <option value="Rajasthan">Rajasthan</option>
                  <option value="Punjab">Punjab</option>
                  <option value="Odisha">Odisha</option>
                  <option value="Kerala">Kerala</option>
                  <option value="Telangana">Telangana</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  {t.pincodeLabel} *
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={regPincode}
                  onChange={(e) => setRegPincode(e.target.value)}
                  placeholder="400050"
                  className="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>
            </div>

            <label className="flex items-center space-x-2 pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={regDigiLocker}
                onChange={(e) => setRegDigiLocker(e.target.checked)}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-xs text-slate-700 font-medium">
                Auto-link DigiLocker Vault & fetch issued government certificates
              </span>
            </label>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 bg-[#0A1F44] hover:bg-blue-900 active:scale-95 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Registering Citizen Record...</span>
              ) : (
                <>
                  <span>Create Account & Verify OTP</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: DYNAMIC OTP VERIFICATION STEP (STRICTLY BOUND TO CURRENT ATTEMPT) */}
        {/* ========================================================================= */}
        {step === 'otp' && pendingUser && (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-200 text-xs text-blue-950 space-y-1.5 shadow-2xs">
              <div className="font-bold flex items-center justify-between">
                <span className="text-sm font-black text-[#0A1F44]">
                  {t.citizenLabel}: {pendingUser.name}
                </span>
                <span className="text-emerald-700 bg-emerald-100/70 border border-emerald-300 px-2 py-0.5 rounded text-[11px] font-bold">
                  ✓ {t.aadhaarVerifiedBadge}
                </span>
              </div>
              <div className="text-[11px] text-slate-700 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span>
                  {t.aadhaarLabel}: <strong className="font-mono text-blue-900 font-bold">{pendingUser.aadhaarMasked}</strong>
                </span>
                <span>•</span>
                <span>
                  {t.mobileNumberLabel}: <strong className="text-blue-900 font-bold">{pendingUser.phone}</strong>
                </span>
                <span>•</span>
                <span>
                  {t.stateLabel}: <strong className="text-blue-900 font-bold">{pendingUser.state}</strong>
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  {t.otpHeader}
                </label>
                <button
                  type="button"
                  onClick={() => setStep('input')}
                  className="text-xs text-blue-700 hover:underline font-semibold cursor-pointer"
                >
                  Edit Details
                </button>
              </div>
              <input
                type="text"
                required
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder={sessionOtp}
                className="w-full text-center text-2xl tracking-widest font-mono py-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold text-[#0A1F44]"
              />
              <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2">
                <span>UIDAI OTP sent via SMS to {pendingUser.phone}</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {t.demoOtpLabel}: {sessionOtp}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold py-2.5 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Validating with UIDAI Gateway...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>{t.verifyOtpButton}</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Footer Security Note */}
        <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-center space-x-2 text-[11px] text-slate-500">
          <Lock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>256-bit SSL Encrypted • Aadhaar Compliant (UIDAI & MeitY)</span>
        </div>

      </div>
    </div>
  );
};
