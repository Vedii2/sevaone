import React, { useState } from 'react';
import { GrievanceTicket, LanguageCode, UserProfile } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  AlertCircle,
  ShieldCheck,
  Send,
  Upload,
  CheckCircle2,
  Clock,
  Building2,
  FileText,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GrievanceSectionProps {
  currentLanguage: LanguageCode;
  user: UserProfile;
  grievances: GrievanceTicket[];
  onFileGrievance: (grievance: GrievanceTicket) => void;
}

export const GrievanceSection: React.FC<GrievanceSectionProps> = ({
  currentLanguage,
  user,
  grievances,
  onFileGrievance,
}) => {
  const [department, setDepartment] = useState('Unique Identification Authority of India (UIDAI)');
  const [category, setCategory] = useState('Demographic Update Delay');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [stateDistrict, setStateDistrict] = useState('Delhi - New Delhi Central');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [submittedTicket, setSubmittedTicket] = useState<GrievanceTicket | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const departmentsList = [
    'Unique Identification Authority of India (UIDAI)',
    'Ministry of Road Transport and Highways (Sarathi/Vahan)',
    'Department of Food and Public Distribution (Ration & NFSA)',
    'Department of Telecommunications (BSNL / MTNL)',
    'Ministry of Health and Family Welfare (PM-JAY)',
    'Income Tax Department / Central Board of Direct Taxes',
    'Ministry of External Affairs (Passport Seva)',
    'Department of Higher Education & Scholarships (NSP)',
    'Department of Agriculture & Farmers Welfare (PM Kisan)',
    'Ministry of Housing and Urban Affairs (PMAY)',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const newTicketId = `GRV-CPGRAMS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const newTicket: GrievanceTicket = {
        id: newTicketId,
        department,
        category,
        subject,
        description,
        filedDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
        status: 'PENDING',
        statusLabel: 'Forwarded to Central Grievance Cell',
        slaDaysRemaining: 21,
        assignedOfficer: 'Central Nodal Officer (CPGRAMS Section)',
        attachmentName: attachedFile ? attachedFile.name : undefined,
        updates: [
          {
            date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + ', Just now',
            stage: 'Grievance Registered on National CPGRAMS Portal',
            remarks: 'Automated acknowledgment generated. Officer assignment in progress within 48 hours.',
          }
        ]
      };

      onFileGrievance(newTicket);
      setSubmittedTicket(newTicket);
      setIsSubmitting(false);
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    }, 600);
  };

  const handleResetForm = () => {
    setSubmittedTicket(null);
    setSubject('');
    setDescription('');
    setAttachedFile(null);
  };

  return (
    <section id="grievances-section" className="py-14 bg-[#F8FAFC] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-2 bg-rose-50 border border-rose-200 text-rose-800 px-3.5 py-1.5 rounded-full text-xs font-semibold mb-3">
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <span>CPGRAMS 24x7 National Grievance Redressal</span>
          </div>
          <h2 className="text-3xl font-extrabold text-[#0A1F44] tracking-tight">
            Centralized Public Grievance Portal
          </h2>
          <p className="mt-2 text-base text-slate-600">
            Lodge complaints regarding government public services, scheme benefits, delays, or officer conduct. Enforced with a strict 21-day time-bound SLA.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Grievance Registration Form (7 Cols) */}
          <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-md">
            {submittedTicket ? (
              /* Success Confirmation Banner */
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <div className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                  Grievance Registered Successfully
                </div>
                <h3 className="text-2xl font-extrabold text-[#0A1F44]">
                  Tracking ID: <span className="font-mono text-blue-700">{submittedTicket.id}</span>
                </h3>
                <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                  Your complaint has been formally mapped to the Nodal Grievance Officer at <strong>{submittedTicket.department}</strong>. You will receive real-time SMS updates at {user.phone}.
                </p>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left text-xs max-w-md mx-auto space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Guaranteed SLA:</span>
                    <strong className="text-rose-700">21 Working Days</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Category:</span>
                    <strong className="text-slate-800">{submittedTicket.category}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Subject:</span>
                    <span className="text-slate-800 line-clamp-1">{submittedTicket.subject}</span>
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-center space-x-3">
                  <button
                    onClick={handleResetForm}
                    className="bg-[#0A1F44] hover:bg-blue-900 text-white text-xs sm:text-sm font-semibold px-5 py-2.5 rounded-lg shadow-xs transition-colors"
                  >
                    File Another Grievance
                  </button>
                </div>
              </div>
            ) : (
              /* Complaint Form */
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-lg font-bold text-[#0A1F44]">Lodge a New Grievance</h3>
                  <span className="text-xs text-slate-400">* All fields mandatory</span>
                </div>

                {/* Ministry / Department Dropdown */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Select Ministry / Department *
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-slate-800"
                  >
                    {departmentsList.map((dept, idx) => (
                      <option key={idx} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Category & State/District Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Grievance Category *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                    >
                      <option value="Demographic Update Delay">Demographic / Card Update Delay</option>
                      <option value="Service Application Rejection">Unjustified Application Rejection</option>
                      <option value="DBT Subsidy Not Credited">Direct Benefit (DBT) Not Credited</option>
                      <option value="Staff Misbehavior / Bribery Demand">Public Officer Conduct / Bribery</option>
                      <option value="Portal / Server Technical Error">Technical / System Outage</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      State & District Jurisdiction *
                    </label>
                    <input
                      type="text"
                      value={stateDistrict}
                      onChange={(e) => setStateDistrict(e.target.value)}
                      placeholder="e.g. Maharashtra - Pune"
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                    />
                  </div>
                </div>

                {/* Grievance Subject */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Grievance Subject / Headline *
                  </label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Concise summary of your issue (e.g. Ration entitlement denied at FPS 401)"
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 font-medium"
                  />
                </div>

                {/* Grievance Detailed Description with Word Counter */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                      Detailed Grievance Description *
                    </label>
                    <span className={`text-[11px] font-mono ${description.length > 500 ? 'text-amber-600' : 'text-slate-400'}`}>
                      {description.length} / 1500 chars
                    </span>
                  </div>
                  <textarea
                    rows={4}
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    maxLength={1500}
                    placeholder="Provide specific dates, application reference numbers, office names, and officers involved to expedite redressal..."
                    className="w-full p-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 leading-relaxed"
                  />
                </div>

                {/* File Attachment Upload */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Upload Supporting Proof / Receipt (Optional, up to 10MB)
                  </label>
                  <div className="border border-slate-300 rounded-xl p-3 bg-slate-50 flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-xs text-slate-600">
                      <Upload className="w-4 h-4 text-slate-400" />
                      <span>{attachedFile ? attachedFile.name : 'Attach Application PDF / Image'}</span>
                    </div>
                    <input
                      type="file"
                      accept=".pdf,.png,.jpg,.jpeg"
                      onChange={(e) => {
                        if (e.target.files?.[0]) setAttachedFile(e.target.files[0]);
                      }}
                      className="text-xs text-slate-500"
                    />
                  </div>
                </div>

                {/* Reassurance Note & Submit */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="text-[11px] text-slate-500 flex items-center space-x-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Protected under Whistleblower & Citizen Charter Act</span>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-[#0A1F44] hover:bg-blue-900 active:scale-95 text-white font-bold text-sm px-6 py-3 rounded-lg shadow-sm transition-all flex items-center justify-center space-x-2"
                  >
                    {isSubmitting ? (
                      <span>Registering on CPGRAMS...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-amber-400" />
                        <span>Submit Official Grievance</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: Existing Grievances & Resolution SLA Indicators (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Resolution SLA Information Box */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <div className="flex items-center space-x-3 pb-3 border-b border-slate-100">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#0A1F44] text-sm">Mandatory Redressal Timelines</h4>
                  <p className="text-[11px] text-slate-500">Government of India Citizen Charter</p>
                </div>
              </div>

              <div className="mt-4 space-y-2.5 text-xs text-slate-600">
                <div className="flex justify-between p-2 rounded-lg bg-slate-50">
                  <span className="font-medium">Initial Acknowledgment</span>
                  <strong className="text-slate-800">Within 48 Hours</strong>
                </div>
                <div className="flex justify-between p-2 rounded-lg bg-slate-50">
                  <span className="font-medium">Direct Transfer / Pension Delays</span>
                  <strong className="text-slate-800">Within 15 Days</strong>
                </div>
                <div className="flex justify-between p-2 rounded-lg bg-slate-50">
                  <span className="font-medium">General Public Service Grievance</span>
                  <strong className="text-slate-800">Max 21 Days (SLA)</strong>
                </div>
              </div>
            </div>

            {/* Active Grievances Tracker */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <h4 className="font-bold text-[#0A1F44] text-sm mb-3">Your Tracked Grievances ({grievances.length})</h4>
              
              <div className="space-y-3">
                {grievances.map((g) => (
                  <div key={g.id} className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold text-rose-800 bg-rose-50 px-2 py-0.5 rounded">
                        {g.id}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">Filed: {g.filedDate}</span>
                    </div>
                    <div className="font-bold text-slate-800 mt-1 line-clamp-1">{g.subject}</div>
                    <div className="text-slate-500 text-[11px] mt-0.5 line-clamp-1">{g.department}</div>
                    
                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                      <span className="font-bold text-amber-700">{g.statusLabel}</span>
                      <span className="text-slate-400">SLA: {g.slaDaysRemaining}d remaining</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
