import React, { useState } from 'react';
import {
  UserProfile,
  TrackedApplication,
  VaultDocument,
  PaymentRecord,
  GrievanceTicket,
  NotificationItem,
  LanguageCode,
  ServiceItem,
} from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  downloadApplicationReceipt,
  downloadPaymentReceipt,
} from '../../utils/receiptGenerator';
import {
  User,
  Search,
  FolderLock,
  CreditCard,
  AlertCircle,
  FileCheck,
  CheckCircle2,
  Clock,
  Download,
  Upload,
  Plus,
  ArrowRight,
  Shield,
  Eye,
  Trash2,
  Bell,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Printer,
  Sparkles,
  QrCode,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CitizenDashboardProps {
  currentLanguage: LanguageCode;
  user: UserProfile;
  applications: TrackedApplication[];
  vaultDocs: VaultDocument[];
  payments: PaymentRecord[];
  grievances: GrievanceTicket[];
  notifications: NotificationItem[];
  initialSubTab?: 'overview' | 'track' | 'vault' | 'payments' | 'grievances';
  onTrackNewId: (id: string) => void;
  onApplyServiceClick: (serviceId?: string) => void;
  onFileGrievanceClick: () => void;
  onUploadVaultDoc: (doc: Omit<VaultDocument, 'id'>) => void;
  onDeleteVaultDoc: (docId: string) => void;
}

export const CitizenDashboard: React.FC<CitizenDashboardProps> = ({
  currentLanguage,
  user,
  applications,
  vaultDocs,
  payments,
  grievances,
  notifications,
  initialSubTab = 'overview',
  onTrackNewId,
  onApplyServiceClick,
  onFileGrievanceClick,
  onUploadVaultDoc,
  onDeleteVaultDoc,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'overview' | 'track' | 'vault' | 'payments' | 'grievances'
  >(initialSubTab);

  // Search in Track Application
  const [trackSearchId, setTrackSearchId] = useState('');
  const [selectedAppId, setSelectedAppId] = useState<string>(
    applications[0]?.id || ''
  );

  // Document Vault Upload Modal State
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocType, setNewDocType] = useState('Identity & Address Proof');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newDocIssuer, setNewDocIssuer] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Document Preview Modal State
  const [previewDoc, setPreviewDoc] = useState<VaultDocument | null>(null);

  // Receipt Preview Modal State
  const [previewReceipt, setPreviewReceipt] = useState<PaymentRecord | null>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Selected Application for detailed view
  const currentApp =
    applications.find((a) => a.id.toLowerCase() === selectedAppId.toLowerCase()) ||
    applications.find((a) => a.id.toLowerCase() === trackSearchId.trim().toLowerCase()) ||
    applications[0];

  const handleSearchTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackSearchId.trim()) {
      const match = applications.find(
        (a) => a.id.toLowerCase() === trackSearchId.trim().toLowerCase()
      );
      if (match) {
        setSelectedAppId(match.id);
      } else {
        onTrackNewId(trackSearchId.trim());
      }
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim()) return;

    onUploadVaultDoc({
      title: newDocTitle,
      docType: newDocType,
      docNumber: newDocNumber || `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
      issuer: newDocIssuer || 'Government of NCT Delhi / E-District',
      issueDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      verified: true,
      fileSize: selectedFile ? `${(selectedFile.size / 1024).toFixed(0)} KB` : '450 KB',
      iconType: 'FileText'
    });

    confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
    setIsUploadModalOpen(false);
    setNewDocTitle('');
    setNewDocNumber('');
    setNewDocIssuer('');
    setSelectedFile(null);
  };

  const getStatusColorBadge = (status: string) => {
    switch (status) {
      case 'approved':
      case 'completed':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'under_review':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'rejected':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'submitted':
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div className="bg-[#F8FAFC] min-h-[800px] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Citizen Header Banner */}
        <div className="bg-[#0A1F44] text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800 mb-8 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 font-extrabold text-2xl flex items-center justify-center border-2 border-white/20 shadow-md">
                {user.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                    {user.name}
                  </h1>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>DigiLocker Linked</span>
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-slate-300 mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span>Aadhaar: <strong className="text-white">{user.aadhaarMasked}</strong></span>
                  <span>•</span>
                  <span>PAN: <strong className="text-white">{user.panMasked}</strong></span>
                  <span>•</span>
                  <span>Phone: <strong className="text-white">{user.phone}</strong></span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3 self-stretch md:self-auto">
              <button
                onClick={() => onApplyServiceClick()}
                className="flex-1 md:flex-none bg-[#1D5FE0] hover:bg-blue-600 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-lg shadow-sm transition-colors flex items-center justify-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>New Application</span>
              </button>
              <button
                onClick={onFileGrievanceClick}
                className="flex-1 md:flex-none bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg border border-white/20 transition-colors flex items-center justify-center space-x-1.5"
              >
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <span>File Grievance</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Navigation Tabs Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200/90 p-1.5 mb-8 flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveSubTab('overview')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'overview'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Overview</span>
          </button>

          <button
            onClick={() => setActiveSubTab('track')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 relative ${
              activeSubTab === 'track'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Track Application ({applications.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('vault')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'vault'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FolderLock className="w-4 h-4" />
            <span>Document Vault ({vaultDocs.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('payments')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'payments'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Payment History</span>
          </button>

          <button
            onClick={() => setActiveSubTab('grievances')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'grievances'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <AlertCircle className="w-4 h-4 text-rose-500" />
            <span>Grievances ({grievances.length})</span>
          </button>
        </div>

        {/* ========================================================================= */}
        {/* SUB-TAB 1: OVERVIEW */}
        {/* ========================================================================= */}
        {activeSubTab === 'overview' && (
          <div className="space-y-8">
            {/* Quick Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">Active Applications</div>
                  <div className="text-2xl font-extrabold text-[#0A1F44] mt-1">{applications.length} In Progress</div>
                  <button onClick={() => setActiveSubTab('track')} className="text-xs font-semibold text-blue-700 hover:underline mt-2 inline-block">
                    View Tracking Timeline →
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <FileCheck className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">DigiLocker Vault</div>
                  <div className="text-2xl font-extrabold text-emerald-700 mt-1">{vaultDocs.length} Verified Docs</div>
                  <button onClick={() => setActiveSubTab('vault')} className="text-xs font-semibold text-emerald-700 hover:underline mt-2 inline-block">
                    Manage Documents →
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Shield className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">CPGRAMS Grievances</div>
                  <div className="text-2xl font-extrabold text-[#0A1F44] mt-1">{grievances.length} Registered</div>
                  <button onClick={() => setActiveSubTab('grievances')} className="text-xs font-semibold text-rose-700 hover:underline mt-2 inline-block">
                    Check SLA Status →
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">Total Fees Paid</div>
                  <div className="text-2xl font-extrabold text-indigo-700 mt-1">₹{payments.reduce((acc, p) => acc + p.amount, 0)}</div>
                  <button onClick={() => setActiveSubTab('payments')} className="text-xs font-semibold text-indigo-700 hover:underline mt-2 inline-block">
                    Download Receipts →
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
                  <CreditCard className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* Active Applications Snippet & Notifications */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Active Applications Snippet (7 Cols) */}
              <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
                  <div>
                    <h2 className="text-lg font-bold text-[#0A1F44]">Recent Applications</h2>
                    <p className="text-xs text-slate-500">Live progress of your submitted citizen requests</p>
                  </div>
                  <button
                    onClick={() => setActiveSubTab('track')}
                    className="text-xs font-bold text-blue-700 hover:underline"
                  >
                    View All Details
                  </button>
                </div>

                <div className="space-y-4">
                  {applications.slice(0, 3).map((app) => (
                    <div
                      key={app.id}
                      onClick={() => {
                        setSelectedAppId(app.id);
                        setActiveSubTab('track');
                      }}
                      className="p-4 rounded-xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-xs font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded">
                            {app.id}
                          </span>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${getStatusColorBadge(app.status)}`}>
                            {app.statusLabel}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-800 text-sm mt-1.5">{app.serviceTitle}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{app.department}</p>
                      </div>

                      <div className="text-right sm:border-l sm:border-slate-100 sm:pl-4">
                        <div className="text-[11px] text-slate-400">Target Date</div>
                        <div className="text-xs font-bold text-slate-700">{app.estimatedCompletionDate}</div>
                        <span className="text-xs font-semibold text-blue-700 flex items-center sm:justify-end mt-1">
                          Track <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Notifications & Quick Vault Access (5 Cols) */}
              <div className="lg:col-span-5 space-y-6">
                {/* Official Notifications */}
                <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                    <h2 className="text-base font-bold text-[#0A1F44] flex items-center space-x-2">
                      <Bell className="w-4 h-4 text-amber-500" />
                      <span>Govt Service Alerts</span>
                    </h2>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold">
                      {notifications.length} Unread
                    </span>
                  </div>

                  <div className="space-y-3">
                    {notifications.map((n) => (
                      <div key={n.id} className="p-3 rounded-lg bg-slate-50 border border-slate-200/70 text-xs">
                        <div className="flex items-center justify-between font-bold text-slate-800">
                          <span>{n.title}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{n.timestamp}</span>
                        </div>
                        <p className="text-slate-600 mt-1 leading-relaxed">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Verified DigiLocker Cards */}
                <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                    <h2 className="text-base font-bold text-[#0A1F44] flex items-center space-x-2">
                      <Shield className="w-4 h-4 text-emerald-600" />
                      <span>Verified Certificates</span>
                    </h2>
                    <button onClick={() => setActiveSubTab('vault')} className="text-xs font-semibold text-emerald-700 hover:underline">
                      View All ({vaultDocs.length})
                    </button>
                  </div>

                  <div className="space-y-2">
                    {vaultDocs.slice(0, 3).map((doc) => (
                      <div key={doc.id} className="flex items-center justify-between p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-xs">
                        <div className="flex items-center space-x-2.5">
                          <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-800 line-clamp-1">{doc.title}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{doc.docNumber}</div>
                          </div>
                        </div>
                        <button
                          onClick={() => setPreviewDoc(doc)}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                          title="Preview Document"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 2: TRACK APPLICATION */}
        {/* ========================================================================= */}
        {activeSubTab === 'track' && (
          <div className="space-y-8">
            {/* Search Any Application Bar */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <h2 className="text-lg font-bold text-[#0A1F44] mb-2">Track Application by Reference ID</h2>
              <p className="text-xs text-slate-500 mb-4">
                Enter your 16-digit Application ID (e.g., <code className="text-blue-700 font-bold">APP-2026-88219</code>) or select from your active submissions below.
              </p>

              <form onSubmit={handleSearchTrackSubmit} className="flex gap-2 max-w-xl">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={trackSearchId}
                    onChange={(e) => setTrackSearchId(e.target.value)}
                    placeholder="Enter Application ID..."
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-[#0A1F44] hover:bg-blue-900 text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-lg transition-colors"
                >
                  Track Now
                </button>
              </form>

              {/* Quick Select Buttons */}
              <div className="flex items-center gap-2 flex-wrap mt-4 pt-3 border-t border-slate-100">
                <span className="text-xs text-slate-400 font-medium">Your Active Submissions:</span>
                {applications.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => {
                      setSelectedAppId(app.id);
                      setTrackSearchId(app.id);
                    }}
                    className={`px-3 py-1 rounded-md text-xs font-mono font-bold transition-all border ${
                      selectedAppId === app.id
                        ? 'bg-blue-700 text-white border-blue-700 shadow-2xs'
                        : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    {app.id} ({app.serviceTitle.split(' ')[0]})
                  </button>
                ))}
              </div>
            </div>

            {/* Detailed Tracking Card for Current Selected Application */}
            {currentApp && (
              <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-md">
                {/* Header Summary */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-6 border-b border-slate-200 gap-4">
                  <div>
                    <div className="flex items-center space-x-3">
                      <span className="font-mono text-sm font-bold bg-blue-100 text-blue-900 px-2.5 py-1 rounded-md">
                        {currentApp.id}
                      </span>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full border ${getStatusColorBadge(currentApp.status)}`}>
                        {currentApp.statusLabel}
                      </span>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-[#0A1F44] mt-2">
                      {currentApp.serviceTitle}
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-500 font-medium mt-0.5">
                      {currentApp.department}
                    </p>
                  </div>

                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => {
                        window.print();
                      }}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3.5 py-2 rounded-lg border border-slate-300 flex items-center space-x-1.5 transition-colors"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print Slip</span>
                    </button>
                    <button
                      onClick={() => {
                        confetti({ particleCount: 50 });
                        downloadApplicationReceipt(currentApp, user);
                      }}
                      className="bg-[#1D5FE0] hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center space-x-1.5 transition-colors shadow-xs"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Receipt (PDF)</span>
                    </button>
                  </div>
                </div>

                {/* Key Application Meta Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400 block">Applicant Name</span>
                    <strong className="text-slate-800 text-sm">{currentApp.applicantName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Submission Date</span>
                    <strong className="text-slate-800 text-sm">{currentApp.submissionDate}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Estimated Delivery</span>
                    <strong className="text-slate-800 text-sm">{currentApp.estimatedCompletionDate}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Receipt / Fee</span>
                    <strong className="text-emerald-700 text-sm">₹{currentApp.feesPaid} ({currentApp.receiptNumber})</strong>
                  </div>
                </div>

                {/* Officer Remarks Banner */}
                {currentApp.officerRemarks && (
                  <div className="my-6 p-4 rounded-xl bg-blue-50/80 border border-blue-200 text-xs text-blue-900 flex items-start space-x-3">
                    <CheckCircle2 className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                    <div>
                      <strong className="font-bold">Official Scrutiny Remarks: </strong>
                      <span>{currentApp.officerRemarks}</span>
                    </div>
                  </div>
                )}

                {/* Step-by-Step Verified Status Timeline */}
                <div className="pt-2">
                  <h4 className="text-sm font-bold text-[#0A1F44] uppercase tracking-wider mb-6">
                    Stage-by-Stage Processing Timeline
                  </h4>

                  <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {currentApp.timeline.map((step, idx) => (
                      <div key={idx} className="relative group">
                        {/* Timeline Circle */}
                        <div
                          className={`absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full flex items-center justify-center border-2 ${
                            step.completed
                              ? 'bg-emerald-500 border-emerald-500 text-white'
                              : step.current
                              ? 'bg-amber-400 border-amber-500 text-slate-950 animate-pulse'
                              : 'bg-white border-slate-300 text-slate-400'
                          }`}
                        >
                          {step.completed ? (
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          ) : step.current ? (
                            <Clock className="w-3.5 h-3.5" />
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-slate-300" />
                          )}
                        </div>

                        {/* Step Details */}
                        <div>
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                            <h5 className={`text-sm font-bold ${step.completed || step.current ? 'text-slate-900' : 'text-slate-500'}`}>
                              {step.title}
                            </h5>
                            {step.date && (
                              <span className="text-[11px] text-slate-400 font-medium">
                                {step.date}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 mt-1 leading-relaxed max-w-2xl">
                            {step.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 3: DOCUMENT VAULT (DIGILOCKER) */}
        {/* ========================================================================= */}
        {activeSubTab === 'vault' && (
          <div className="space-y-8">
            {/* Vault Action Header */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2 text-xs font-bold text-emerald-700 uppercase">
                  <Shield className="w-4 h-4" />
                  <span>DigiLocker Ecosystem • Rule 9A IT Rules 2016</span>
                </div>
                <h2 className="text-xl font-bold text-[#0A1F44] mt-1">Verified Citizen Document Vault</h2>
                <p className="text-xs text-slate-500">
                  Legally valid digital certificates recognized on par with physical originals across all public authorities.
                </p>
              </div>

              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-lg flex items-center justify-center space-x-2 shadow-xs transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>Upload / Link Document</span>
              </button>
            </div>

            {/* Document Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vaultDocs.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white rounded-2xl p-6 border border-slate-200/90 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Top: Icon & Verification Stamp */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center">
                        <FileText className="w-6 h-6" />
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>Verified Digital Copy</span>
                      </span>
                    </div>

                    {/* Title & Document Number */}
                    <h4 className="font-bold text-base text-[#0A1F44] line-clamp-1">{doc.title}</h4>
                    <p className="text-xs text-slate-400 mt-0.5 font-medium">{doc.docType}</p>

                    <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Doc No:</span>
                        <span className="font-mono font-bold text-slate-700">{doc.docNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Issuer:</span>
                        <span className="font-medium text-slate-700 text-right line-clamp-1 max-w-[160px]">{doc.issuer}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Issued On:</span>
                        <span className="font-medium text-slate-700">{doc.issueDate}</span>
                      </div>
                      {doc.expiryDate && (
                        <div className="flex justify-between">
                          <span className="text-slate-400">Valid Till:</span>
                          <span className="font-bold text-blue-700">{doc.expiryDate}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Document Actions */}
                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => setPreviewDoc(doc)}
                      className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center space-x-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Verified Copy</span>
                    </button>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          confetti({ particleCount: 40 });
                          alert(`Downloading authenticated digital copy of ${doc.title}`);
                        }}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                        title="Download PDF"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteVaultDoc(doc.id)}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Remove Document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 4: PAYMENTS */}
        {/* ========================================================================= */}
        {activeSubTab === 'payments' && (
          <div className="space-y-8">
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
                <div>
                  <h2 className="text-xl font-bold text-[#0A1F44]">Bharat BillPay & Treasury Receipts</h2>
                  <p className="text-xs text-slate-500">Official government transaction records with GST invoices</p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Total Processed</span>
                  <div className="text-2xl font-extrabold text-[#0A1F44]">
                    ₹{payments.reduce((acc, p) => acc + p.amount, 0).toLocaleString('en-IN')}
                  </div>
                </div>
              </div>

              {/* Transactions Table */}
              <div className="overflow-x-auto mt-6">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase text-[11px] font-bold">
                      <th className="pb-3 font-semibold">Transaction ID</th>
                      <th className="pb-3 font-semibold">Service Description</th>
                      <th className="pb-3 font-semibold">Date & Time</th>
                      <th className="pb-3 font-semibold">Mode</th>
                      <th className="pb-3 font-semibold">Amount</th>
                      <th className="pb-3 font-semibold">Status</th>
                      <th className="pb-3 font-semibold text-right">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {payments.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-4 font-mono font-bold text-blue-700">{p.transactionId}</td>
                        <td className="py-4 font-medium text-slate-800">{p.serviceName}</td>
                        <td className="py-4 text-slate-500 text-xs">{p.date}</td>
                        <td className="py-4 text-slate-600 text-xs">{p.paymentMode}</td>
                        <td className="py-4 font-extrabold text-slate-900">₹{p.amount}</td>
                        <td className="py-4">
                          <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded">
                            {p.status}
                          </span>
                        </td>
                        <td className="py-4 text-right">
                          <button
                            onClick={() => setPreviewReceipt(p)}
                            className="inline-flex items-center space-x-1 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-200 transition-colors"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Slip</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 5: GRIEVANCES */}
        {/* ========================================================================= */}
        {activeSubTab === 'grievances' && (
          <div className="space-y-8">
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-[#0A1F44]">CPGRAMS Grievances Track</h2>
                <p className="text-xs text-slate-500">Live SLA resolution countdown & Action Taken Reports (ATR)</p>
              </div>
              <button
                onClick={onFileGrievanceClick}
                className="bg-rose-700 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-lg flex items-center justify-center space-x-2 transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Lodge New Grievance</span>
              </button>
            </div>

            <div className="space-y-6">
              {grievances.map((g) => (
                <div key={g.id} className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-xs font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded">
                          {g.id}
                        </span>
                        <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded">
                          {g.statusLabel}
                        </span>
                      </div>
                      <h4 className="text-base font-bold text-slate-800 mt-2">{g.subject}</h4>
                      <p className="text-xs text-slate-500 mt-0.5 font-medium">{g.department}</p>
                    </div>

                    <div className="text-left sm:text-right">
                      <span className="text-xs text-slate-400">Guaranteed SLA</span>
                      <div className="text-sm font-extrabold text-rose-700">
                        {g.slaDaysRemaining > 0 ? `${g.slaDaysRemaining} Days Remaining` : 'Resolved within SLA'}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
                    "{g.description}"
                  </p>

                  {/* Resolution Stages */}
                  <div className="pt-2">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                      Action Taken Updates
                    </div>
                    <div className="space-y-3">
                      {g.updates.map((u, idx) => (
                        <div key={idx} className="flex items-start space-x-3 text-xs">
                          <div className="w-2 h-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                          <div>
                            <div className="font-bold text-slate-800">{u.stage}</div>
                            <div className="text-slate-500">{u.remarks}</div>
                            <div className="text-[10px] text-slate-400 mt-0.5">{u.date}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* MODAL: UPLOAD NEW DOCUMENT */}
      {/* ========================================================================= */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-lg font-bold text-[#0A1F44] mb-1">Add Document to DigiLocker Vault</h3>
            <p className="text-xs text-slate-500 mb-4">
              Upload your PDF/image to link it securely to your Aadhaar-verified citizen vault.
            </p>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="e.g. Caste Certificate, Degree Marksheet"
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
                <select
                  value={newDocType}
                  onChange={(e) => setNewDocType(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Identity & Address Proof">Identity & Address Proof</option>
                  <option value="Educational Qualification">Educational Qualification</option>
                  <option value="Income & Asset Proof">Income & Asset Proof</option>
                  <option value="Property & Land Record">Property & Land Record</option>
                  <option value="Healthcare Certificate">Healthcare Certificate</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Certificate / Document Number</label>
                <input
                  type="text"
                  value={newDocNumber}
                  onChange={(e) => setNewDocNumber(e.target.value)}
                  placeholder="e.g. DL-04-2022-00918"
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Issuing Authority</label>
                <input
                  type="text"
                  value={newDocIssuer}
                  onChange={(e) => setNewDocIssuer(e.target.value)}
                  placeholder="e.g. State Revenue Department / CBSE"
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* File Attachment Drop Area */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Upload File (PDF / PNG / JPG)</label>
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:bg-slate-50 cursor-pointer">
                  <Upload className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                  <p className="text-xs text-slate-600">Drag and drop file here, or click to browse</p>
                  <input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg"
                    onChange={(e) => {
                      if (e.target.files?.[0]) setSelectedFile(e.target.files[0]);
                    }}
                    className="mt-2 text-xs text-slate-500"
                  />
                  {selectedFile && (
                    <div className="mt-2 text-xs font-bold text-emerald-700">
                      ✓ Selected: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(0)} KB)
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg shadow-xs"
                >
                  Save to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DOCUMENT PREVIEW */}
      {/* ========================================================================= */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  DIGILOCKER VERIFIED
                </span>
                <h3 className="text-lg font-bold text-[#0A1F44] mt-1">{previewDoc.title}</h3>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            {/* Document Digital Replica Frame */}
            <div className="my-6 p-6 rounded-xl bg-slate-50 border-2 border-slate-200 text-center relative overflow-hidden">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto mb-3">
                <QrCode className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-slate-800 text-base">{previewDoc.title}</h4>
              <p className="font-mono text-sm font-bold text-blue-800 mt-1">{previewDoc.docNumber}</p>
              <p className="text-xs text-slate-500 mt-2">Issued by {previewDoc.issuer}</p>
              <div className="mt-4 inline-flex items-center space-x-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>2048-bit Cryptographically E-Signed & Valid</span>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  confetti({ particleCount: 50 });
                  const pseudoDocApp: TrackedApplication = {
                    id: previewDoc.docNumber,
                    serviceId: 'digilocker-doc',
                    serviceTitle: previewDoc.title,
                    department: previewDoc.issuer,
                    applicantName: user.name,
                    aadhaarNumber: user.aadhaarMasked,
                    submissionDate: previewDoc.issueDate,
                    estimatedCompletionDate: 'Active & Cryptographically Verified',
                    status: 'completed',
                    statusLabel: 'DigiLocker Authentic Certificate',
                    currentStage: 'Issued by ' + previewDoc.issuer,
                    feesPaid: 0,
                    receiptNumber: 'DIGILOCKER-' + previewDoc.id,
                    timeline: [],
                  };
                  downloadApplicationReceipt(pseudoDocApp, user);
                  setPreviewDoc(null);
                }}
                className="px-4 py-2 text-xs font-bold bg-blue-700 hover:bg-blue-800 text-white rounded-lg flex items-center space-x-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Download Authenticated PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: RECEIPT SLIP PREVIEW */}
      {/* ========================================================================= */}
      {previewReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div className="text-center pb-4 border-b border-slate-200">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                Government of India • Treasury Receipt
              </div>
              <h3 className="text-xl font-extrabold text-[#0A1F44] mt-1">Bharat BillPay Receipt</h3>
              <p className="text-xs font-mono text-blue-700 mt-0.5">{previewReceipt.transactionId}</p>
            </div>

            <div className="my-6 space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Service:</span>
                <strong className="text-slate-800">{previewReceipt.serviceName}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Applicant:</span>
                <strong className="text-slate-800">{user.name}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Date & Time:</span>
                <span className="text-slate-800">{previewReceipt.date}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Payment Gateway:</span>
                <span className="text-slate-800">{previewReceipt.paymentMode}</span>
              </div>
              <div className="flex justify-between py-2 text-sm font-extrabold text-slate-900 border-t-2 border-slate-800">
                <span>Total Amount Paid:</span>
                <span>₹{previewReceipt.amount}.00</span>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setPreviewReceipt(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  confetti({ particleCount: 40 });
                  downloadPaymentReceipt(previewReceipt, user);
                  setPreviewReceipt(null);
                }}
                className="px-4 py-2 text-xs font-bold bg-[#0A1F44] hover:bg-blue-950 text-white rounded-lg flex items-center space-x-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Download Tax Invoice</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
