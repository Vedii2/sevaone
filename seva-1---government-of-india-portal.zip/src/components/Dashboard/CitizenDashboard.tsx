import React, { useState } from 'react';
import {
  UserProfile,
  TrackedApplication,
  VaultDocument,
  PaymentRecord,
  GrievanceTicket,
  NotificationItem,
  LanguageCode,
  ServiceItem,
} from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  downloadApplicationReceipt,
  downloadPaymentReceipt,
} from '../../utils/receiptGenerator';
import {
  User,
  Search,
  FolderLock,
  CreditCard,
  AlertCircle,
  FileCheck,
  CheckCircle2,
  Clock,
  Download,
  Upload,
  Plus,
  ArrowRight,
  Shield,
  Eye,
  Trash2,
  Bell,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Printer,
  Sparkles,
  QrCode,
  FileText,
  Edit3,
  MapPin,
  Calendar,
  Phone,
  Mail,
  ShieldCheck,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CitizenDashboardProps {
  currentLanguage: LanguageCode;
  user: UserProfile;
  applications: TrackedApplication[];
  vaultDocs: VaultDocument[];
  payments: PaymentRecord[];
  grievances: GrievanceTicket[];
  notifications: NotificationItem[];
  initialSubTab?: 'overview' | 'vault' | 'payments' | 'profile';
  onNavigateToTrack: () => void;
  onApplyServiceClick: (serviceId?: string) => void;
  onFileGrievanceClick: () => void;
  onUploadVaultDoc: (doc: Omit<VaultDocument, 'id'>) => void;
  onDeleteVaultDoc: (docId: string) => void;
  onUpdateUser?: (updatedUser: UserProfile) => void;
  onCheckSchemesClick?: () => void;
}

export const CitizenDashboard: React.FC<CitizenDashboardProps> = ({
  currentLanguage,
  user,
  applications,
  vaultDocs,
  payments,
  grievances,
  notifications,
  initialSubTab = 'overview',
  onNavigateToTrack,
  onApplyServiceClick,
  onFileGrievanceClick,
  onUploadVaultDoc,
  onDeleteVaultDoc,
  onUpdateUser,
  onCheckSchemesClick,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'vault' | 'payments' | 'profile'>(initialSubTab);

  // Document Vault Upload Modal State
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocType, setNewDocType] = useState('Identity & Address Proof');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newDocIssuer, setNewDocIssuer] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Document Preview Modal State
  const [previewDoc, setPreviewDoc] = useState<VaultDocument | null>(null);

  // Receipt Preview Modal State
  const [previewReceipt, setPreviewReceipt] = useState<PaymentRecord | null>(null);

  // Edit Profile Modal State
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editPhone, setEditPhone] = useState(user.phone);
  const [editEmail, setEditEmail] = useState(user.email);
  const [editDob, setEditDob] = useState(user.dob || '1998-08-14');
  const [editGender, setEditGender] = useState(user.gender || 'Female');
  const [editAddress, setEditAddress] = useState(user.address);
  const [editCity, setEditCity] = useState(user.city);
  const [editDistrict, setEditDistrict] = useState(user.district || 'Mumbai Suburban');
  const [editState, setEditState] = useState(user.state);
  const [editPincode, setEditPincode] = useState(user.pincode);

  React.useEffect(() => {
    setEditName(user.name);
    setEditPhone(user.phone);
    setEditEmail(user.email);
    setEditDob(user.dob || '1998-08-14');
    setEditGender(user.gender || 'Female');
    setEditAddress(user.address);
    setEditCity(user.city);
    setEditDistrict(user.district || '');
    setEditState(user.state);
    setEditPincode(user.pincode);
  }, [user]);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim()) return;

    onUploadVaultDoc({
      title: newDocTitle,
      docType: newDocType,
      docNumber: newDocNumber || `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
      issuer: newDocIssuer || 'Government of NCT Delhi / E-District',
      issueDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      verified: true,
      fileSize: selectedFile ? `${(selectedFile.size / 1024).toFixed(0)} KB` : '450 KB',
      iconType: 'FileText'
    });

    confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
    setIsUploadModalOpen(false);
    setNewDocTitle('');
    setNewDocNumber('');
    setNewDocIssuer('');
    setSelectedFile(null);
  };

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;

    const updated: UserProfile = {
      ...user,
      name: editName.trim(),
      phone: editPhone.trim(),
      email: editEmail.trim(),
      dob: editDob,
      gender: editGender,
      address: editAddress.trim(),
      city: editCity.trim(),
      district: editDistrict.trim(),
      state: editState,
      pincode: editPincode.trim(),
    };

    if (onUpdateUser) {
      onUpdateUser(updated);
    }
    try {
      localStorage.setItem('SEVA1_ACTIVE_USER', JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }

    confetti({ particleCount: 50 });
    setIsEditProfileOpen(false);
  };

  const getStatusColorBadge = (status: string) => {
    switch (status) {
      case 'approved':
      case 'completed':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'under_review':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'rejected':
        return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'submitted':
      default:
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div className="bg-[#F8FAFC] min-h-[850px] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Citizen Header Banner */}
        <div className="bg-[#0A1F44] text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800 mb-8 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
          
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 font-extrabold text-2xl flex items-center justify-center border-2 border-white/20 shadow-md">
                {user.name ? user.name.charAt(0) : 'C'}
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                    {user.name}
                  </h1>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>DigiLocker & Aadhaar Linked</span>
                  </span>
                </div>
                <div className="text-xs sm:text-sm text-slate-300 mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span>Aadhaar: <strong className="text-white">{user.aadhaarMasked}</strong></span>
                  <span>•</span>
                  <span>Phone: <strong className="text-white">{user.phone}</strong></span>
                  <span>•</span>
                  <span>State: <strong className="text-white">{user.state}</strong></span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 self-stretch md:self-auto">
              <button
                onClick={() => setIsEditProfileOpen(true)}
                className="bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white font-semibold text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-white/20 transition-colors flex items-center justify-center space-x-1.5"
              >
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>Edit Profile</span>
              </button>
              <button
                onClick={() => onApplyServiceClick()}
                className="bg-[#1D5FE0] hover:bg-blue-600 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-lg shadow-sm transition-colors flex items-center justify-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>New Application</span>
              </button>
              <button
                onClick={onFileGrievanceClick}
                className="bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white font-medium text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-white/20 transition-colors flex items-center justify-center space-x-1.5"
              >
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <span>File Grievance</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Sub-Tabs Navigation Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200/90 p-1.5 mb-8 flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveSubTab('overview')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'overview'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={onNavigateToTrack}
            className="flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          >
            <Search className="w-4 h-4 text-blue-600" />
            <span>Track Application Hub ({applications.length}) →</span>
          </button>

          <button
            onClick={() => setActiveSubTab('vault')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'vault'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FolderLock className="w-4 h-4" />
            <span>DigiLocker Vault ({vaultDocs.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('payments')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'payments'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Payment History</span>
          </button>

          <button
            onClick={() => setActiveSubTab('profile')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center space-x-2 ${
              activeSubTab === 'profile'
                ? 'bg-[#0A1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Citizen Profile & KYC</span>
          </button>
        </div>

        {/* ========================================================================= */}
        {/* SUB-TAB 1: OVERVIEW (HOME BASE) */}
        {/* ========================================================================= */}
        {activeSubTab === 'overview' && (
          <div className="space-y-8">
            
            {/* Quick Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              
              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">Active Applications</div>
                  <div className="text-2xl font-extrabold text-[#0A1F44] mt-1">{applications.length} In Progress</div>
                  <button
                    onClick={onNavigateToTrack}
                    className="text-xs font-bold text-blue-700 hover:underline mt-2 inline-flex items-center space-x-1"
                  >
                    <span>View Tracking Hub</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <FileCheck className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">DigiLocker Vault</div>
                  <div className="text-2xl font-extrabold text-emerald-700 mt-1">{vaultDocs.length} Verified Docs</div>
                  <button
                    onClick={() => setActiveSubTab('vault')}
                    className="text-xs font-bold text-emerald-700 hover:underline mt-2 inline-flex items-center space-x-1"
                  >
                    <span>Manage Vault</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Shield className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">CPGRAMS Grievances</div>
                  <div className="text-2xl font-extrabold text-[#0A1F44] mt-1">{grievances.length} Registered</div>
                  <button
                    onClick={onFileGrievanceClick}
                    className="text-xs font-bold text-rose-700 hover:underline mt-2 inline-flex items-center space-x-1"
                  >
                    <span>Check SLA Status</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-500 uppercase">Total Fees Paid</div>
                  <div className="text-2xl font-extrabold text-indigo-700 mt-1">₹{payments.reduce((acc, p) => acc + p.amount, 0)}</div>
                  <button
                    onClick={() => setActiveSubTab('payments')}
                    className="text-xs font-bold text-indigo-700 hover:underline mt-2 inline-flex items-center space-x-1"
                  >
                    <span>Download Receipts</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
                  <CreditCard className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* Quick Actions Bar */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                Citizen Quick Shortcuts
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs">
                <button
                  onClick={() => onApplyServiceClick()}
                  className="p-3.5 rounded-xl bg-blue-50/80 hover:bg-blue-100/90 border border-blue-200 text-blue-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <Plus className="w-5 h-5 text-blue-600" />
                  <span>Apply Service</span>
                </button>
                <button
                  onClick={onNavigateToTrack}
                  className="p-3.5 rounded-xl bg-indigo-50/80 hover:bg-indigo-100/90 border border-indigo-200 text-indigo-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <Search className="w-5 h-5 text-indigo-600" />
                  <span>Track Status</span>
                </button>
                <button
                  onClick={() => setActiveSubTab('vault')}
                  className="p-3.5 rounded-xl bg-emerald-50/80 hover:bg-emerald-100/90 border border-emerald-200 text-emerald-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <FolderLock className="w-5 h-5 text-emerald-600" />
                  <span>DigiLocker</span>
                </button>
                <button
                  onClick={() => setActiveSubTab('payments')}
                  className="p-3.5 rounded-xl bg-amber-50/80 hover:bg-amber-100/90 border border-amber-200 text-amber-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <CreditCard className="w-5 h-5 text-amber-600" />
                  <span>Payment Slips</span>
                </button>
                <button
                  onClick={onFileGrievanceClick}
                  className="p-3.5 rounded-xl bg-rose-50/80 hover:bg-rose-100/90 border border-rose-200 text-rose-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <AlertCircle className="w-5 h-5 text-rose-600" />
                  <span>CPGRAMS</span>
                </button>
                <button
                  onClick={onCheckSchemesClick || (() => onApplyServiceClick())}
                  className="p-3.5 rounded-xl bg-purple-50/80 hover:bg-purple-100/90 border border-purple-200 text-purple-900 font-bold flex flex-col items-center justify-center text-center space-y-1.5 transition-colors"
                >
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  <span>Check Schemes</span>
                </button>
              </div>
            </div>

            {/* Active Applications Snippet & Notifications */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column: Active Applications Snippet (7 Cols) */}
              <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
                  <div>
                    <h2 className="text-lg font-bold text-[#0A1F44]">Recent Applications</h2>
                    <p className="text-xs text-slate-500">Live progress of your submitted citizen requests</p>
                  </div>
                  <button
                    onClick={onNavigateToTrack}
                    className="text-xs font-bold text-blue-700 hover:underline flex items-center space-x-1"
                  >
                    <span>View All ({applications.length}) in Hub</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-3">
                  {applications.slice(0, 3).map((app) => (
                    <div
                      key={app.id}
                      className="p-4 rounded-xl border border-slate-200/80 hover:border-blue-300 hover:bg-blue-50/30 transition-all text-xs"
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <div>
                          <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">
                            {app.department.split(',')[0]}
                          </span>
                          <h3 className="text-sm font-bold text-[#0A1F44]">
                            {app.serviceTitle}
                          </h3>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold border ${getStatusColorBadge(app.status)}`}>
                          {app.status === 'under_review' ? 'Under Scrutiny' : app.status === 'approved' ? 'Approved' : 'Submitted'}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center justify-between text-slate-500 gap-y-1 mt-2">
                        <span className="font-mono font-bold text-slate-700">{app.id}</span>
                        <span>Stage: <strong className="text-slate-700">{app.currentStage}</strong></span>
                        <span>Est: <strong className="text-blue-900">{app.estimatedCompletionDate}</strong></span>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                        <button
                          onClick={() => downloadApplicationReceipt(app, user)}
                          className="text-blue-700 font-bold hover:underline flex items-center space-x-1"
                        >
                          <Download className="w-3 h-3" />
                          <span>Download PDF Receipt</span>
                        </button>

                        <button
                          onClick={onNavigateToTrack}
                          className="text-slate-600 font-semibold hover:text-blue-700 flex items-center space-x-1"
                        >
                          <span>Full Audit Trail →</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Notifications & Alerts (5 Cols) */}
              <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4 text-blue-600" />
                    <h2 className="text-lg font-bold text-[#0A1F44]">Official Alerts & SMS</h2>
                  </div>
                  <span className="text-xs text-slate-400">Real-time</span>
                </div>

                <div className="space-y-3">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between font-bold text-slate-800">
                        <span>{n.title}</span>
                        <span className="text-[10px] text-slate-400 font-normal">{n.timestamp}</span>
                      </div>
                      <p className="text-slate-600 text-[11px] leading-relaxed">
                        {n.message}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Personalized Recommended Welfare Schemes Banner */}
            <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl p-6 sm:p-7 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div>
                <div className="text-amber-400 text-xs font-bold uppercase tracking-wider mb-1 flex items-center space-x-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Direct Benefit Transfer (DBT) Scheme Finder</span>
                </div>
                <h3 className="text-xl font-extrabold text-white">
                  3 Central Welfare Schemes Match Your Profile ({user.state})
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">
                  Based on your residential state of {user.state} and linked DigiLocker verified documents, you qualify for instant DBT direct transfers.
                </p>
              </div>

              <button
                onClick={onCheckSchemesClick || (() => onApplyServiceClick())}
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm px-5 py-2.5 rounded-lg transition-colors shrink-0 flex items-center space-x-2 shadow-xs"
              >
                <span>Check Welfare Eligibility</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 2: DIGILOCKER DOCUMENT VAULT */}
        {/* ========================================================================= */}
        {activeSubTab === 'vault' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-emerald-700 text-xs font-bold uppercase tracking-wider">
                      National DigiLocker Repository
                    </span>
                    <span>•</span>
                    <span className="text-xs text-slate-500 font-bold">256-Bit Encrypted</span>
                  </div>
                  <h2 className="text-xl font-extrabold text-[#0A1F44] mt-0.5">
                    Verified Digital Certificates & Identity Proofs
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Digitally signed under Section 5 of the Information Technology Act 2000.
                  </p>
                </div>

                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-lg flex items-center space-x-1.5 shadow-xs transition-colors shrink-0"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload & Verify Document</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
                {vaultDocs.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-emerald-300 hover:shadow-xs transition-all space-y-3 text-xs relative"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
                        <FileText className="w-5 h-5" />
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>DigiLocker Verified</span>
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-slate-900 line-clamp-1">{doc.title}</h3>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">ID: {doc.docNumber}</p>
                    </div>

                    <div className="text-[11px] text-slate-500 space-y-0.5 pt-2 border-t border-slate-200/60">
                      <div>Issuer: <strong className="text-slate-700">{doc.issuer}</strong></div>
                      <div>Date: <span className="text-slate-700">{doc.issueDate}</span> • Size: {doc.fileSize}</div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                      <button
                        onClick={() => setPreviewDoc(doc)}
                        className="text-emerald-700 font-bold hover:underline flex items-center space-x-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Preview</span>
                      </button>

                      <button
                        onClick={() => onDeleteVaultDoc(doc.id)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                        title="Remove Document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 3: PAYMENT & TREASURY HISTORY */}
        {/* ========================================================================= */}
        {activeSubTab === 'payments' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
                <div>
                  <div className="flex items-center space-x-2 text-indigo-700 text-xs font-bold uppercase tracking-wider">
                    <span>Bharat BillPay (BBPS) & Treasury Gateway</span>
                  </div>
                  <h2 className="text-xl font-extrabold text-[#0A1F44] mt-0.5">
                    Official Government Payment Receipts
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    All treasury challans, service fees, and e-stamp payments recorded on the National Consolidated Fund.
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto mt-6">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider font-semibold">
                      <th className="pb-3 px-3">Transaction ID</th>
                      <th className="pb-3 px-3">Service Name</th>
                      <th className="pb-3 px-3">Date & Time</th>
                      <th className="pb-3 px-3">Amount</th>
                      <th className="pb-3 px-3">Status</th>
                      <th className="pb-3 px-3 text-right">Receipt Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {payments.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3.5 px-3 font-mono font-bold text-slate-900">{p.transactionId}</td>
                        <td className="py-3.5 px-3 font-semibold text-slate-900">{p.serviceName}</td>
                        <td className="py-3.5 px-3 text-slate-500">{p.date}</td>
                        <td className="py-3.5 px-3 font-extrabold text-[#0A1F44]">₹{p.amount}</td>
                        <td className="py-3.5 px-3">
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                            SUCCESS
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right space-x-2">
                          <button
                            onClick={() => {
                              confetti({ particleCount: 30 });
                              downloadPaymentReceipt(p, user);
                            }}
                            className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold px-2.5 py-1.5 rounded-lg border border-indigo-200 inline-flex items-center space-x-1"
                          >
                            <Download className="w-3 h-3" />
                            <span>PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SUB-TAB 4: CITIZEN PROFILE & KYC DETAILS */}
        {/* ========================================================================= */}
        {activeSubTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
              <div>
                <div className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                  Citizen Identification Record (UIDAI / e-Pramaan)
                </div>
                <h2 className="text-xl font-extrabold text-[#0A1F44] mt-0.5">
                  Verified Identity Profile
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Your registered details are synchronized with National DigiLocker and UIDAI e-KYC.
                </p>
              </div>

              <button
                onClick={() => setIsEditProfileOpen(true)}
                className="bg-[#1D5FE0] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-lg transition-colors flex items-center space-x-1.5 shadow-xs"
              >
                <Edit3 className="w-4 h-4" />
                <span>Edit Profile Information</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">Full Legal Name</span>
                <strong className="text-sm text-slate-900 block">{user.name}</strong>
                <span className="text-[10px] text-emerald-700 font-bold">✓ Matches UIDAI Master Record</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">Date of Birth & Gender</span>
                <strong className="text-sm text-slate-900 block">{user.dob || '14/08/1998'} • {user.gender || 'Female'}</strong>
                <span className="text-[10px] text-emerald-700 font-bold">✓ Age Verified for DBT</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">Aadhaar Number (UIDAI)</span>
                <strong className="text-sm font-mono text-slate-900 block">{user.aadhaarMasked}</strong>
                <span className="text-[10px] text-emerald-700 font-bold">✓ e-KYC OTP Linked</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">Mobile Number</span>
                <strong className="text-sm text-slate-900 block">{user.phone}</strong>
                <span className="text-[10px] text-emerald-700 font-bold">✓ SMS & WhatsApp Alerts Active</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">Email Address</span>
                <strong className="text-sm text-slate-900 block">{user.email}</strong>
                <span className="text-[10px] text-blue-700 font-bold">Primary e-Governance Inbox</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="text-slate-400 font-semibold block">PAN Number</span>
                <strong className="text-sm font-mono text-slate-900 block">{user.panMasked}</strong>
                <span className="text-[10px] text-emerald-700 font-bold">✓ Income Tax Gateway Linked</span>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 md:col-span-2 lg:col-span-3 space-y-1">
                <span className="text-slate-400 font-semibold block">Permanent Residential Address</span>
                <strong className="text-sm text-slate-900 block">{user.address}</strong>
                <span className="text-[11px] text-slate-600 block">
                  District: <strong>{user.district || user.city}</strong> • State: <strong>{user.state}</strong> • PIN: <strong>{user.pincode}</strong>
                </span>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* MODAL: EDIT CITIZEN PROFILE */}
      {/* ========================================================================= */}
      {isEditProfileOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 relative my-8">
            <button
              onClick={() => setIsEditProfileOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
            >
              ✕
            </button>

            <div className="pb-4 border-b border-slate-100 mb-4">
              <h2 className="text-lg font-bold text-[#0A1F44]">Edit Citizen Profile Details</h2>
              <p className="text-xs text-slate-500">Update your particulars across application auto-fill and receipts</p>
            </div>

            <form onSubmit={handleProfileSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-semibold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={editDob}
                    onChange={(e) => setEditDob(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Gender</label>
                  <select
                    value={editGender}
                    onChange={(e) => setEditGender(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email ID</label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Residential Street Address</label>
                <textarea
                  rows={2}
                  value={editAddress}
                  onChange={(e) => setEditAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">City / District</label>
                  <input
                    type="text"
                    value={editCity}
                    onChange={(e) => {
                      setEditCity(e.target.value);
                      setEditDistrict(e.target.value);
                    }}
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">State</label>
                  <input
                    type="text"
                    value={editState}
                    onChange={(e) => setEditState(e.target.value)}
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">PIN Code</label>
                  <input
                    type="text"
                    maxLength={6}
                    value={editPincode}
                    onChange={(e) => setEditPincode(e.target.value)}
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsEditProfileOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0A1F44] hover:bg-blue-900 text-white font-bold rounded-lg shadow-sm"
                >
                  Save Profile Updates
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: UPLOAD VAULT DOCUMENT */}
      {/* ========================================================================= */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 relative">
            <button
              onClick={() => setIsUploadModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
            >
              ✕
            </button>

            <div className="pb-4 border-b border-slate-100 mb-4">
              <h2 className="text-lg font-bold text-[#0A1F44]">Upload to DigiLocker Vault</h2>
              <p className="text-xs text-slate-500">Secure 256-bit encrypted government repository</p>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Document Title *</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="e.g. Caste Certificate or Form 16"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Document Category</label>
                <select
                  value={newDocType}
                  onChange={(e) => setNewDocType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="Identity & Address Proof">Identity & Address Proof</option>
                  <option value="Revenue & Land Certificate">Revenue & Land Certificate</option>
                  <option value="Educational Credential">Educational Credential</option>
                  <option value="Transport & Vehicle">Transport & Vehicle</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Document / Certificate No.</label>
                <input
                  type="text"
                  value={newDocNumber}
                  onChange={(e) => setNewDocNumber(e.target.value)}
                  placeholder="e.g. CC/2026/99410"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Issuing Authority</label>
                <input
                  type="text"
                  value={newDocIssuer}
                  onChange={(e) => setNewDocIssuer(e.target.value)}
                  placeholder="e.g. Revenue Department, Govt of Maharashtra"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Select File (PDF / JPEG / PNG)</label>
                <input
                  type="file"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-blue-50 file:text-blue-700 file:font-bold hover:file:bg-blue-100"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg shadow-sm"
                >
                  Verify & Store Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: DOCUMENT PREVIEW */}
      {/* ========================================================================= */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150 relative">
            <button
              onClick={() => setPreviewDoc(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
            >
              ✕
            </button>

            <div className="flex items-center space-x-3 pb-4 border-b border-slate-100">
              <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
                <FileCheck className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-[#0A1F44]">{previewDoc.title}</h2>
                <p className="text-xs text-slate-500">Official DigiLocker Certificate Preview</p>
              </div>
            </div>

            <div className="my-6 p-6 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-3">
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Document No:</span>
                <span className="font-mono font-bold text-slate-900">{previewDoc.docNumber}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Issuing Department:</span>
                <span className="font-bold text-slate-900">{previewDoc.issuer}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Issued to Citizen:</span>
                <span className="font-bold text-slate-900">{user.name}</span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Issue Date:</span>
                <span className="text-slate-900">{previewDoc.issueDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Digital Signature:</span>
                <span className="text-emerald-700 font-bold">✓ Valid (CCA India)</span>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
