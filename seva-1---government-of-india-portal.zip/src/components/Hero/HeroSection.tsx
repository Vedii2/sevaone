import React, { useState, useRef, useEffect } from 'react';
import { IndianGovIllustration } from './IndianGovIllustration';
import { ServiceItem, SchemeItem, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  searchPortalCatalog,
  UnifiedSearchResult,
  getRecentSearches,
  saveRecentSearch,
  removeRecentSearch,
  clearAllRecentSearches,
  DEFAULT_RECENT_SEARCHES
} from '../../utils/searchEngine';
import {
  Search,
  Bot,
  Sparkles,
  ArrowRight,
  MessageSquare,
  ShieldCheck,
  CheckCircle,
  FileText,
  CreditCard,
  GraduationCap,
  Users,
  ChevronRight,
  X,
  Clock,
  Compass,
  FileCheck,
  Trash2,
  Send,
  Zap,
  HelpCircle,
  ShieldAlert
} from 'lucide-react';

interface HeroSectionProps {
  currentLanguage: LanguageCode;
  onSelectService: (service: ServiceItem) => void;
  onSelectScheme: (scheme: SchemeItem) => void;
  onOpenAiAssistant: (initialQuery?: string) => void;
  onTrackLookup: (appId: string) => void;
  onOpenEligibilityModal?: () => void;
  onNavigateToTab?: (tab: string) => void;
  userEmail?: string;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currentLanguage,
  onSelectService,
  onSelectScheme,
  onOpenAiAssistant,
  onTrackLookup,
  onOpenEligibilityModal,
  onNavigateToTab,
  userEmail,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [searchResults, setSearchResults] = useState<UnifiedSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  // Sync recent searches
  useEffect(() => {
    setRecentSearches(getRecentSearches(userEmail));
  }, [userEmail]);

  // Real-time dynamic search computation across services, schemes & documents
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(() => {
      const hits = searchPortalCatalog(searchQuery);
      setSearchResults(hits);
      setIsSearching(false);
    }, 100);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Handle outside clicks to close search dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard shortcut listener (Escape closes dropdown)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setIsSearchFocused(false);
      searchInputRef.current?.blur();
    } else if (e.key === 'Enter' && searchQuery.trim()) {
      saveRecentSearch(searchQuery, userEmail);
      setRecentSearches(getRecentSearches(userEmail));
      if (searchResults.length > 0) {
        handleResultClick(searchResults[0]);
      }
    }
  };

  const handleResultClick = (result: UnifiedSearchResult) => {
    saveRecentSearch(searchQuery || result.title, userEmail);
    setRecentSearches(getRecentSearches(userEmail));
    setIsSearchFocused(false);

    if (result.type === 'service' && result.serviceData) {
      onSelectService(result.serviceData);
    } else if (result.type === 'scheme' && result.schemeData) {
      onSelectScheme(result.schemeData);
    } else if (result.type === 'document' && onNavigateToTab) {
      onNavigateToTab('vault');
    }
  };

  const handleRecentClick = (recentItem: string) => {
    setSearchQuery(recentItem);
    saveRecentSearch(recentItem, userEmail);
    setIsSearchFocused(true);
    searchInputRef.current?.focus();
  };

  const handleRemoveRecent = (e: React.MouseEvent, itemToRemove: string) => {
    e.stopPropagation();
    const updated = removeRecentSearch(itemToRemove, userEmail);
    setRecentSearches(updated);
  };

  const handleClearAllRecent = (e: React.MouseEvent) => {
    e.stopPropagation();
    clearAllRecentSearches(userEmail);
    setRecentSearches([]);
  };

  const popularPills = [
    { label: 'Aadhaar Update', query: 'Aadhaar' },
    { label: 'Instant e-PAN', query: 'PAN' },
    { label: 'PM Kisan ₹6,000', query: 'PM Kisan' },
    { label: 'Ayushman Card', query: 'Ayushman' },
    { label: 'Driving License', query: 'Driving License' },
    { label: 'Scholarships', query: 'Scholarship' },
  ];

  const handlePillClick = (query: string) => {
    setSearchQuery(query);
    setIsSearchFocused(true);
    searchInputRef.current?.focus();
  };

  return (
    <section className="relative overflow-hidden bg-[#F3F6F9] pt-6 sm:pt-8 pb-12 sm:pb-16 border-b border-slate-200/80">
      {/* Soft Ambient Background Elements */}
      <div className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1D5FE0]/10 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#F5893C]/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* ========================================================================= */}
          {/* LEFT COLUMN: Headlines, Advanced Search Bar & Quick Trust Pillars (7 Cols) */}
          {/* ========================================================================= */}
          <div className="lg:col-span-7 space-y-5 sm:space-y-6 text-left">
            {/* Official Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/95 border border-slate-200/90 text-[#0A1F44] px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>National Single Window Portal • MeitY</span>
              <span className="text-slate-300">|</span>
              <span className="text-[#1D5FE0] font-bold">1,400+ Services</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-[#0A1F44] tracking-tight leading-[1.08]">
              Government Services,{' '}
              <span className="text-[#1D5FE0] relative inline-block">
                Simplified
              </span>{' '}
              for Every Citizen.
            </h1>

            {/* Supporting Subheadline */}
            <p className="text-sm sm:text-base lg:text-lg text-slate-600 font-medium leading-relaxed max-w-2xl">
              {t.heroSubheadline}
            </p>

            {/* ========================================================================= */}
            {/* ADVANCED FUNCTIONAL SEARCH BAR */}
            {/* ========================================================================= */}
            <div className="relative max-w-2xl" ref={searchContainerRef}>
              <div className="relative flex items-center bg-white p-2 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 border border-slate-200 focus-within:border-[#1D5FE0] focus-within:ring-4 focus-within:ring-blue-500/15">
                <div className="pl-3.5 pr-2 text-[#1D5FE0]">
                  <Search className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchFocused(true);
                  }}
                  onFocus={() => setIsSearchFocused(true)}
                  onKeyDown={handleKeyDown}
                  placeholder={t.searchPlaceholder}
                  className="flex-1 bg-transparent py-3 sm:py-3.5 px-2 text-slate-800 placeholder-slate-400 text-sm sm:text-base focus:outline-none font-medium"
                />
                
                {/* Clear 'X' button */}
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      searchInputRef.current?.focus();
                    }}
                    className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600 mr-2 transition-colors"
                    title="Clear Search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                {/* Primary Search Button */}
                <button
                  onClick={() => {
                    if (searchQuery.trim()) {
                      saveRecentSearch(searchQuery, userEmail);
                      setRecentSearches(getRecentSearches(userEmail));
                    }
                    setIsSearchFocused(true);
                  }}
                  className="bg-[#F5893C] hover:bg-[#e0772d] text-white px-5 sm:px-8 py-3 sm:py-3.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center space-x-1.5 shrink-0 shadow-md hover:shadow-orange-500/30 active:scale-[0.98]"
                >
                  <span>Search</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* ========================================================================= */}
              {/* LIVE AUTOSUGGEST & RECENT SEARCHES DROPDOWN PANEL */}
              {/* ========================================================================= */}
              {isSearchFocused && (
                <div className="absolute left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden max-h-96 overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-150">
                  
                  {/* Loading Shimmer */}
                  {isSearching && (
                    <div className="p-4 space-y-2">
                      <div className="h-4 bg-slate-100 animate-pulse rounded w-1/3" />
                      <div className="h-10 bg-slate-50 animate-pulse rounded-xl" />
                    </div>
                  )}

                  {/* 1. When Input is Empty: Show Recent Searches & Trending Shortcuts */}
                  {!isSearching && !searchQuery.trim() && (
                    <div className="p-3 sm:p-4 space-y-4">
                      {recentSearches.length > 0 && (
                        <div>
                          <div className="flex items-center justify-between pb-2 px-1">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1">
                              <Clock className="w-3.5 h-3.5" />
                              <span>Recent Searches</span>
                            </span>
                            <button
                              onClick={handleClearAllRecent}
                              className="text-[11px] text-rose-600 hover:underline font-semibold flex items-center space-x-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Clear All</span>
                            </button>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                            {recentSearches.map((item) => (
                              <div
                                key={item}
                                onClick={() => handleRecentClick(item)}
                                className="group flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50/80 border border-slate-200/70 hover:border-blue-200 cursor-pointer transition-colors"
                              >
                                <div className="flex items-center space-x-2 min-w-0">
                                  <Clock className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#1D5FE0] shrink-0" />
                                  <span className="text-xs font-semibold text-slate-700 group-hover:text-[#1D5FE0] truncate">
                                    {item}
                                  </span>
                                </div>
                                <button
                                  onClick={(e) => handleRemoveRecent(e, item)}
                                  className="text-slate-300 hover:text-slate-600 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                  title="Remove"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-1 pb-2">
                          Popular Citizen Searches
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {DEFAULT_RECENT_SEARCHES.map((pill) => (
                            <button
                              key={pill}
                              onClick={() => handleRecentClick(pill)}
                              className="px-3 py-1.5 rounded-full text-xs font-semibold bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-[#1D5FE0] border border-slate-200/80 hover:border-blue-200 transition-all flex items-center space-x-1"
                            >
                              <Search className="w-3 h-3 text-slate-400" />
                              <span>{pill}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* 2. When Input Has Text: Show Matching Results */}
                  {!isSearching && searchQuery.trim() && searchResults.length > 0 && (
                    <div className="p-2 divide-y divide-slate-100">
                      {searchResults.slice(0, 7).map((res) => {
                        const isService = res.type === 'service';
                        const isScheme = res.type === 'scheme';
                        const isDoc = res.type === 'document';

                        return (
                          <button
                            key={`${res.type}-${res.id}`}
                            onClick={() => handleResultClick(res)}
                            className="w-full text-left p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between group transition-colors"
                          >
                            <div className="flex items-center space-x-3 min-w-0">
                              <div
                                className={`p-2 rounded-lg shrink-0 transition-colors ${
                                  isService
                                    ? 'bg-blue-50 text-[#1D5FE0] group-hover:bg-[#1D5FE0] group-hover:text-white'
                                    : isScheme
                                    ? 'bg-amber-50 text-[#F5893C] group-hover:bg-[#F5893C] group-hover:text-white'
                                    : 'bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white'
                                }`}
                              >
                                {isService && <FileText className="w-4 h-4" />}
                                {isScheme && <Sparkles className="w-4 h-4" />}
                                {isDoc && <ShieldCheck className="w-4 h-4" />}
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center space-x-2">
                                  <span className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-[#1D5FE0] truncate">
                                    {res.title}
                                  </span>
                                  <span
                                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded border shrink-0 ${
                                      isService
                                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                                        : isScheme
                                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                    }`}
                                  >
                                    {res.badge}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-500 truncate mt-0.5">
                                  {res.subtitle}
                                </div>
                              </div>
                            </div>

                            <span className="text-xs font-bold text-[#1D5FE0] opacity-0 group-hover:opacity-100 transition-opacity flex items-center shrink-0 pl-2">
                              {res.actionText} <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {/* 3. When Search Has No Matches */}
                  {!isSearching && searchQuery.trim() && searchResults.length === 0 && (
                    <div className="p-6 text-center text-slate-500 space-y-3">
                      <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                        <Search className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-700">
                          No direct records found for "{searchQuery}"
                        </p>
                        <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                          Try searching for Aadhaar, PAN, Driving License, PM Kisan, or ask our AI Assistant.
                        </p>
                      </div>

                      <div className="pt-1 flex justify-center">
                        <button
                          onClick={() => {
                            setIsSearchFocused(false);
                            onOpenAiAssistant(`I am looking for information on: ${searchQuery}`);
                          }}
                          className="inline-flex items-center space-x-1.5 bg-gradient-to-r from-[#1D5FE0] to-[#0A47B8] hover:from-[#174ebd] hover:to-[#083893] text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 active:scale-95 transition-all"
                        >
                          <Bot className="w-3.5 h-3.5" />
                          <span>Ask SevaMitra AI about "{searchQuery}"</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Popular Search Pills */}
            <div className="flex items-center flex-wrap gap-2 pt-1">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mr-1">
                {t.popularSearches}:
              </span>
              {popularPills.map((pill) => (
                <button
                  key={pill.label}
                  onClick={() => handlePillClick(pill.query)}
                  className="px-3.5 py-1.5 rounded-full text-xs font-semibold bg-white hover:border-[#1D5FE0] text-slate-700 hover:text-[#1D5FE0] border border-slate-200 shadow-2xs transition-all active:scale-95"
                >
                  {pill.label}
                </button>
              ))}
            </div>

            {/* Quick Trust Highlights */}
            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-200/80">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-slate-600 font-medium">100% Aadhaar Verified</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-[#1D5FE0] shrink-0" />
                <span className="text-xs text-slate-600 font-medium">Zero Red Tape SLAs</span>
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-[#F5893C] shrink-0" />
                <span className="text-xs text-slate-600 font-medium">Instant DigiLocker Vault</span>
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* RIGHT COLUMN: Illustration + Premium Redesigned SevaMitra AI Card (5 Cols) */}
          {/* ========================================================================= */}
          <div className="lg:col-span-5 relative flex flex-col items-center">
            {/* Illustrated Friendly Indian Family & Govt Secretariat */}
            <div className="w-full relative z-0">
              <IndianGovIllustration />
            </div>

            {/* ========================================================================= */}
            {/* REDESIGNED SEVAMITRA AI ASSISTANT WIDGET / CARD */}
            {/* ========================================================================= */}
            <div
              id="sevamitra-ai-card"
              className="w-full max-w-md -mt-10 sm:-mt-14 relative z-10 bg-gradient-to-b from-white via-blue-50/25 to-white rounded-2xl sm:rounded-3xl p-5 sm:p-6 shadow-xl hover:shadow-2xl border border-blue-100/90 ring-1 ring-slate-900/5 transition-all duration-300 overflow-hidden group"
            >
              {/* Soft Ambient Background Aura */}
              <div className="absolute top-0 right-0 w-36 h-36 bg-gradient-to-bl from-blue-400/10 via-cyan-400/5 to-transparent rounded-full blur-2xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#F5893C]/5 rounded-full blur-2xl pointer-events-none" />

              {/* 1. Top Bar: Alive Avatar + Typographic Hierarchy + Primary "Chat Now" Action */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-100/90 relative z-10">
                <div className="flex items-center space-x-3 min-w-0">
                  {/* Alive Bot Avatar with Pulsing Halo Ring & Online Status */}
                  <div className="relative shrink-0">
                    {/* Breathing animated aura ring */}
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-[#1D5FE0] via-cyan-400 to-indigo-600 rounded-2xl blur-xs opacity-60 group-hover:opacity-100 animate-pulse transition duration-500" />
                    
                    {/* Avatar Icon Box */}
                    <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#0A1F44] via-[#1D5FE0] to-[#0284C7] text-white flex items-center justify-center shadow-md shadow-blue-500/25 ring-2 ring-white">
                      <Bot className="w-6 h-6" />
                    </div>

                    {/* Verified Green Live Ping Indicator */}
                    <span className="absolute -bottom-0.5 -right-0.5 flex h-3.5 w-3.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-white" />
                    </span>
                  </div>

                  {/* Header Titles & Badges */}
                  <div className="min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <h2 className="text-base font-extrabold text-[#0A1F44] tracking-tight truncate">
                        SevaMitra AI
                      </h2>
                      <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold px-2 py-0.5 rounded-full shrink-0">
                        24×7 Live
                      </span>
                    </div>
                    <p className="text-[11px] font-semibold text-[#1D5FE0] uppercase tracking-wider truncate">
                      Citizen AI Assistant
                    </p>
                  </div>
                </div>

                {/* Primary "Chat Now" Button with Gradient & Soft Glow */}
                <button
                  onClick={() => onOpenAiAssistant()}
                  className="bg-gradient-to-r from-[#1D5FE0] via-[#2563EB] to-[#1E40AF] hover:from-[#174ebd] hover:to-[#083893] text-white text-xs font-bold px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl shadow-md shadow-blue-500/25 hover:shadow-lg hover:shadow-blue-500/40 transition-all duration-200 flex items-center space-x-1.5 shrink-0 active:scale-95"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{t.chatWithBot || 'Chat Now'}</span>
                </button>
              </div>

              {/* 2. Bot Greeting Speech Bubble with Softer Typography & Clean Hierarchy */}
              <div className="my-3.5 bg-gradient-to-br from-blue-50/70 via-slate-50/80 to-blue-50/40 p-3.5 rounded-2xl border border-blue-100/80 text-xs text-slate-700 leading-relaxed font-medium relative z-10 shadow-2xs break-words">
                <div className="flex items-start space-x-2">
                  <Sparkles className="w-4 h-4 text-[#1D5FE0] shrink-0 mt-0.5" />
                  <p className="min-w-0">
                    "{t.aiGreeting}"
                  </p>
                </div>
              </div>

              {/* 3. Redesigned Interactive Quick-Action Chips with Icons & Pill Shapes */}
              <div className="space-y-2 relative z-10">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                  <Zap className="w-3 h-3 text-amber-500" />
                  <span>Quick Inquiries & Actions</span>
                </div>
                
                <div className="flex flex-col gap-1.5">
                  {/* Action 1: Check Scheme Eligibility */}
                  <button
                    onClick={() => {
                      if (onOpenEligibilityModal) {
                        onOpenEligibilityModal();
                      } else {
                        onOpenAiAssistant('Check my eligibility for government welfare schemes');
                      }
                    }}
                    className="w-full text-left bg-white hover:bg-[#1D5FE0] hover:text-white border border-slate-200/90 hover:border-[#1D5FE0] shadow-2xs hover:shadow-md transition-all px-3 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between group/chip active:scale-[0.98]"
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="p-1 rounded-md bg-amber-50 text-amber-600 group-hover/chip:bg-white/20 group-hover/chip:text-white transition-colors">
                        <Sparkles className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Check my eligibility for schemes</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover/chip:text-white opacity-70 group-hover/chip:opacity-100 transition-all shrink-0 ml-1" />
                  </button>

                  {/* Action 2: Track My Application */}
                  <button
                    onClick={() => {
                      if (onNavigateToTab) {
                        onNavigateToTab('track');
                      } else {
                        onTrackLookup('');
                      }
                    }}
                    className="w-full text-left bg-white hover:bg-[#1D5FE0] hover:text-white border border-slate-200/90 hover:border-[#1D5FE0] shadow-2xs hover:shadow-md transition-all px-3 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between group/chip active:scale-[0.98]"
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="p-1 rounded-md bg-blue-50 text-[#1D5FE0] group-hover/chip:bg-white/20 group-hover/chip:text-white transition-colors">
                        <Compass className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Track my application status</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover/chip:text-white opacity-70 group-hover/chip:opacity-100 transition-all shrink-0 ml-1" />
                  </button>

                  {/* Action 3: Find Public Services */}
                  <button
                    onClick={() => {
                      if (onNavigateToTab) {
                        onNavigateToTab('services');
                      } else {
                        onOpenAiAssistant('What public services are available on SEVA 1?');
                      }
                    }}
                    className="w-full text-left bg-white hover:bg-[#1D5FE0] hover:text-white border border-slate-200/90 hover:border-[#1D5FE0] shadow-2xs hover:shadow-md transition-all px-3 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between group/chip active:scale-[0.98]"
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="p-1 rounded-md bg-indigo-50 text-indigo-600 group-hover/chip:bg-white/20 group-hover/chip:text-white transition-colors">
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Find government public services</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover/chip:text-white opacity-70 group-hover/chip:opacity-100 transition-all shrink-0 ml-1" />
                  </button>

                  {/* Action 4: Lodge Grievance (CPGRAMS) */}
                  <button
                    onClick={() => {
                      if (onNavigateToTab) {
                        onNavigateToTab('grievances');
                      } else {
                        onOpenAiAssistant('How do I lodge a grievance on CPGRAMS?');
                      }
                    }}
                    className="w-full text-left bg-white hover:bg-[#1D5FE0] hover:text-white border border-slate-200/90 hover:border-[#1D5FE0] shadow-2xs hover:shadow-md transition-all px-3 py-2 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between group/chip active:scale-[0.98]"
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <div className="p-1 rounded-md bg-emerald-50 text-emerald-600 group-hover/chip:bg-white/20 group-hover/chip:text-white transition-colors">
                        <ShieldAlert className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">Lodge CPGRAMS grievance</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover/chip:text-white opacity-70 group-hover/chip:opacity-100 transition-all shrink-0 ml-1" />
                  </button>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
