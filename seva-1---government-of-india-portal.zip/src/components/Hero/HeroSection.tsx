import React, { useState, useRef, useEffect } from 'react';
import { IndianGovIllustration } from './IndianGovIllustration';
import { SERVICES_LIST } from '../../data/servicesData';
import { SCHEMES_LIST } from '../../data/schemesData';
import { ServiceItem, SchemeItem, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  Search,
  Bot,
  Sparkles,
  ArrowRight,
  MessageSquare,
  ShieldCheck,
  CheckCircle,
  FileText,
  CreditCard,
  GraduationCap,
  Users,
  ChevronRight,
  X
} from 'lucide-react';

interface HeroSectionProps {
  currentLanguage: LanguageCode;
  onSelectService: (service: ServiceItem) => void;
  onSelectScheme: (scheme: SchemeItem) => void;
  onOpenAiAssistant: (initialQuery?: string) => void;
  onTrackLookup: (appId: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currentLanguage,
  onSelectService,
  onSelectScheme,
  onOpenAiAssistant,
  onTrackLookup,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const popularPills = [
    { label: 'Aadhaar Update', query: 'Aadhaar', serviceId: 'aadhaar-update' },
    { label: 'PAN Card', query: 'PAN', serviceId: 'pan-card' },
    { label: 'Scholarship', query: 'Scholarship', schemeId: 'national-scholarship' },
    { label: 'Pension Scheme', query: 'Pension', schemeId: 'national-pension-system' },
    { label: 'Driving License', query: 'Driving', serviceId: 'driving-license' },
  ];

  // Filter matching services & schemes
  const filteredServices = searchQuery.trim()
    ? SERVICES_LIST.filter(
        (s) =>
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.department.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 4)
    : [];

  const filteredSchemes = searchQuery.trim()
    ? SCHEMES_LIST.filter(
        (sc) =>
          sc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          sc.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
          sc.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
      ).slice(0, 3)
    : [];

  // Close search popup if clicked outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handlePillClick = (pill: typeof popularPills[0]) => {
    setSearchQuery(pill.label);
    if (pill.serviceId) {
      const match = SERVICES_LIST.find((s) => s.id === pill.serviceId);
      if (match) onSelectService(match);
    } else if (pill.schemeId) {
      const match = SCHEMES_LIST.find((sc) => sc.id === pill.schemeId);
      if (match) onSelectScheme(match);
    }
  };

  return (
    <section className="relative overflow-hidden bg-[#F3F6F9] pt-8 pb-14 border-b border-slate-200/80">
      {/* Soft Ambient Background Elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1D5FE0]/10 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#F5893C]/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headlines, Search Bar & Popular Search Pills (7 Cols) */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Official Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/90 border border-slate-200/80 text-[#0A1F44] px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>National Single Window Portal • MeitY</span>
              <span className="text-slate-300">|</span>
              <span className="text-[#1D5FE0] font-bold">1,400+ Services</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-[#0A1F44] tracking-tight leading-[1.05]">
              Government Services,{' '}
              <span className="text-[#1D5FE0] relative inline-block">
                Simplified
              </span>{' '}
              for Every Citizen.
            </h1>

            {/* Supporting Line */}
            <p className="text-base sm:text-lg text-slate-600 font-medium leading-relaxed max-w-2xl">
              {t.heroSubheadline}
            </p>

            {/* Functional Search Bar */}
            <div className="relative max-w-2xl" ref={searchContainerRef}>
              <div className="relative flex items-center bg-white p-2 rounded-2xl shadow-xl hover:shadow-2xl transition-shadow border border-slate-200/90 focus-within:border-[#1D5FE0] focus-within:ring-4 focus-within:ring-blue-500/10">
                <div className="pl-3.5 pr-2 text-slate-400">
                  <Search className="w-5 h-5 text-[#1D5FE0]" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchFocused(true);
                  }}
                  onFocus={() => setIsSearchFocused(true)}
                  placeholder={t.searchPlaceholder}
                  className="flex-1 bg-transparent py-3 sm:py-3.5 px-2 text-slate-800 placeholder-slate-400 text-base sm:text-lg focus:outline-none font-medium"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-600 mr-2"
                    title="Clear Search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => {
                    if (searchQuery.trim()) {
                      setIsSearchFocused(true);
                    }
                  }}
                  className="bg-[#F5893C] hover:bg-[#e0772d] text-white px-6 sm:px-8 py-3 sm:py-3.5 rounded-xl text-sm sm:text-base font-bold transition-all flex items-center space-x-2 shrink-0 shadow-lg hover:shadow-orange-500/30"
                >
                  <span>Search</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Live Instant Search Results Dropdown */}
              {isSearchFocused && searchQuery.trim().length > 0 && (
                <div className="absolute left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden max-h-96 overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-150">
                  {filteredServices.length === 0 && filteredSchemes.length === 0 ? (
                    <div className="p-6 text-center text-slate-500">
                      <p className="text-sm font-medium">No direct service found for "{searchQuery}"</p>
                      <p className="text-xs text-slate-400 mt-1">Try searching "Aadhaar", "PAN", "Driving License", "PM Kisan" or ask our AI Assistant.</p>
                      <button
                        onClick={() => {
                          setIsSearchFocused(false);
                          onOpenAiAssistant(`I am looking for information on: ${searchQuery}`);
                        }}
                        className="mt-3 inline-flex items-center space-x-1.5 bg-blue-50 text-[#1D5FE0] hover:bg-blue-100 px-3.5 py-1.5 rounded-lg text-xs font-bold"
                      >
                        <Bot className="w-3.5 h-3.5" />
                        <span>Ask AI Assistant about "{searchQuery}"</span>
                      </button>
                    </div>
                  ) : (
                    <div className="p-2 divide-y divide-slate-100">
                      {filteredServices.length > 0 && (
                        <div className="py-2">
                          <div className="px-3 pb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                            Public Services ({filteredServices.length})
                          </div>
                          {filteredServices.map((service) => (
                            <button
                              key={service.id}
                              onClick={() => {
                                onSelectService(service);
                                setIsSearchFocused(false);
                              }}
                              className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-50 flex items-center justify-between group transition-colors"
                            >
                              <div className="flex items-center space-x-3">
                                <div className="p-2 rounded-lg bg-blue-50 text-[#1D5FE0] group-hover:bg-[#1D5FE0] group-hover:text-white transition-colors">
                                  <FileText className="w-4 h-4" />
                                </div>
                                <div>
                                  <div className="text-sm font-bold text-slate-800 group-hover:text-[#1D5FE0]">
                                    {service.title}
                                  </div>
                                  <div className="text-xs text-slate-500 line-clamp-1">
                                    {service.department}
                                  </div>
                                </div>
                              </div>
                              <span className="text-xs font-semibold text-[#1D5FE0] opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                                Apply <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                              </span>
                            </button>
                          ))}
                        </div>
                      )}

                      {filteredSchemes.length > 0 && (
                        <div className="py-2">
                          <div className="px-3 pb-1.5 text-[11px] font-bold uppercase tracking-wider text-[#F5893C]">
                            Government Welfare Schemes ({filteredSchemes.length})
                          </div>
                          {filteredSchemes.map((scheme) => (
                            <button
                              key={scheme.id}
                              onClick={() => {
                                onSelectScheme(scheme);
                                setIsSearchFocused(false);
                              }}
                              className="w-full text-left px-3 py-2 rounded-xl hover:bg-amber-50/50 flex items-center justify-between group transition-colors"
                            >
                              <div className="flex items-center space-x-3">
                                <div className="p-2 rounded-lg bg-amber-50 text-[#F5893C] group-hover:bg-[#F5893C] group-hover:text-white transition-colors">
                                  <Sparkles className="w-4 h-4" />
                                </div>
                                <div>
                                  <div className="text-sm font-bold text-slate-800 group-hover:text-[#F5893C]">
                                    {scheme.name}
                                  </div>
                                  <div className="text-xs text-slate-500">
                                    Benefit: <span className="font-semibold text-emerald-600">{scheme.benefitAmount}</span>
                                  </div>
                                </div>
                              </div>
                              <span className="text-xs font-semibold text-[#F5893C] opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                                Check Eligibility <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Popular Search Pills */}
            <div className="flex items-center flex-wrap gap-2 pt-1">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mr-1">
                {t.popularSearches}:
              </span>
              {popularPills.map((pill) => (
                <button
                  key={pill.label}
                  onClick={() => handlePillClick(pill)}
                  className="px-4 py-1.5 rounded-full text-[13px] font-semibold bg-white hover:border-[#1D5FE0] text-slate-700 hover:text-[#1D5FE0] border border-slate-200 shadow-2xs transition-all active:scale-95"
                >
                  {pill.label}
                </button>
              ))}
            </div>

            {/* Quick Trust Highlights */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-200/80">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-xs text-slate-600 font-medium">100% Aadhaar Verified</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-[#1D5FE0] shrink-0" />
                <span className="text-xs text-slate-600 font-medium">Zero Red Tape SLAs</span>
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-[#F5893C] shrink-0" />
                <span className="text-xs text-slate-600 font-medium">Instant DigiLocker Vault</span>
              </div>
            </div>
          </div>

          {/* Right Column: High Quality Illustration + Frosted Glass Editorial AI Assistant Card (5 Cols) */}
          <div className="lg:col-span-5 relative flex flex-col items-center">
            {/* Illustrated Friendly Indian Family & Govt Secretariat */}
            <div className="w-full relative z-0">
              <IndianGovIllustration />
            </div>

            {/* Floating AI Assistant Card (Editorial Aesthetic Frosted Glass Card) */}
            <div className="w-full max-w-md -mt-10 sm:-mt-14 relative z-10 bg-white/85 backdrop-blur-xl rounded-[32px] sm:rounded-[36px] p-6 sm:p-7 shadow-2xl border border-white ring-1 ring-slate-900/5 transition-transform hover:-translate-y-1 duration-200 overflow-hidden">
              {/* Card Ambient Glow */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#F5893C]/10 rounded-full blur-3xl pointer-events-none" />

              {/* Header with Avatar & Status */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 relative z-10">
                <div className="flex items-center space-x-3.5">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-2xl bg-[#1D5FE0] text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
                      <Bot className="w-6 h-6" />
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-[#0A1F44] flex items-center space-x-1.5">
                      <span>SevaMitra AI</span>
                      <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full">
                        24x7
                      </span>
                    </h2>
                    <p className="text-xs font-semibold text-[#1D5FE0] uppercase tracking-wider">Citizen AI Assistant</p>
                  </div>
                </div>

                <button
                  onClick={() => onOpenAiAssistant()}
                  className="bg-[#1D5FE0] hover:bg-[#0A1F44] text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-md transition-colors flex items-center space-x-1"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{t.chatWithBot}</span>
                </button>
              </div>

              {/* Bot Greeting Speech Bubble */}
              <div className="my-3.5 bg-slate-50/90 p-3.5 rounded-2xl border border-slate-200/70 text-xs text-slate-700 leading-relaxed font-medium relative z-10">
                "{t.aiGreeting}"
              </div>

              {/* Quick Action Chips (Fully working) */}
              <div className="space-y-2 relative z-10">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                  Quick Inquiries
                </div>
                <div className="flex flex-col gap-1.5">
                  <button
                    onClick={() => onOpenAiAssistant('How do I check my PM Kisan 19th installment status and DBT link?')}
                    className="w-full text-left bg-slate-100 hover:bg-[#1D5FE0] hover:text-white transition-all px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 text-slate-700 flex items-center justify-between group"
                  >
                    <span>Check PM Kisan Status</span>
                    <ChevronRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100" />
                  </button>

                  <button
                    onClick={() => {
                      const panService = SERVICES_LIST.find((s) => s.id === 'pan-card');
                      if (panService) onSelectService(panService);
                    }}
                    className="w-full text-left bg-slate-100 hover:bg-[#1D5FE0] hover:text-white transition-all px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 text-slate-700 flex items-center justify-between group"
                  >
                    <span>Apply for PAN Card Online</span>
                    <ChevronRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100" />
                  </button>

                  <button
                    onClick={() => onOpenAiAssistant('How do I file a grievance against Fair Price Shop ration delay?')}
                    className="w-full text-left bg-slate-100 hover:bg-[#1D5FE0] hover:text-white transition-all px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-200 text-slate-700 flex items-center justify-between group"
                  >
                    <span>Grievance against Ration Card Delay</span>
                    <ChevronRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100" />
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
