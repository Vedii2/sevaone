import React from 'react';

export const IndianGovIllustration: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`relative w-full aspect-4/3 max-w-lg mx-auto select-none ${className}`}>
      <svg
        viewBox="0 0 540 420"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-lg"
      >
        <defs>
          <linearGradient id="skyGrad" x1="270" y1="0" x2="270" y2="420" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#E0F2FE" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#F1F5F9" stopOpacity="0.9" />
          </linearGradient>
          <linearGradient id="buildingGrad" x1="270" y1="60" x2="270" y2="340" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
          <linearGradient id="flagPoleGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#E2E8F0" />
            <stop offset="100%" stopColor="#64748B" />
          </linearGradient>
          <filter id="softShadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="6" stdDeviation="8" floodColor="#0F172A" floodOpacity="0.08" />
          </filter>
        </defs>

        {/* Ambient Backdrop Circle */}
        <circle cx="270" cy="220" r="190" fill="#EEF2F6" />
        <circle cx="270" cy="220" r="160" fill="#F8FAFC" />

        {/* Trees & Foliage in Background */}
        <circle cx="100" cy="240" r="45" fill="#86EFAC" opacity="0.6" />
        <circle cx="125" cy="230" r="35" fill="#4ADE80" opacity="0.7" />
        <circle cx="440" cy="240" r="45" fill="#86EFAC" opacity="0.6" />
        <circle cx="415" cy="230" r="35" fill="#4ADE80" opacity="0.7" />

        {/* Government Building (Classical Secretariat Architecture) */}
        <g id="govt-building" filter="url(#softShadow)">
          {/* Main Base Plinth */}
          <rect x="90" y="240" width="360" height="40" rx="3" fill="#E2E8F0" />
          <rect x="80" y="275" width="380" height="15" rx="2" fill="#CBD5E1" />

          {/* Central Facade Block */}
          <rect x="170" y="140" width="200" height="105" fill="#FFFBEB" stroke="#FDE68A" strokeWidth="2" />

          {/* Wing Blocks (Left & Right) */}
          <rect x="110" y="170" width="60" height="75" fill="#FEF3C7" />
          <rect x="370" y="170" width="60" height="75" fill="#FEF3C7" />

          {/* Wing Windows */}
          <rect x="122" y="185" width="12" height="20" rx="6" fill="#93C5FD" opacity="0.8" />
          <rect x="146" y="185" width="12" height="20" rx="6" fill="#93C5FD" opacity="0.8" />
          <rect x="382" y="185" width="12" height="20" rx="6" fill="#93C5FD" opacity="0.8" />
          <rect x="406" y="185" width="12" height="20" rx="6" fill="#93C5FD" opacity="0.8" />

          {/* Classical Sandstone Columns */}
          <rect x="185" y="155" width="10" height="85" fill="#FDE68A" rx="1" />
          <rect x="215" y="155" width="10" height="85" fill="#FDE68A" rx="1" />
          <rect x="245" y="155" width="10" height="85" fill="#FDE68A" rx="1" />
          <rect x="285" y="155" width="10" height="85" fill="#FDE68A" rx="1" />
          <rect x="315" y="155" width="10" height="85" fill="#FDE68A" rx="1" />
          <rect x="345" y="155" width="10" height="85" fill="#FDE68A" rx="1" />

          {/* Main Entrance Archway */}
          <path d="M250 245V200C250 188 290 188 290 200V245H250Z" fill="#1E293B" />
          <path d="M255 245V205C255 195 285 195 285 205V245H255Z" fill="#0F172A" />

          {/* Classical Triangular Pediment Roof */}
          <path d="M160 142L270 95L380 142H160Z" fill="#F59E0B" />
          <path d="M175 140L270 102L365 140H175Z" fill="#FCD34D" />

          {/* Central Majestic Dome */}
          <path d="M235 95C235 60 305 60 305 95H235Z" fill="#D97706" />
          <rect x="245" y="90" width="50" height="8" fill="#B45309" />
          <circle cx="270" cy="55" r="5" fill="#F59E0B" />
          <rect x="268" y="45" width="4" height="15" fill="#D97706" />

          {/* Ashoka Chakra Motif in Pediment */}
          <circle cx="270" cy="124" r="9" fill="none" stroke="#0A1F44" strokeWidth="1.5" />
          <circle cx="270" cy="124" r="2" fill="#0A1F44" />
        </g>

        {/* Flag Mast & Fluttering Indian Flag (Tiranga) */}
        <g id="indian-flag">
          {/* Mast */}
          <line x1="270" y1="45" x2="270" y2="10" stroke="#64748B" strokeWidth="3" strokeLinecap="round" />
          <circle cx="270" cy="9" r="3.5" fill="#F59E0B" />

          {/* Fluttering Tricolor Wave */}
          <g transform="translate(270, 10)">
            {/* Top Stripe: Saffron */}
            <path
              d="M0 0C15 -3 30 3 45 -1C60 -5 75 1 80 -1V11C75 13 60 7 45 11C30 15 15 9 0 12V0Z"
              fill="#FF9933"
            />
            {/* Middle Stripe: White */}
            <path
              d="M0 12C15 9 30 15 45 11C60 7 75 13 80 11V23C75 25 60 19 45 23C30 27 15 21 0 24V12Z"
              fill="#FFFFFF"
            />
            {/* Ashoka Chakra on White Stripe */}
            <circle cx="40" cy="17" r="4.5" fill="none" stroke="#000080" strokeWidth="1" />
            <circle cx="40" cy="17" r="1" fill="#000080" />
            {/* Bottom Stripe: Green */}
            <path
              d="M0 24C15 21 30 27 45 23C60 19 75 25 80 23V35C75 37 60 31 45 35C30 39 15 33 0 36V24Z"
              fill="#138808"
            />
          </g>
        </g>

        {/* Lawn & Pathway in Foreground */}
        <path d="M40 375C120 365 420 365 500 375V420H40V375Z" fill="#10B981" opacity="0.25" />
        <path d="M190 300L140 420H400L350 300H190Z" fill="#F1F5F9" />

        {/* Illustrated Friendly Indian Family (Grandfather, Father, Mother, Daughter) */}
        <g id="indian-family" transform="translate(130, 240)">
          {/* 1. Grandfather (Left) */}
          <g id="grandfather">
            {/* Legs & Kurta Pajama */}
            <rect x="25" y="100" width="8" height="40" fill="#E2E8F0" rx="3" />
            <rect x="37" y="100" width="8" height="40" fill="#E2E8F0" rx="3" />
            {/* Shoes */}
            <ellipse cx="28" cy="142" rx="6" ry="3" fill="#475569" />
            <ellipse cx="42" cy="142" rx="6" ry="3" fill="#475569" />
            {/* White Kurta & Nehru Jacket (Brown) */}
            <path d="M18 45C18 42 52 42 52 45V105H18V45Z" fill="#FFFFFF" />
            <path d="M20 48C20 46 50 46 50 48V95H20V48Z" fill="#92400E" rx="2" />
            {/* Head & Silver Hair & Glasses */}
            <circle cx="35" cy="28" r="12" fill="#FCD34D" />
            <path d="M23 24C23 16 47 16 47 24C47 20 45 15 35 15C25 15 23 20 23 24Z" fill="#E2E8F0" />
            <circle cx="31" cy="27" r="2.5" fill="none" stroke="#334155" strokeWidth="1" />
            <circle cx="39" cy="27" r="2.5" fill="none" stroke="#334155" strokeWidth="1" />
            <line x1="33.5" y1="27" x2="36.5" y2="27" stroke="#334155" strokeWidth="1" />
            {/* Warm Smile */}
            <path d="M32 34C34 36 36 36 38 34" stroke="#78350F" strokeWidth="1" strokeLinecap="round" />
          </g>

          {/* 2. Father (Center-Left) */}
          <g id="father" transform="translate(60, 0)">
            {/* Trousers & Shoes */}
            <rect x="20" y="95" width="10" height="45" fill="#1E293B" rx="3" />
            <rect x="34" y="95" width="10" height="45" fill="#1E293B" rx="3" />
            <ellipse cx="24" cy="142" rx="7" ry="3.5" fill="#0F172A" />
            <ellipse cx="40" cy="142" rx="7" ry="3.5" fill="#0F172A" />
            {/* Formal Shirt (Smart Blue) */}
            <path d="M12 40C12 36 52 36 52 40V100H12V40Z" fill="#1D5FE0" rx="3" />
            <polygon points="32,40 28,60 36,60" fill="#0F172A" />
            {/* Head & Hair */}
            <circle cx="32" cy="22" r="13" fill="#FBBF24" />
            <path d="M19 18C19 9 45 9 45 18C45 12 42 7 32 7C22 7 19 12 19 18Z" fill="#1E293B" />
            <circle cx="28" cy="22" r="1.5" fill="#1E293B" />
            <circle cx="36" cy="22" r="1.5" fill="#1E293B" />
            <path d="M29 28C31 30 33 30 35 28" stroke="#78350F" strokeWidth="1.2" strokeLinecap="round" />
          </g>

          {/* 3. Mother (Center-Right in Elegant Saffron / Teal Saree) */}
          <g id="mother" transform="translate(130, 8)">
            {/* Saree Pallu & Drape */}
            <path d="M12 45C12 40 48 40 48 45L54 135H6L12 45Z" fill="#059669" />
            <path d="M12 45L48 95L44 135L10 80Z" fill="#F5893C" />
            {/* Head & Traditional Bindi */}
            <circle cx="30" cy="24" r="12" fill="#FBBF24" />
            <path d="M18 20C18 10 42 10 42 20C42 14 38 9 30 9C22 9 18 14 18 20Z" fill="#0F172A" />
            {/* Bun */}
            <circle cx="42" cy="20" r="5" fill="#0F172A" />
            <circle cx="30" cy="19" r="1.5" fill="#DC2626" /> {/* Bindi */}
            <circle cx="26" cy="24" r="1.5" fill="#0F172A" />
            <circle cx="34" cy="24" r="1.5" fill="#0F172A" />
            <path d="M27 29C29 31 31 31 33 29" stroke="#78350F" strokeWidth="1.2" strokeLinecap="round" />
          </g>

          {/* 4. Daughter with schoolbag (Right) */}
          <g id="daughter" transform="translate(195, 30)">
            {/* Uniform Skirt & Legs */}
            <rect x="15" y="70" width="7" height="42" fill="#FBBF24" rx="2" />
            <rect x="26" y="70" width="7" height="42" fill="#FBBF24" rx="2" />
            <rect x="10" y="55" width="28" height="22" fill="#1D4ED8" rx="2" />
            {/* Shoes & White Socks */}
            <rect x="15" y="98" width="7" height="10" fill="#FFFFFF" />
            <rect x="26" y="98" width="7" height="10" fill="#FFFFFF" />
            <ellipse cx="18.5" cy="112" rx="5" ry="3" fill="#0F172A" />
            <ellipse cx="29.5" cy="112" rx="5" ry="3" fill="#0F172A" />
            {/* School Shirt & Red Backpack */}
            <rect x="10" y="32" width="28" height="25" fill="#FFFFFF" rx="2" />
            <rect x="4" y="34" width="8" height="24" fill="#DC2626" rx="2" />
            {/* Head & Pigtails */}
            <circle cx="24" cy="18" r="10" fill="#FCD34D" />
            <circle cx="12" cy="16" r="4" fill="#0F172A" />
            <circle cx="36" cy="16" r="4" fill="#0F172A" />
            <path d="M14 14C14 6 34 6 34 14C34 9 30 5 24 5C18 5 14 9 14 14Z" fill="#0F172A" />
            <circle cx="21" cy="18" r="1.2" fill="#0F172A" />
            <circle cx="27" cy="18" r="1.2" fill="#0F172A" />
            <path d="M22 22C23 24 25 24 26 22" stroke="#78350F" strokeWidth="1" strokeLinecap="round" />
          </g>
        </g>
      </svg>
    </div>
  );
};
