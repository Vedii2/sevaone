import React from 'react';
import { ActiveTab, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  FileText,
  Search,
  FolderLock,
  Landmark,
  CreditCard,
  AlertCircle,
  ArrowUpRight,
} from 'lucide-react';

interface QuickActionsGridProps {
  currentLanguage: LanguageCode;
  onNavigate: (tab: ActiveTab) => void;
}

export const QuickActionsGrid: React.FC<QuickActionsGridProps> = ({
  currentLanguage,
  onNavigate,
}) => {
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const actions = [
    {
      id: 'apply-services',
      tab: 'services' as ActiveTab,
      title: 'Apply for Services',
      description: 'Access 1,400+ Central and State public services, licenses, and certificates.',
      icon: FileText,
      iconColor: 'text-[#1D5FE0]',
      badgeBg: 'bg-blue-50 group-hover:bg-[#1D5FE0] group-hover:text-white',
      badgeBorder: 'border-blue-100',
    },
    {
      id: 'track-application',
      tab: 'track' as ActiveTab,
      title: 'Track Application',
      description: 'Real-time timeline tracking with SMS updates and officer remarks.',
      icon: Search,
      iconColor: 'text-[#F5893C]',
      badgeBg: 'bg-orange-50 group-hover:bg-[#F5893C] group-hover:text-white',
      badgeBorder: 'border-orange-100',
    },
    {
      id: 'document-vault',
      tab: 'vault' as ActiveTab,
      title: 'Document Vault',
      description: 'DigiLocker-integrated digital locker for Aadhaar, PAN, DL, and certificates.',
      icon: FolderLock,
      iconColor: 'text-purple-600',
      badgeBg: 'bg-purple-50 group-hover:bg-purple-600 group-hover:text-white',
      badgeBorder: 'border-purple-100',
    },
    {
      id: 'government-schemes',
      tab: 'schemes' as ActiveTab,
      title: 'Government Schemes',
      description: 'Explore welfare benefits, PM Kisan, Ayushman Bharat, and check eligibility.',
      icon: Landmark,
      iconColor: 'text-emerald-600',
      badgeBg: 'bg-emerald-50 group-hover:bg-emerald-600 group-hover:text-white',
      badgeBorder: 'border-emerald-100',
    },
    {
      id: 'make-payments',
      tab: 'payments' as ActiveTab,
      title: 'Make Payments',
      description: 'Pay application fees, utility bills, and download official GST receipts.',
      icon: CreditCard,
      iconColor: 'text-rose-600',
      badgeBg: 'bg-rose-50 group-hover:bg-rose-600 group-hover:text-white',
      badgeBorder: 'border-rose-100',
    },
    {
      id: 'grievance-system',
      tab: 'grievances' as ActiveTab,
      title: 'Grievance Redressal',
      description: 'Lodge formal complaints under CPGRAMS with 21-day guaranteed SLA.',
      icon: AlertCircle,
      iconColor: 'text-slate-700',
      badgeBg: 'bg-slate-100 group-hover:bg-[#0A1F44] group-hover:text-white',
      badgeBorder: 'border-slate-200',
    },
  ];

  return (
    <section className="py-12 bg-white border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 pb-3 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#1D5FE0] mb-1">
              One-Click Citizen Gateway
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0A1F44] tracking-tight">
              {t.quickActions}
            </h2>
          </div>
          <p className="text-sm text-slate-500 mt-1 sm:mt-0 font-medium">
            Fastest path to essential public utilities and workflows
          </p>
        </div>

        {/* 6-Card Responsive Grid with Editorial Styling */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actions.map((action) => {
            const Icon = action.icon;
            return (
              <div
                key={action.id}
                onClick={() => onNavigate(action.tab)}
                className="group bg-white rounded-2xl p-6 border border-slate-200/90 hover:border-[#1D5FE0]/40 shadow-xs hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onNavigate(action.tab);
                  }
                }}
                aria-label={`Navigate to ${action.title}`}
              >
                <div>
                  {/* 14x14 icon badge container */}
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className={`w-14 h-14 rounded-2xl ${action.badgeBg} border ${action.badgeBorder} flex items-center justify-center transition-all`}
                    >
                      <Icon className="w-7 h-7 transition-colors" />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-slate-50 group-hover:bg-blue-50 text-slate-400 group-hover:text-[#1D5FE0] flex items-center justify-center transition-colors">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Bold Title */}
                  <h3 className="text-lg font-bold text-[#0A1F44] group-hover:text-[#1D5FE0] transition-colors leading-snug">
                    {action.title}
                  </h3>

                  {/* Body Description */}
                  <p className="mt-2 text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
                    {action.description}
                  </p>
                </div>

                {/* Footer Link Cue */}
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center text-xs font-bold text-[#1D5FE0] group-hover:underline">
                  <span>Open {action.title}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
