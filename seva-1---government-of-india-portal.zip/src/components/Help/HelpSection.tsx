import React, { useState } from 'react';
import { FAQS_LIST } from '../../data/mockData';
import { FaqItem, LanguageCode } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  HelpCircle,
  ChevronDown,
  BookOpen,
  MessageSquare,
  PhoneCall,
  Mail,
  MapPin,
  Star,
  Search,
  CheckCircle2,
  Download,
  Send
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface HelpSectionProps {
  currentLanguage: LanguageCode;
}

export const HelpSection: React.FC<HelpSectionProps> = ({ currentLanguage }) => {
  const [activeFaqId, setActiveFaqId] = useState<string | null>(FAQS_LIST[0].id);
  const [faqSearch, setFaqSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  // Feedback Form State
  const [feedbackRating, setFeedbackRating] = useState(5);
  const [feedbackAspect, setFeedbackAspect] = useState('Service Speed');
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  // Callback State
  const [callbackName, setCallbackName] = useState('');
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackSubmitted, setCallbackSubmitted] = useState(false);

  // User Manual Modal
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);

  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const categories = ['All', 'General', 'Tracking', 'DigiLocker', 'Schemes', 'Grievances', 'Payments'];

  const filteredFaqs = FAQS_LIST.filter((f) => {
    const matchesCategory = activeCategory === 'All' || f.category === activeCategory;
    const matchesSearch =
      f.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
      f.answer.toLowerCase().includes(faqSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackSubmitted(true);
    confetti({ particleCount: 50, spread: 60 });
  };

  const handleCallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCallbackSubmitted(true);
    confetti({ particleCount: 40 });
  };

  return (
    <section id="help-section" className="py-14 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-2 bg-blue-50 border border-blue-200 text-blue-900 px-3.5 py-1.5 rounded-full text-xs font-semibold mb-3">
            <HelpCircle className="w-4 h-4 text-blue-700" />
            <span>Citizen Assistance & Support Center</span>
          </div>
          <h2 className="text-3xl font-extrabold text-[#0A1F44] tracking-tight">
            How Can We Assist You?
          </h2>
          <p className="mt-2 text-base text-slate-600">
            Find answers to frequently asked questions, consult the step-by-step user manual, provide feedback, or reach our 24x7 National Helpline.
          </p>
        </div>

        {/* 4 Quick Support Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-12">
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center mx-auto mb-3">
              <PhoneCall className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-[#0A1F44] text-base">Toll-Free Helpline</h4>
            <p className="text-xs text-slate-500 mt-1">24x7 All India Assistance</p>
            <div className="mt-3 font-extrabold text-blue-700 text-base">1800-11-SEVA</div>
            <span className="text-[11px] text-slate-400">or dial 1912</span>
          </div>

          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto mb-3">
              <Mail className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-[#0A1F44] text-base">Email Support</h4>
            <p className="text-xs text-slate-500 mt-1">Direct Helpdesk Ticket</p>
            <div className="mt-3 font-bold text-slate-800 text-xs truncate">support@seva1.gov.in</div>
            <span className="text-[11px] text-slate-400">Response within 24 hrs</span>
          </div>

          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-[#0A1F44] text-base">Citizen User Manual</h4>
            <p className="text-xs text-slate-500 mt-1">Visual guides and walkthroughs</p>
            <button
              onClick={() => setIsManualModalOpen(true)}
              className="mt-3 inline-flex items-center space-x-1 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-3 py-1.5 rounded-lg transition-colors"
            >
              <span>View Manual</span>
            </button>
          </div>

          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center mx-auto mb-3">
              <MapPin className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-[#0A1F44] text-base">Seva Kendra Locator</h4>
            <p className="text-xs text-slate-500 mt-1">Find nearby CSC / Aadhaar Center</p>
            <div className="mt-3 text-xs font-bold text-purple-800">5.4 Lakh+ Centers</div>
            <span className="text-[11px] text-slate-400">Across 750+ Districts</span>
          </div>
        </div>

        {/* FAQs & Feedback Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Interactive FAQ Accordion (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-3">
              <h3 className="text-xl font-bold text-[#0A1F44]">Frequently Asked Questions</h3>
              
              {/* FAQ Search */}
              <div className="relative w-full sm:w-60">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={faqSearch}
                  onChange={(e) => setFaqSearch(e.target.value)}
                  placeholder="Search questions..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Category Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveCategory(c)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors border ${
                    activeCategory === c
                      ? 'bg-[#0A1F44] text-white border-[#0A1F44]'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* FAQ Accordion List */}
            <div className="space-y-3 pt-2">
              {filteredFaqs.map((faq) => {
                const isOpen = activeFaqId === faq.id;
                return (
                  <div
                    key={faq.id}
                    className="border border-slate-200 rounded-xl overflow-hidden transition-colors"
                  >
                    <button
                      onClick={() => setActiveFaqId(isOpen ? null : faq.id)}
                      className={`w-full text-left p-4 text-sm font-bold flex items-center justify-between transition-colors ${
                        isOpen ? 'bg-blue-50/70 text-blue-950' : 'bg-slate-50/50 hover:bg-slate-100 text-slate-800'
                      }`}
                      aria-expanded={isOpen}
                    >
                      <span className="pr-4">{faq.question}</span>
                      <ChevronDown className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180 text-blue-700' : ''}`} />
                    </button>
                    {isOpen && (
                      <div className="p-4 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 animate-in fade-in duration-150">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Citizen Feedback Form & Request Callback (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Citizen Feedback Form */}
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <div className="flex items-center space-x-2 pb-3 border-b border-slate-200 mb-4">
                <MessageSquare className="w-5 h-5 text-blue-700" />
                <h3 className="text-base font-bold text-[#0A1F44]">Citizen Feedback & Rating</h3>
              </div>

              {feedbackSubmitted ? (
                <div className="text-center py-6 space-y-2">
                  <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                  <h4 className="font-bold text-slate-800 text-base">Dhanyavaad! Feedback Received</h4>
                  <p className="text-xs text-slate-500">
                    Your rating helps us improve digital public service delivery across India.
                  </p>
                  <button
                    onClick={() => setFeedbackSubmitted(false)}
                    className="mt-3 text-xs font-semibold text-blue-700 hover:underline"
                  >
                    Submit Another Response
                  </button>
                </div>
              ) : (
                <form onSubmit={handleFeedbackSubmit} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1.5">Rate Your Experience</label>
                    <div className="flex items-center space-x-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setFeedbackRating(star)}
                          className="p-1 text-amber-400 hover:scale-110 transition-transform"
                        >
                          <Star className={`w-6 h-6 ${star <= feedbackRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`} />
                        </button>
                      ))}
                      <span className="font-bold text-slate-700 ml-2">({feedbackRating} / 5)</span>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Key Experience Aspect</label>
                    <select
                      value={feedbackAspect}
                      onChange={(e) => setFeedbackAspect(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Service Speed">Application Speed & Clarity</option>
                      <option value="Document Vault">DigiLocker Integration</option>
                      <option value="Application Tracking">Tracking & SMS Updates</option>
                      <option value="Grievance SLA">Grievance Redressal Time</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Your Suggestions (Optional)</label>
                    <textarea
                      rows={3}
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      placeholder="Tell us how we can make government portals even simpler..."
                      className="w-full p-2.5 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#0A1F44] hover:bg-blue-900 text-white font-bold py-2.5 rounded-lg shadow-xs transition-colors flex items-center justify-center space-x-1.5"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    <span>Submit Feedback</span>
                  </button>
                </form>
              )}
            </div>

            {/* Request a Callback Form */}
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200/90 shadow-xs">
              <div className="flex items-center space-x-2 pb-3 border-b border-slate-200 mb-4">
                <PhoneCall className="w-5 h-5 text-emerald-700" />
                <h3 className="text-base font-bold text-[#0A1F44]">Request an Official Callback</h3>
              </div>

              {callbackSubmitted ? (
                <div className="text-center py-4 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                  <p className="text-xs font-bold text-slate-800">
                    Callback requested for {callbackPhone}!
                  </p>
                  <p className="text-[11px] text-slate-500">
                    A Seva Kendra executive will call you back within 15 minutes.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleCallbackSubmit} className="space-y-3 text-xs">
                  <div>
                    <input
                      type="text"
                      required
                      value={callbackName}
                      onChange={(e) => setCallbackName(e.target.value)}
                      placeholder="Your Name"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <input
                      type="tel"
                      required
                      value={callbackPhone}
                      onChange={(e) => setCallbackPhone(e.target.value)}
                      placeholder="Mobile Number (+91)"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 rounded-lg transition-colors"
                  >
                    Request Callback
                  </button>
                </form>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL: CITIZEN USER MANUAL */}
      {/* ========================================================================= */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-blue-700" />
                <h3 className="text-lg font-bold text-[#0A1F44]">Citizen User Manual & Step-by-Step Guide</h3>
              </div>
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="p-1 hover:bg-slate-100 rounded-full text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="my-6 space-y-6 text-xs sm:text-sm text-slate-700">
              <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                <h4 className="font-bold text-blue-900 text-base mb-1">1. How to Apply for a Public Service</h4>
                <p className="text-slate-600 leading-relaxed">
                  Browse the Popular Services section or use the unified search bar. Click "Apply", review mandatory documents, fill in applicant particulars, pay fees via Bharat BillPay, and obtain an instant tracking reference number.
                </p>
              </div>

              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                <h4 className="font-bold text-emerald-900 text-base mb-1">2. Accessing and Reusing Document Vault</h4>
                <p className="text-slate-600 leading-relaxed">
                  The Document Vault connects directly with DigiLocker. Verified certificates like e-Aadhaar, e-PAN, Driving License, and Marksheets are pre-authenticated and automatically attached during scheme/service applications without physical scans.
                </p>
              </div>

              <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
                <h4 className="font-bold text-amber-900 text-base mb-1">3. Checking Scheme Eligibility</h4>
                <p className="text-slate-600 leading-relaxed">
                  Click the "Check Eligibility" button on any scheme or homepage to launch the interactive calculator. Enter annual income, state, and occupation to view instant DBT entitlement recommendations.
                </p>
              </div>

              <div className="p-4 bg-rose-50 rounded-xl border border-rose-200">
                <h4 className="font-bold text-rose-900 text-base mb-1">4. CPGRAMS Grievance Resolution Rights</h4>
                <p className="text-slate-600 leading-relaxed">
                  Every citizen has the legal right to time-bound redressal within 21 days under the Citizen Charter. If unresolved, cases are automatically escalated to the Joint Secretary of the respective Ministry.
                </p>
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-4 border-t border-slate-200">
              <button
                onClick={() => setIsManualModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Close
              </button>
              <button
                onClick={() => {
                  confetti({ particleCount: 40 });
                  alert('Downloading SEVA 1 Official Citizen Handbook (PDF)');
                  setIsManualModalOpen(false);
                }}
                className="px-4 py-2 text-xs font-bold bg-[#0A1F44] hover:bg-blue-900 text-white rounded-lg flex items-center space-x-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Download Handbook (PDF)</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
