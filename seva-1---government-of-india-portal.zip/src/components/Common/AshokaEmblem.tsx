import React from 'react';

interface AshokaEmblemProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
  variant?: 'gold' | 'navy' | 'white' | 'monochrome' | 'black' | 'saffron';
  color?: string;
}

/**
 * Official National Emblem of India (State Emblem of India)
 * Adaptation of the Lion Capital of Ashoka at Sarnath:
 * - Four Asiatic Lions standing back-to-back (3 visible from any angle, with the 4th lion silhouette/crest)
 * - Circular abacus (drum) carved in high relief with the Dharma Chakra (Wheel of Law) at the center
 * - Flanked by a galloping Horse on the left and a stout Bull (Vrishabha) on the right
 * - Inverted bell-shaped lotus base
 * - Motto inscribed in Devanagari script below: "सत्यमेव जयते" (Satyameva Jayate - Truth Alone Triumphs)
 */
export const AshokaEmblem: React.FC<AshokaEmblemProps> = ({
  className = '',
  size = 'md',
  variant = 'gold',
  color,
}) => {
  const sizeMap: Record<string, string> = {
    xs: 'w-5 h-7',
    sm: 'w-6 h-8.5',
    md: 'w-8 h-11 sm:w-9 sm:h-12',
    lg: 'w-12 h-16',
    xl: 'w-16 h-22',
  };

  const colorMap: Record<string, string> = {
    gold: '#9A6014', // Rich warm bronze-gold as used on official state seals
    navy: '#0A1F44',
    black: '#111827',
    white: '#FFFFFF',
    saffron: '#D97706',
    monochrome: 'currentColor',
  };

  const resolvedColor = color || colorMap[variant] || '#0A1F44';
  const accentColor = variant === 'white' ? '#0A1F44' : '#FFFFFF';
  const customDimensions = typeof size === 'number' ? { width: size, height: Math.round(size * 1.38) } : undefined;
  const classes = typeof size === 'string' ? sizeMap[size] || sizeMap.md : '';

  return (
    <div
      className={`inline-flex flex-col items-center justify-center shrink-0 select-none ${className}`}
      style={customDimensions}
      title="National Emblem of India (Lion Capital of Ashoka) - Satyameva Jayate"
      role="img"
      aria-label="Official National Emblem of India - Lion Capital of Ashoka"
    >
      <svg
        className={typeof size === 'string' ? classes : 'w-full h-full'}
        viewBox="0 0 120 166"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        shapeRendering="geometricPrecision"
      >
        <defs>
          <filter id="emblem-shadow" x="-5%" y="-5%" width="110%" height="110%">
            <feDropShadow dx="0" dy="0.5" stdDeviation="0.4" floodOpacity="0.15" />
          </filter>
        </defs>

        {/* ============================================================ */}
        {/* 1. LION CAPITAL OF ASHOKA (FOUR LIONS STANDING BACK-TO-BACK) */}
        {/* ============================================================ */}
        <g filter="url(#emblem-shadow)">
          
          {/* Back 4th Lion Crest Silhouette */}
          <path
            d="M50 8C44 8 40 12 39 16C45 14 55 14 61 16C60 12 56 8 50 8Z"
            fill={resolvedColor}
            opacity="0.85"
          />

          {/* Left Profile Lion (Facing West) */}
          {/* Left Lion Head & Roaring Snout */}
          <path
            d="M26 21C22 17 15 20 12 26C8 34 11 44 18 49C14 54 12 62 16 71C20 78 28 82 35 83C40 83 44 79 46 73C44 63 42 47 43 33C43 25 42 22 41 21C38 18 31 16 26 21Z"
            fill={resolvedColor}
          />
          {/* Left Lion Mane Tuft Curls */}
          <path
            d="M13 32C18 32 23 37 24 43M17 48C23 48 29 53 30 60M20 63C26 64 32 68 34 75"
            stroke={accentColor}
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.6"
          />
          {/* Left Lion Open Eye & Jaw */}
          <circle cx="21" cy="28" r="2" fill={accentColor} />
          <circle cx="21" cy="28" r="1" fill={resolvedColor} />
          <path d="M12 36C15 37 19 36 21 34" stroke={accentColor} strokeWidth="1.2" strokeLinecap="round" />

          {/* Right Profile Lion (Facing East) */}
          {/* Right Lion Head & Roaring Snout */}
          <path
            d="M94 21C98 17 105 20 108 26C112 34 109 44 102 49C106 54 108 62 104 71C100 78 92 82 85 83C80 83 76 79 74 73C76 63 78 47 77 33C77 25 78 22 79 21C82 18 89 16 94 21Z"
            fill={resolvedColor}
          />
          {/* Right Lion Mane Tuft Curls */}
          <path
            d="M107 32C102 32 97 37 96 43M103 48C97 48 91 53 90 60M100 63C94 64 88 68 86 75"
            stroke={accentColor}
            strokeWidth="1.2"
            strokeLinecap="round"
            opacity="0.6"
          />
          {/* Right Lion Open Eye & Jaw */}
          <circle cx="99" cy="28" r="2" fill={accentColor} />
          <circle cx="99" cy="28" r="1" fill={resolvedColor} />
          <path d="M108 36C105 37 101 36 99 34" stroke={accentColor} strokeWidth="1.2" strokeLinecap="round" />

          {/* Central Majestic Lion (Facing Front / South) */}
          {/* Main Head Crown and Massive Textured Mane */}
          <path
            d="M60 11C49 11 41 19 40 28C38 37 39 48 40 57C41 71 44 80 48 87C52 92 56 94 60 94C64 94 68 92 72 87C76 80 79 71 80 57C81 48 82 37 80 28C79 19 71 11 60 11Z"
            fill={resolvedColor}
          />

          {/* Central Lion Distinctive Mane Layer Patterns (Sarnath Style) */}
          <path
            d="M48 24C53 19 67 19 72 24M44 37C51 31 69 31 76 37M42 50C50 44 70 44 78 50M44 63C51 58 69 58 76 63M48 76C54 72 66 72 72 76"
            stroke={accentColor}
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.75"
          />

          {/* Central Lion Ears */}
          <path d="M42 20C40 16 43 14 46 16C47 19 45 22 42 20Z" fill={resolvedColor} stroke={accentColor} strokeWidth="0.8" />
          <path d="M78 20C80 16 77 14 74 16C73 19 75 22 78 20Z" fill={resolvedColor} stroke={accentColor} strokeWidth="0.8" />

          {/* Central Lion Facial Anatomy: Eyes, Forehead Furrow, Snout, Whiskers, Muzzle */}
          {/* Eyes */}
          <ellipse cx="52.5" cy="30" rx="3" ry="2.6" fill={accentColor} />
          <ellipse cx="67.5" cy="30" rx="3" ry="2.6" fill={accentColor} />
          <circle cx="52.5" cy="30" r="1.4" fill={resolvedColor} />
          <circle cx="67.5" cy="30" r="1.4" fill={resolvedColor} />
          {/* Eyebrow / Furrow Arches */}
          <path d="M48 26C51 25 55 26 56 28M72 26C69 25 65 26 64 28" stroke={accentColor} strokeWidth="1.2" strokeLinecap="round" />

          {/* Snout Bridge & Nose */}
          <path d="M57 30H63L61.5 37L58.5 37L57 30Z" fill={accentColor} opacity="0.95" />
          <path d="M56 37C58 40 62 40 64 37C66 40 68 40 70 37" stroke={accentColor} strokeWidth="1.3" strokeLinecap="round" fill="none" />

          {/* Roaring Whisker Pad & Open Mouth / Fangs */}
          <ellipse cx="56" cy="42" rx="2.5" ry="1.5" fill={accentColor} opacity="0.8" />
          <ellipse cx="64" cy="42" rx="2.5" ry="1.5" fill={accentColor} opacity="0.8" />
          <path d="M54 45C57 48 63 48 66 45" stroke={accentColor} strokeWidth="1.5" strokeLinecap="round" />
          <path d="M52 53C56 56 64 56 68 53" stroke={accentColor} strokeWidth="1.2" strokeLinecap="round" opacity="0.7" />

          {/* Front Muscular Chest & Paws */}
          <path d="M53 87L52 94M67 87L68 94" stroke={accentColor} strokeWidth="1.5" strokeLinecap="round" opacity="0.7" />
        </g>

        {/* ============================================================ */}
        {/* 2. CIRCULAR ABACUS (DRUM) WITH HIGH RELIEF SCULPTURES        */}
        {/* ============================================================ */}
        <g>
          {/* Upper Bead/Fillet Molding Line */}
          <rect x="8" y="96" width="104" height="2.5" rx="1.2" fill={resolvedColor} />
          
          {/* Main Abacus Drum Body */}
          <rect x="10" y="99" width="100" height="23" rx="2" fill={resolvedColor} />
          
          {/* Lower Bead/Fillet Molding Line */}
          <rect x="8" y="123" width="104" height="2.5" rx="1.2" fill={resolvedColor} />

          {/* ---------------------------------------------------------- */}
          {/* CENTER ASHOKA CHAKRA (DHARMA WHEEL) - 24 SPOKES           */}
          {/* ---------------------------------------------------------- */}
          <circle cx="60" cy="110.5" r="9" fill="none" stroke={accentColor} strokeWidth="1.6" />
          <circle cx="60" cy="110.5" r="2.2" fill={accentColor} />
          {/* 12 intersecting spoke lines = 24 spokes */}
          {[...Array(12)].map((_, i) => (
            <line
              key={i}
              x1="60"
              y1="102"
              x2="60"
              y2="119"
              stroke={accentColor}
              strokeWidth="0.85"
              transform={`rotate(${i * 15} 60 110.5)`}
            />
          ))}

          {/* ---------------------------------------------------------- */}
          {/* LEFT: GALLOPING HORSE (SYMBOL OF ENERGY & SPEED)           */}
          {/* ---------------------------------------------------------- */}
          <g transform="translate(14, 102)">
            {/* Horse Head & Ears */}
            <path
              d="M19 3C19 2 21 0.5 22 2C23 3.5 22 5 21 6L18 8L15 6L16 4L19 3Z"
              fill={accentColor}
            />
            {/* Arched Neck & Flowing Mane */}
            <path
              d="M17 6C15 8 13 11 11 12C9 13 6 12 5 10C5 7 9 4 15 5"
              fill={accentColor}
              opacity="0.9"
            />
            {/* Powerful Torso & Galloping Forelegs */}
            <path
              d="M12 12C14 13 17 13 19 11L21 14L19 16L16 14L14 16L12 14L10 13L8 14L6 12C7 11 10 11 12 12Z"
              fill={accentColor}
            />
            {/* Hindquarters & Tail */}
            <path
              d="M6 10C4 11 2 13 1 15C2 16 4 15 5 13L6 10Z"
              fill={accentColor}
              opacity="0.8"
            />
          </g>

          {/* ---------------------------------------------------------- */}
          {/* RIGHT: STOUT BULL / VRISHABHA (SYMBOL OF STEADFASTNESS)    */}
          {/* ---------------------------------------------------------- */}
          <g transform="translate(82, 102)">
            {/* Bull Horns & Head */}
            <path
              d="M5 4C4 2 2 1 1 3C0 5 2 7 4 7L6 9L9 7L8 4L5 4Z"
              fill={accentColor}
            />
            {/* Hump & Massive Shoulders */}
            <path
              d="M7 6C9 4 12 4 14 6C16 8 18 10 20 10C21 12 19 14 16 13C13 12 10 11 7 8"
              fill={accentColor}
              opacity="0.9"
            />
            {/* Sturdy Body & Sturdy Hooves */}
            <path
              d="M10 9C12 10 15 11 18 11L19 14L17 15L15 13L13 15L11 13L9 14L7 12C8 10 9 9 10 9Z"
              fill={accentColor}
            />
            {/* Tail */}
            <path
              d="M20 10C22 12 23 14 23 16C22 16 21 15 20 13L20 10Z"
              fill={accentColor}
              opacity="0.8"
            />
          </g>
        </g>

        {/* ============================================================ */}
        {/* 3. INVERTED BELL-SHAPED LOTUS FLOWER BASE                    */}
        {/* ============================================================ */}
        <g>
          {/* Inverted Lotus Bell Outline */}
          <path
            d="M16 127C16 127 26 145 60 145C94 145 104 127 104 127H16Z"
            fill={resolvedColor}
          />
          {/* Distinctive Vertical Fluted Lotus Petal Arches */}
          <path
            d="M28 127C33 135 44 142 60 143C76 142 87 135 92 127"
            stroke={accentColor}
            strokeWidth="1.2"
            opacity="0.55"
            fill="none"
          />
          <path
            d="M38 127C43 133 50 137 60 138C70 137 77 133 82 127"
            stroke={accentColor}
            strokeWidth="1"
            opacity="0.45"
            fill="none"
          />
          <path
            d="M48 127C51 131 55 133 60 133.5C65 133 69 131 72 127"
            stroke={accentColor}
            strokeWidth="0.8"
            opacity="0.35"
            fill="none"
          />

          {/* Stepped Pedestal Base Plinth */}
          <rect x="8" y="146.5" width="104" height="4.5" rx="1.5" fill={resolvedColor} />
        </g>

        {/* ============================================================ */}
        {/* 4. MOTTO: "सत्यमेव जयते" (SATYAMEVA JAYATE) IN DEVANAGARI   */}
        {/* ============================================================ */}
        <text
          x="60"
          y="161.5"
          textAnchor="middle"
          fill={resolvedColor}
          fontSize="10.5"
          fontWeight="900"
          fontFamily="'Noto Sans Devanagari', 'Mukta', 'Kohinoor Devanagari', 'Yantramanav', 'Segoe UI', system-ui, sans-serif"
          letterSpacing="0.06em"
          style={{ textRendering: 'optimizeLegibility' }}
        >
          सत्यमेव जयते
        </text>
      </svg>
    </div>
  );
};

export default AshokaEmblem;
