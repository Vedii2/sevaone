import React from 'react';

interface AshokaEmblemProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  variant?: 'gold' | 'navy' | 'white' | 'monochrome' | 'saffron';
  color?: string;
}

export const AshokaEmblem: React.FC<AshokaEmblemProps> = ({
  className = '',
  size = 'md',
  variant = 'gold',
  color,
}) => {
  const sizeMap: Record<string, string> = {
    sm: 'w-6 h-8',
    md: 'w-8 h-11',
    lg: 'w-11 h-15',
    xl: 'w-16 h-22',
  };

  const colorMap: Record<string, string> = {
    gold: '#B45309',
    navy: '#0A1F44',
    white: '#FFFFFF',
    saffron: '#F5893C',
    monochrome: 'currentColor',
  };

  const resolvedColor = color || colorMap[variant] || '#0A1F44';
  const customDimensions = typeof size === 'number' ? { width: size, height: Math.round(size * 1.35) } : undefined;
  const classes = typeof size === 'string' ? sizeMap[size] || sizeMap.md : '';

  return (
    <div
      className={`inline-flex flex-col items-center justify-center shrink-0 select-none ${className}`}
      style={customDimensions}
      title="National Emblem of India (Lion Capital of Ashoka) - Satyameva Jayate"
      role="img"
      aria-label="National Emblem of India - Lion Capital of Ashoka"
    >
      <svg
        className={typeof size === 'string' ? classes : 'w-full h-full'}
        viewBox="0 0 100 135"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* ============================================================ */}
        {/* LION CAPITAL OF ASHOKA (OFFICIAL STATE EMBLEM OF INDIA) */}
        {/* ============================================================ */}
        
        {/* Central Lion Head & Mane */}
        <path
          d="M50 8C41 8 36 16 36 25C36 34 37 46 41 64C43 68 47 70 50 70C53 70 57 68 59 64C63 46 64 34 64 25C64 16 59 8 50 8Z"
          fill={resolvedColor}
        />
        {/* Center Lion Face Details */}
        <circle cx="45" cy="22" r="2.2" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} />
        <circle cx="55" cy="22" r="2.2" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} />
        <path d="M48 27H52V33H48Z" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} opacity="0.8" />
        <path d="M43 38C46 43 54 43 57 38" stroke={variant === 'white' ? '#0A1F44' : '#FFFFFF'} strokeWidth="1.8" strokeLinecap="round" />
        <path d="M41 48H59" stroke={variant === 'white' ? '#0A1F44' : '#FFFFFF'} strokeWidth="1.2" opacity="0.6" />

        {/* Left Lion Profile */}
        <path
          d="M32 16C27 10 18 14 16 20C14 26 18 34 22 38C18 42 14 48 16 54C18 60 24 64 30 64C34 64 36 61 38 56C36 48 36 36 36 26C36 20 34 17 32 16Z"
          fill={resolvedColor}
          opacity="0.95"
        />
        {/* Left Lion Eye */}
        <circle cx="23" cy="23" r="1.8" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} />

        {/* Right Lion Profile */}
        <path
          d="M68 16C73 10 82 14 84 20C86 26 82 34 78 38C82 42 86 48 84 54C82 60 76 64 70 64C66 64 64 61 62 56C64 48 64 36 64 26C64 20 66 17 68 16Z"
          fill={resolvedColor}
          opacity="0.95"
        />
        {/* Right Lion Eye */}
        <circle cx="77" cy="23" r="1.8" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} />

        {/* Back Lion mane hint in background */}
        <path d="M44 6H56V12H44Z" fill={resolvedColor} opacity="0.7" />

        {/* ============================================================ */}
        {/* ABACUS (DRUM) WITH ASHOKA CHAKRA, BULL & HORSE */}
        {/* ============================================================ */}
        <rect x="14" y="72" width="72" height="14" rx="2" fill={resolvedColor} />
        
        {/* Center Ashoka Chakra (24 Spokes) */}
        <circle cx="50" cy="79" r="5.5" fill="none" stroke={variant === 'white' ? '#0A1F44' : '#FFFFFF'} strokeWidth="1.2" />
        <circle cx="50" cy="79" r="1.5" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} />
        {/* Spokes */}
        {[...Array(8)].map((_, i) => (
          <line
            key={i}
            x1="50"
            y1="74"
            x2="50"
            y2="84"
            stroke={variant === 'white' ? '#0A1F44' : '#FFFFFF'}
            strokeWidth="0.7"
            transform={`rotate(${i * 22.5} 50 79)`}
          />
        ))}

        {/* Bull on Right & Horse on Left (Silhouettes) */}
        <path d="M24 76C26 76 28 78 28 80C28 82 25 82 23 82C21 82 21 78 24 76Z" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} opacity="0.9" />
        <path d="M76 76C74 76 72 78 72 80C72 82 75 82 77 82C79 82 79 78 76 76Z" fill={variant === 'white' ? '#0A1F44' : '#FFFFFF'} opacity="0.9" />

        {/* ============================================================ */}
        {/* INVERTED LOTUS FLOWER BASE */}
        {/* ============================================================ */}
        <path
          d="M20 88C20 88 28 102 50 102C72 102 80 88 80 88H20Z"
          fill={resolvedColor}
          opacity="0.95"
        />
        {/* Lotus Petal Lines */}
        <path d="M35 88C38 94 44 98 50 99C56 98 62 94 65 88" stroke={variant === 'white' ? '#0A1F44' : '#FFFFFF'} strokeWidth="1" opacity="0.5" fill="none" />

        {/* Foundation Plinth */}
        <rect x="12" y="104" width="76" height="6" rx="1.5" fill={resolvedColor} />

        {/* ============================================================ */}
        {/* SATYAMEVA JAYATE (सत्यमेव जयते) DEVANAGARI MOTTO */}
        {/* ============================================================ */}
        <text
          x="50"
          y="124"
          textAnchor="middle"
          fill={resolvedColor}
          fontSize="11"
          fontWeight="800"
          fontFamily="'Noto Sans Devanagari', 'Plus Jakarta Sans', sans-serif"
          letterSpacing="0.06em"
        >
          सत्यमेव जयते
        </text>
      </svg>
    </div>
  );
};

