import React from 'react';

export const IndianFlagBadge: React.FC<{ className?: string; size?: 'sm' | 'md' | 'lg' }> = ({
  className = '',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'w-5 h-3.5',
    md: 'w-7 h-5',
    lg: 'w-10 h-7',
  };

  return (
    <div
      className={`inline-flex flex-col overflow-hidden rounded-xs border border-white/20 shadow-xs shrink-0 ${sizeClasses[size]} ${className}`}
      title="National Flag of India (Tiranga)"
    >
      {/* Saffron Top Stripe */}
      <div className="flex-1 bg-[#FF9933]" />
      {/* White Middle Stripe with Navy Ashoka Chakra */}
      <div className="flex-1 bg-white flex items-center justify-center relative">
        <svg className="w-2.5 h-2.5 text-[#000080]" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
          <circle cx="12" cy="12" r="2.5" fill="currentColor" />
          {[...Array(12)].map((_, i) => (
            <line
              key={i}
              x1="12"
              y1="3"
              x2="12"
              y2="21"
              stroke="currentColor"
              strokeWidth="0.8"
              transform={`rotate(${i * 15} 12 12)`}
            />
          ))}
        </svg>
      </div>
      {/* India Green Bottom Stripe */}
      <div className="flex-1 bg-[#138808]" />
    </div>
  );
};
