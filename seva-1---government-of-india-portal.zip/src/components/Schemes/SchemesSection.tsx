import React, { useState } from 'react';
import { SCHEMES_LIST } from '../../data/schemesData';
import { SchemeItem, SchemeCategory, LanguageCode, UserProfile } from '../../types';
import { TRANSLATIONS } from '../../data/translations';
import {
  Tractor,
  HeartPulse,
  Home,
  Flame,
  Landmark,
  Users,
  GraduationCap,
  Heart,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Filter,
  ShieldCheck
} from 'lucide-react';

interface SchemesSectionProps {
  currentLanguage: LanguageCode;
  onSelectScheme: (scheme: SchemeItem) => void;
  onCheckEligibility: (scheme?: SchemeItem) => void;
  onViewAllClick: () => void;
  user?: UserProfile;
  showAllSchemes?: boolean;
}

export const SchemesSection: React.FC<SchemesSectionProps> = ({
  currentLanguage,
  onSelectScheme,
  onCheckEligibility,
  onViewAllClick,
  user,
  showAllSchemes = false,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<SchemeCategory>('all');
  const t = TRANSLATIONS[currentLanguage] || TRANSLATIONS.en;

  const getSchemeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Tractor':
        return Tractor;
      case 'HeartPulse':
        return HeartPulse;
      case 'Home':
        return Home;
      case 'Flame':
        return Flame;
      case 'Landmark':
        return Landmark;
      case 'Users':
        return Users;
      case 'GraduationCap':
        return GraduationCap;
      case 'Heart':
      default:
        return Heart;
    }
  };

  const schemeCategories = [
    { id: 'all' as SchemeCategory, label: 'All Schemes' },
    { id: 'farmers' as SchemeCategory, label: 'Farmers & DBT' },
    { id: 'health' as SchemeCategory, label: 'Health (Ayushman)' },
    { id: 'women' as SchemeCategory, label: 'Women & Child' },
    { id: 'students' as SchemeCategory, label: 'Students & Scholarships' },
    { id: 'housing' as SchemeCategory, label: 'Housing (PMAY)' },
    { id: 'seniors' as SchemeCategory, label: 'Senior Citizens' },
  ];

  // Filter schemes
  const filteredSchemes = SCHEMES_LIST.filter(
    (s) => selectedCategory === 'all' || s.category === selectedCategory
  );

  const displaySchemes = showAllSchemes ? filteredSchemes : filteredSchemes.slice(0, 6);

  return (
    <section id="schemes-section" className="py-14 bg-[#F8FAFC] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Strip */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-200">
          <div>
            <div className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-[#F5893C] mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#F5893C]" />
              <span>Direct Benefit Transfer (DBT) & Welfare</span>
              {user?.isLoggedIn && (
                <span className="bg-amber-100 text-amber-900 px-2 py-0.5 rounded text-[10px] font-bold">
                  Personalized for {user.name.split(' ')[0]}
                </span>
              )}
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0A1F44] tracking-tight">
              {t.schemesForYou}
            </h2>
          </div>

          <div className="mt-4 md:mt-0 flex items-center space-x-3">
            <button
              onClick={() => onCheckEligibility()}
              className="bg-[#F5893C] hover:bg-[#e0772d] text-slate-950 font-bold text-xs sm:text-sm px-4 py-2 rounded-lg transition-colors shadow-xs flex items-center space-x-1.5"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>{t.checkEligibility}</span>
            </button>

            {!showAllSchemes && (
              <button
                onClick={onViewAllClick}
                className="inline-flex items-center space-x-1 text-xs sm:text-sm font-semibold text-blue-700 hover:text-blue-900 bg-white border border-slate-300 px-3.5 py-2 rounded-lg transition-colors"
              >
                <span>{t.viewAll}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          {schemeCategories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors border ${
                  isSelected
                    ? 'bg-[#0A1F44] text-white border-[#0A1F44] shadow-xs'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Schemes Grid (Consistent and polished across all screen sizes) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displaySchemes.map((scheme) => {
            const Icon = getSchemeIcon(scheme.iconName);
            return (
              <div
                key={scheme.id}
                className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs hover:shadow-xl hover:border-orange-300 transition-all duration-300 transform hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  {/* Top Badge & Ministry */}
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-orange-50 text-[#F5893C] border border-orange-100 flex items-center justify-center shrink-0">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-bold text-[#F5893C] bg-orange-50 border border-orange-200/70 px-3 py-1 rounded-full text-right">
                      {scheme.benefitAmount}
                    </span>
                  </div>

                  {/* Scheme Name */}
                  <h3
                    onClick={() => onSelectScheme(scheme)}
                    className="text-lg sm:text-[20px] font-bold text-[#0A1F44] hover:text-[#1D5FE0] transition-colors cursor-pointer leading-snug"
                  >
                    {scheme.name}
                  </h3>

                  {/* Ministry */}
                  <p className="text-xs text-slate-500 mt-1 line-clamp-1 font-medium">
                    {scheme.ministry}
                  </p>

                  {/* Body Summary */}
                  <p className="text-sm sm:text-base text-slate-600 mt-3 line-clamp-3 leading-relaxed">
                    {scheme.summary}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {scheme.tags.slice(0, 3).map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-xs font-medium bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Card Action Footers */}
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                  <button
                    onClick={() => onSelectScheme(scheme)}
                    className="text-xs font-bold text-[#1D5FE0] hover:text-[#0A1F44] hover:underline flex items-center space-x-1"
                  >
                    <span>Scheme Details</span>
                  </button>

                  <button
                    onClick={() => onCheckEligibility(scheme)}
                    className="bg-[#F5893C] hover:bg-[#e0772d] text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors flex items-center space-x-1.5"
                  >
                    <ShieldCheck className="w-4 h-4 text-white" />
                    <span>Check Eligibility</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
